    function limpa_formulário_cep() {
            //Limpa valores do formulário de cep.
            document.getElementById('cep').value=("");
            document.getElementById('cep').focus();
            document.getElementById('rua').value=("");
            document.getElementById('bairro').value=("");
            document.getElementById('cidade').value=("");
            document.getElementById('uf').value=("");
    }

    function meu_callback(conteudo) {
        if (!("erro" in conteudo)) {
            //Atualiza os campos com os valores.
            document.getElementById('rua').value=(conteudo.logradouro);
            document.getElementById('bairro').value=(conteudo.bairro);
            document.getElementById('cidade').value=(conteudo.localidade);
            document.getElementById('uf').value=(conteudo.uf);

        } //end if.
        else {
            //CEP não Encontrado.
            limpa_formulário_cep();
            $(document).ready(function() {
                swal({
                    title: "Processo Cancelado!",
                    text: "CEP inválido!",
                    type: "error",
                    timer: 1800,
                    showCancelButton: false, 
                    showConfirmButton: false 
                    });   
                }); 
        }
    }
        
    function pesquisacep(valor) {

        //Nova variável "cep" somente com dígitos.
        var cep = valor.replace(/\D/g, '');

        //Verifica se campo cep possui valor informado.
        if (cep != "") {

            //Expressão regular para validar o CEP.
            var validacep = /^[0-9]{8}$/;

            //Valida o formato do CEP.
            if(validacep.test(cep)) {

                //Preenche os campos com "..." enquanto consulta webservice.
                document.getElementById('rua').value="...";
                document.getElementById('bairro').value="...";
                document.getElementById('cidade').value="...";
                document.getElementById('uf').value="...";

                //Cria um elemento javascript.
                var script = document.createElement('script');

                //Sincroniza com o callback.
                script.src = '//viacep.com.br/ws/'+ cep + '/json/?callback=meu_callback';

                //Insere script no documento e carrega o conteúdo.
                document.body.appendChild(script);

            } //end if.
            else {
                //cep é inválido.
                limpa_formulário_cep();
                $(document).ready(function() {
                swal({
                    title: "Processo Cancelado!",
                    text: "CEP inválido!",
                    type: "error",
                    timer: 1800,
                    showCancelButton: false, 
                    showConfirmButton: false 
                    });   
                }); 
            }
        } //end if.
        else {
            //cep sem valor, limpa formulário.
            limpa_formulário_cep();
        }
    }

//BUSCA CEP PARA AS MODAIS DE EDICAO

    function limpa_cep() {
            //Limpa valores do formulário de cep.
            document.getElementById('ceps').value=("");
            document.getElementById('ceps').focus();
            document.getElementById('ruas').value=("");
            document.getElementById('bairros').value=("");
            document.getElementById('cidades').value=("");
            document.getElementById('ufs').value=("");

    }

    function meu_callbacks(conteudos) {
        if (!("erro" in conteudos)) {
            //Atualiza os campos com os valores.
            document.getElementById('ruas').value=(conteudos.logradouro);
            document.getElementById('bairros').value=(conteudos.bairro);
            document.getElementById('cidades').value=(conteudos.localidade);
            document.getElementById('ufs').value=(conteudos.uf);

        } //end if.
        else {
            //CEP não Encontrado.
            limpa_cep();
            $(document).ready(function() {
             swal({
                    title: "Processo Cancelado!",
                    text: "CEP inválido!",
                    type: "error",
                    timer: 1800,
                    showCancelButton: false, 
                    showConfirmButton: false 
                    });   
                }); 
        }
    }
   
    function pesquisa(valors) {

        //Nova variável "cep" somente com dígitos.
        var ceps = valors.replace(/\D/g, '');

        //Verifica se campo cep possui valor informado.
        if (ceps != "") {

            //Expressão regular para validar o CEP.
            var validaceps = /^[0-9]{8}$/;

            //Valida o formato do CEP.
            if(validaceps.test(ceps)) {

                //Preenche os campos com "..." enquanto consulta webservice.
                document.getElementById('ruas').value="...";
                document.getElementById('bairros').value="...";
                document.getElementById('cidades').value="...";
                document.getElementById('ufs').value="...";

                //Cria um elemento javascript.
                var script = document.createElement('script');

                //Sincroniza com o callback.
                script.src = '//viacep.com.br/ws/'+ ceps + '/json/?callback=meu_callbacks';

                //Insere script no documento e carrega o conteúdo.
                document.body.appendChild(script);

            } //end if.
            else {
                //cep é inválido.
                limpa_cep();
                $(document).ready(function() {
                 swal({
                    title: "Processo Cancelado!",
                    text: "CEP inválido!",
                    type: "error",
                    timer: 1800,
                    showCancelButton: false, 
                    showConfirmButton: false 
                    });   
                }); 
            }
        } //end if.
        else {
            //cep sem valor, limpa formulário.
            limpa_cep();
        }
    };
