        function fechar(){
            $.ajax({
                url:'../controllers/Usuario.php',
                type:'POST',
                data:"menssagem=menssagem&botao=fechar"
            }).done(function(resp){
                window.location.href = "index";
            });
        }