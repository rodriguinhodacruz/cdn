if($("#tbs tr").length == 1){
  $("#tbs").css("display", "none");
  $("#smile").show();
}
else{
  var tb = ($("#tbs  tr").length)-1;
  $("#smile").hide();
}

      $('#tbFatura').append('<tr><td class="color-blue-grey-lighter uppercase"><b>Descrição</b></td><td class="color-blue-grey-lighter uppercase"><b>Procedimentos</b></td><td class="color-blue-grey-lighter uppercase"><b>Valor</b></td></tr>');
      var availableTags = [
         "Dentes  Faces(M, D, V, O/I, L/P)", 
         "Dentes ",
         "Arcadas",
         "Arcada Superior",
         "Arcada Inferior",
         "Arcadas(Agenesia 18, 28, 48, 38)",
         "Arcada Superior(Agenesia 18 e 28)",
         "Arcada Inferior(Agenesia 48 e 38)"];
      $( "#descricao_receber" ).autocomplete({
      source: availableTags
     });

   $('#plano').append('<option class="plano0">Selecione o Plano</option><option class="plano1" value="Particular">Particular</option><option class="plano2" value="Convênio">Convênio</option>');  
   $('#convenioSelect').append('<option class="selecaoConvenio">Selecione o Convênio</option>');
   $('#plano').on('change', function() {
    if($('#plano').val() == 'Particular'){
       $('.convenio').remove();
       $('.selecaoConvenio').remove();
       $('.nome_procedimento').remove();
       $('#valor_procedimento').val(""); 
       $('#convenioSelect').append('<option class="selecaoConvenio">Selecione o Convênio</option>'+'<option class="particular" value="Particular">Particular</option>');
       }
       else{
         $('#convenioSelect').append('<option class="selecaoConvenio">Selecione o Convênio</option>');
         $('.particular').remove();
         $('.selecaoConvenio').remove();
         $('.nome_procedimento').remove();
         $('#valor_procedimento').val("");
         //AJAX BUSCA CONVENIOS
         var id_usuario=$('#id_usuario').val();
          $.post('../models/ConvenioProcedimentos.php', { id_usuario: id_usuario },
            function(data) {
             data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.
             $('#convenioSelect').append('<option class="selecaoConvenio">Selecione o Convênio</option>');
             for(var i=0; data.length > i; i++){  
             $('#convenioSelect').append('<option  class="convenio" value="'+data[i].convenio+'">'+data[i].convenio+'</option>');
            }
         });
       }
    });

    $('#convenioSelect').on('change', function(){
    $('.selecaoConvenio').remove();
    $('.nome_procedimento').remove();
    $('.selecaoProcedimento').remove();
    $('#valor_receber').val("");
    var convenio=$('#convenioSelect').val();                   
     $.post('../models/ProcedimentoBusca.php', { convenio: convenio },
       function(data) {
       data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.
       $('#procedimento').append('<option class="selecaoProcedimento">Selecione o Procedimento</option>');
       for(var i=0; data.length > i; i++){  
       $('#procedimento').append('<option  class="nome_procedimento" value="'+data[i].valor_procedimento+'">'+data[i].nome_procedimento+'</option>');
       }
     });
    });

    $('#procedimento').on('change', function() {
       var valor = $(this).val();
       $('#valor_receber').val(parseInt(valor).toLocaleString('pt-br', {minimumFractionDigits: 2}));
    });

    $('#procedimento').on('change', function() {
       $("#tbFatura2").html("");
       $("#tbDescricao").html("");
       var valor = $(this).val();
       var procedimentos = $("#procedimento option:selected").text();
       var descricao = $("#descricao_receber").val();
       $('#tbFatura2').append('<tr><td>'+descricao+'</td><td>'+procedimentos+'</td><td>'+parseInt(valor).toLocaleString('pt-br', {minimumFractionDigits: 2})+'</td></tr>');
       $('#tbDescricao').append(descricao+', '+procedimentos);
       $('#valor_receber').val(parseInt(valor).toLocaleString('pt-br', {minimumFractionDigits: 2}));
    });

       function atualizarTabela() {
         $("#tbFatura2").html("");
         $("#tbDescricao").html("");
         var valor = $('#procedimento').val();
         var procedimentos = $("#procedimento option:selected").text();
         var descricao = $("#descricao_receber").val();
         $('#tbFatura2').append('<tr><td>'+descricao+'</td><td>'+procedimentos+'</td><td>'+parseInt(valor).toLocaleString('pt-br', {minimumFractionDigits: 2})+'</td></tr>');
         $('#tbDescricao').append(descricao+', '+procedimentos);
       }

       function atualizarOutros() {
         $("#tbFatura2").html("");
         $("#tbDescricao").html("");
         var descricao = $("#descricao_receber").val();
         var valorOutros = $('#valor_outros').val();
         $('#tbFatura2').append('<tr><td>'+descricao+'</td><td>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</td><td>'+valorOutros+'</td></tr>');
         $('#tbDescricao').append(descricao);
       }

        function Atualizar() {
           window.location.reload();
        }

         function cadastrar_recebimento(){
            var id_usuario=$('#id_usuario').val();
            var id_paciente=$('#paciente').val();
            var nome_fatura=$('#nome_fatura').val();
            var plano="Particular";
            var convenio="Particular";
            var procedimentos_aprovados= $('#divAprovados').html();
            var tbDescricao= $('#tbDescricao').html();
            if ($('#valor_receber').val()=="") {
                var valor_total=$('#valor_outros').val();
            }
            else{
                var valor_total=$('#valor_receber').val();
            }
            var parcelamento="1";
            var valor_entrada="0";
            var desconto="";
            var forma_pagamento="Dinheiro";
            var dt_vencimento=$('#dt_vencimento').val();

            if (cadastroReceber.dt_vencimento.value == "")
            {
            cadastroReceber.dt_vencimento.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha com a Data de Vencimento!",
            type: "error",
            timer: 1300,
            showCancelButton: false, 
            showConfirmButton: false 
            });            
            return (false);
            }
            $.ajax({
              url: '../controllers/Orcamentos.php',
              type: 'POST',
              data:'id_usuario='+id_usuario+'&id_paciente='+id_paciente+'&nome_fatura='+nome_fatura+'&plano='+plano+'&convenio='+convenio+'&procedimentos_aprovados='+procedimentos_aprovados+'&tbDescricao='+tbDescricao+'&valor_total='+valor_total+'&parcelamento='+parcelamento+'&valor_entrada='+valor_entrada+'&desconto='+desconto+'&forma_pagamento='+forma_pagamento+'&dt_vencimento='+dt_vencimento+'&botao=cadastrarReceber'
            }).done(function(resposta){
            if (resposta) {
               $('#CadastroRecebimento').modal('hide'); 
               swal({
                 title: "Processo Concluído!",
                 text: "Recebimento cadastrado com sucesso!",
                 type: "success",
                 showCancelButton: false, 
                 showConfirmButton: false 
               });
               setTimeout('location.reload();', 1700);
             }  
          });
        }

      function visualizarCheque(id) {
        var id_fatura=id; 
        $('.id_fatura').val(id);
        $('#tabela_cheques').html("");
        $('#cheque_paciente').modal("show"); 
        $.post('../models/ChequeBusca.php', {id_fatura: id_fatura},
          function(data) {
           data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.
           for(var i=0; data.length > i; i++){
            var idCheque = data[i].id;

            if(data[i].status_cheque == "#DAA520"){
               var status_cheques = '<span class="label label-warning" style="position:relative; left:8%;">Aguardando Compensação</span>';
            }
            if(data[i].status_cheque == "#3CB371"){
               var status_cheques = '<span class="label label-success" style="position:relative; left:8%;">Cheque Compensado</span>';
            }
            if(data[i].status_cheque == "#FF6347"){
               var status_cheques = '<span class="label label-danger" style="position:relative; left:8%;">Cheque Devolvido</span>';
            }
            $('#tabela_cheques').append("<tr><td>"+data[i].nome_titular+"</td><td>"+moment(data[i].data_emissao).format('DD/MM/YYYY')+"</td><td>"+moment(data[i].pre_datado).format('DD/MM/YYYY')+"</td><td>"+parseFloat(data[i].valor_cheque).toLocaleString('pt-br', {minimumFractionDigits: 2})+"</td><td id='tdStatus'>"+status_cheques+"</td><td><a onclick='compensarCheque("+idCheque+")' style='position: relative; left:-15px;' class = 'tool' data-tip='Compensar' tabindex='2'><i class='fa fa-usd color-green' style='font-size:17px'></i></a><a onclick='devolverCheque("+idCheque+")' style='position: relative; left:-2px;' class = 'tool' data-tip='Devolver' tabindex='2'><i class='fa fa-usd color-red' style='font-size:17px'></i></a><a onclick='imprimeCheque("+idCheque+")' style='position: relative; left:8px;' class = 'tool' data-tip='Imprimir' tabindex='2'><i class='fa fa-print color-blue' style='font-size:15px'></i></a></td></tr>");          
            }
        });
      }

      function compensarCheque(idCheque) {
        $('#cheque_paciente').modal('hide');
        var idCheque = idCheque;
        swal({
        title: 'Você tem certeza?',
        text: "Deseja Compensar este Cheque?",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sim',
        cancelButtonText: "Cancelar",   
        closeOnConfirm: false,   
        closeOnCancel: false
        },
        function(isConfirm){   
         if (isConfirm){   
          swal({
          title: "Processo Concluído!",
          text: "Cheque Compensado com sucesso!",
          type: "success",
          timer: 1500,
          showCancelButton: false, 
          showConfirmButton: false 
          });
          $.ajax({
            url:'../controllers/Recebimentos.php',
            type: "POST",
            data: 'id='+idCheque+"&botao=compensarCheque"
          });
          window.setTimeout(function () {
            id=$('.id_fatura').val();
            visualizarCheque(id) 
           }, 1500);
          }
          else{     
          swal({
            title: "Processo Cancelado!",
            text: "Cheque não Compensado!",
            type: "error",
            timer: 1500,
            showCancelButton: false, 
            showConfirmButton: false 
            });
            window.setTimeout(function () {
            id=$('.id_fatura').val();
            visualizarCheque(id) 
           }, 1500);   
          }
        });
      }

      function devolverCheque(idCheque) {
        $('#cheque_paciente').modal('hide');
        var idCheque = idCheque;
        swal({
        title: 'Você tem certeza?',
        text: "Deseja Devolver este Cheque?",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sim',
        cancelButtonText: "Cancelar",   
        closeOnConfirm: false,   
        closeOnCancel: false
        },
        function(isConfirm){   
         if (isConfirm){     
          swal({
          title: "Processo Concluído!",
          text: "Cheque Devolvido com sucesso!",
          type: "success",
          timer: 1500,
          showCancelButton: false, 
          showConfirmButton: false 
          });
          $.ajax({
            url:'../controllers/Recebimentos.php',
            type: "POST",
            data: 'id='+idCheque+"&botao=devolverCheque"
          });
          window.setTimeout(function () {
            id=$('.id_fatura').val();
            visualizarCheque(id) 
           }, 1500);
          }
          else{     
          swal({
            title: "Processo Cancelado!",
            text: "Cheque não Devolvido!",
            type: "error",
            timer: 1700,
            showCancelButton: false, 
            showConfirmButton: false 
            });
            window.setTimeout(function () {
            id=$('.id_fatura').val();
            visualizarCheque(id) 
           }, 1500);   
          }
        });
      }

    
      function imprimeCheque(idCheque) {
        var randomico=$('#randomico').val();
        var codigo = randomico+btoa(idCheque);
        window.open('imprimir/cheque?@='+codigo, '_blank');
        window.setTimeout(function () {
        id=$('.id_fatura').val();
         visualizarCheque(id) 
        }, 1500);
      }

      function visualizarBoleto(id) {
        var id_fatura=id 
        $('#boleto_paciente').modal("show");
        $('#tabela_boletos').html("");
        $.post('../models/BoletosBusca.php', {id_fatura: id_fatura},
          function(data) {
           data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.
           for(var i=0; data.length > i; i++){ 
            if(data[i].status_fatura == "Aguardando Pagamento"){
                status = '<span class="label label-warning" style="position:relative; left:25%;">Aguardando Pagamento</span>';
            }
            if(data[i].status_fatura == "Fatura Liquidada"){
                status = '<span class="label label-success" style="position:relative; left:25%;">Fatura Liquidada</span>';
            }
            if(data[i].status_fatura == "Fatura Cancelada"){
                status = '<span class="label label-danger" style="position:relative; left:25%;">Fatura Cancelada</span>';
            }
              $('#tabela_boletos').append("<tr><td>"+data[i].paciente+"</td><td>"+data[i].dentista+"</td><td>"+moment(data[i].dt_vencimento).format('DD/MM/YYYY')+"</td><td>"+parseFloat(data[i].valor_fatura).toLocaleString('pt-br', {minimumFractionDigits: 2})+"</td><td>"+status+"</td></tr>");          
            }
        });
      }


      function excluirFaturas(id){
        var id=id        
          swal({
              title: 'Você tem certeza?',
              text: "A Fatura será excluída permanentemente!",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Sim',
              cancelButtonText: "Cancelar",   
              closeOnConfirm: false,   
              closeOnCancel: false
              },

             function(isConfirm){   
               if (isConfirm){     
                   swal({
                   title: "Processo Concluído!",
                   text: "Fatura excluída com sucesso!",
                   type: "success",
                   showCancelButton: false, 
                   showConfirmButton: false 
                   });
                   $.ajax({
                     url:'../controllers/Recebimentos.php',
                     type: "POST",
                     data: 'id='+id+"&botao=excluirFaturas"
                   });
                     setTimeout('location.reload();', 1700);
                   }
                   else{     
                    swal({
                      title: "Processo Cancelado!",
                      text: "Fatura não excluída!",
                      type: "error",
                      timer: 1700,
                      showCancelButton: false, 
                      showConfirmButton: false 
                     });   
                    }
                  });
                }

      
      function excluirFaturasBoletos(id){
        var id=id        
          swal({
              title: 'Você tem certeza?',
              text: "A Fatura será excluída permanentemente!",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Sim',
              cancelButtonText: "Cancelar",   
              closeOnConfirm: false,   
              closeOnCancel: false
              },

             function(isConfirm){   
               if (isConfirm){     
                   swal({
                   title: "Processo Concluído!",
                   text: "Fatura excluída com sucesso!",
                   type: "success",
                   showCancelButton: false, 
                   showConfirmButton: false 
                   });
                   $.ajax({
                     url:'../controllers/Recebimentos.php',
                     type: "POST",
                     data: 'id='+id+"&botao=excluirFaturasBoletos"
                   });
                     setTimeout('location.reload();', 1700);
                   }
                   else{     
                    swal({
                      title: "Processo Cancelado!",
                      text: "Fatura não excluída!",
                      type: "error",
                      timer: 1700,
                      showCancelButton: false, 
                      showConfirmButton: false 
                     });   
                    }
                  });
                }
      
      function excluirFaturasCheques(id){
        var id=id        
          swal({
              title: 'Você tem certeza?',
              text: "A Fatura será excluída permanentemente!",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Sim',
              cancelButtonText: "Cancelar",   
              closeOnConfirm: false,   
              closeOnCancel: false
              },

             function(isConfirm){   
               if (isConfirm){     
                   swal({
                   title: "Processo Concluído!",
                   text: "Fatura excluída com sucesso!",
                   type: "success",
                   showCancelButton: false, 
                   showConfirmButton: false 
                   });
                   $.ajax({
                     url:'../controllers/Recebimentos.php',
                     type: "POST",
                     data: 'id='+id+"&botao=excluirFaturasCheques"
                   });
                     setTimeout('location.reload();', 1700);
                   }
                   else{     
                    swal({
                      title: "Processo Cancelado!",
                      text: "Fatura não excluída!",
                      type: "error",
                      timer: 1700,
                      showCancelButton: false, 
                      showConfirmButton: false 
                     });   
                    }
                  });
                }

         function cancelar_exclusao(){
           swal({
             title: "Processo Cancelado!",
             text: "Você não pode excluir uma Fatura Liquidada!",
             type: "error",
             timer: 1700,
             showCancelButton: false, 
             showConfirmButton: false 
            }); 
         }
