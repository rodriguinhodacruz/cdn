      //insert update das configuracoes
        function configuracoes(){
            var id=$('#id').val();
            var nome_clinica=$('#nome_clinica').val();
            var especialidade=$('#especialidade').val();
            var status=$('#status').val();
            var registrocro=$('#registrocro').val();
            var epao=$('#epao').val();
            var cpf=$('#cpf').val();
            var cnpj=$('#cnpj').val();
            var resp_tecnico=$('#resp_tecnico').val();
            var telefone_comercial=$('#telefoneFixo').val();
            var telefone_celular=$('#celular').val();
            var cep=$('#cep').val();
            var numero=$('#numero').val();
            var rua=$('#rua').val();
            var bairro=$('#bairro').val();
            var cidade=$('#cidade').val();
            var uf=$('#uf').val();
            var email_pagseguro=$('#email_pagseguro').val();
            var token_pagseguro=$('#token_pagseguro').val();

            $.ajax({
                    url:'../controllers/Configuracoes.php',
                    type:'POST',
                    data:'id='+id+'&nome_clinica='+nome_clinica+'&especialidade='+especialidade+'&status='+status+'&registrocro='+registrocro+'&epao='+epao+'&cpf='+cpf+'&cnpj='+cnpj+'&resp_tecnico='+resp_tecnico+'&telefone_comercial='+telefone_comercial+'&telefone_celular='+telefone_celular+'&cep='+cep+'&numero='+numero+'&rua='+rua+'&bairro='+bairro+'&cidade='+cidade+'&uf='+uf+'&email_pagseguro='+email_pagseguro+'&token_pagseguro='+token_pagseguro+'&botao=Config'
                }).done(function(resposta){
                    if (resposta) {
                        swal({
                            title: "Processo Concluído!",
                            text: "Registro atualizado com sucesso!",
                            type: "success",
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });
                      setTimeout('location.reload();', 1700);
                    }

                    
                });
            
            }


$(document).ready(function() {
    $('#status').change(function(){
    var tipo = $("#status option:selected").val();
    
    if (tipo == 'Clínica Odontológica') {
      $('#registrocro').attr('disabled', true);
      $('#epao').attr('disabled', false);
      $('#especialidade').attr('disabled', true);
    }else if (tipo == 'Consultório Odontológico') {
      $('#registrocro').attr('disabled', false);
      $('#epao').attr('disabled', true);
      $('#especialidade').attr('disabled', false);
    }
  });
});

