if($("#tbPacientes tr").length == 1){
  $("#tbPacientes").css("display", "none");
  $("#smile").show();
}
else{
  var tb = ($("#tbPacientes  tr").length)-1;
  $("#smile").hide();
}

   $('._cpf').hide();
   $('.rg').hide();
   $('._cnpj').hide();
   $('.ie').hide();
   $('#tipo_fornecedor').on('change', function() {
    if($('#tipo_fornecedor').val() == 'fisica'){
       $('._cpf').show();
       $('.rg').show();
       $('._cnpj').hide();
       $('.ie').hide();
       $('._cpf2').show();
       $('.rg2').show();
       $('._cnpj2').hide();
       $('.ie2').hide();
    }
    else if($('#tipo_fornecedor').val() == 'juridica'){
       $('._cpf').hide();
       $('.rg').hide();
       $('._cnpj').show();
       $('.ie').show();
       $('._cpf2').hide();
       $('.rg2').hide();
       $('._cnpj2').show();
       $('.ie2').show();
    }
  });

    if($('#cpf').val() == ''){
       $('._cpf2').hide();
       $('.rg2').hide();
       $('._cnpj2').show();
       $('.ie2').show();              
       $('#tipo_fornecedor2').append('<option value="juridica">Pessoa Jurídica</option>');
    }
    else if($('#_cnpj2').val() == ''){
       $('._cpf2').show();
       $('.rg2').show();
       $('._cnpj2').hide();
       $('.ie2').hide();
       $('#tipo_fornecedor2').append('<option value="fisica">Pessoa Física</option>');
    }

//FUNCAO QUE CADASTRA FORNECEDOR
        function cadastrar_fornecedor(){
            var id_usuario=$('#id_usuario').val();
            var segmento=$('#segmento').val();
            var fornecedor=$('#fornecedor').val();
            var cpf=$('#cpf').val();
            var rg=$('#rg').val();
            var cnpj=$('#cnpj').val();
            var inscricao_estadual=$('#inscricao_estadual').val();
            var email=$('#email').val();
            var site=$('#site').val();
            var telefone=$('#telefone').val();
            var cep=$('#cep').val();
            var numero=$('#numero').val();
            var rua=$('#rua').val();
            var bairro=$('#bairro').val();
            var cidade=$('#cidade').val();
            var uf=$('#uf').val();

            if (cadastroFornecedor.tipo_fornecedor.value == "")
            {
            cadastroFornecedor.tipo_fornecedor.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, selecione o tipo de Fornecedor!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });            
            return (false);
            }

            if (cadastroFornecedor.fornecedor.value == "")
            {
            cadastroFornecedor.fornecedor.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Fornecedor!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });            
            return (false);
            }
            
            if (cadastroFornecedor.telefone.value == "")
            {
            cadastroFornecedor.telefone.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Telefone!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });           
            return (false);
            }
        
            $.ajax({
              url:'../controllers/Fornecedores.php',
              type:'POST',
              data:'id_usuario='+id_usuario+'&segmento='+segmento+'&fornecedor='+fornecedor+'&cpf='+cpf+'&rg='+rg+'&cnpj='+cnpj+'&inscricao_estadual='+inscricao_estadual+'&email='+email+'&site='+site+'&telefone='+telefone+'&cep='+cep+'&numero='+numero+'&rua='+rua+'&bairro='+bairro+'&cidade='+cidade+'&uf='+uf+'&botao=cadastrarFornecedor'
            }).done(function(resposta){
            if (resposta) {
                $('#CadastroFornecedores').modal('hide'); 
                swal({
                title: "Processo Concluído!",
                text: "Cadastro realizado com sucesso!",
                type: "success",
                showCancelButton: false, 
                showConfirmButton: false 
                });
                setTimeout('location.reload();', 1700);
              }
            });
          }


//FUNCAO QUE EDITA FORNECEDOR
        function editar_fornecedor(id){
            var id=$('#id').val();
            var segmento=$('#segmento').val();
            var fornecedor=$('#fornecedor').val();
            var cpf=$('#cpf').val();
            var rg=$('#rg').val();
            var cnpj=$('#cnpj').val();
            var inscricao_estadual=$('#inscricao_estadual').val();
            var email=$('#email').val();
            var site=$('#site').val();
            var telefone=$('#telefone').val();
            var cep=$('#cep').val();
            var numero=$('#numero').val();
            var rua=$('#rua').val();
            var bairro=$('#bairro').val();
            var cidade=$('#cidade').val();
            var uf=$('#uf').val();


            if (editaFornecedor.fornecedor.value == "")
            {
            editaFornecedor.fornecedor.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Fornecedor!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });            
            return (false);
            }
            
            if (editaFornecedor.telefone.value == "")
            {
            editaFornecedor.telefone.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Telefone!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });           
            return (false);
            }
        
            $.ajax({
              url:'../controllers/Fornecedores.php',
              type:'POST',
              data:'id='+id+'&segmento='+segmento+'&fornecedor='+fornecedor+'&cpf='+cpf+'&rg='+rg+'&cnpj='+cnpj+'&inscricao_estadual='+inscricao_estadual+'&email='+email+'&site='+site+'&telefone='+telefone+'&cep='+cep+'&numero='+numero+'&rua='+rua+'&bairro='+bairro+'&cidade='+cidade+'&uf='+uf+'&botao=editarFornecedor'
            }).done(function(resposta){
            if (resposta) { 
                swal({
                title: "Processo Concluído!",
                text: "Cadastro editado com sucesso!",
                type: "success",
                showCancelButton: false, 
                showConfirmButton: false 
                });
                setTimeout('location.href = "fornecedores"', 1700);
              }
            });
          }
             function deletar(id){
                var id=id          
                swal({
                title: 'Você tem certeza?',
                text: "O Registro será excluído permanentemente!",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sim',
                cancelButtonText: "Cancelar",   
                closeOnConfirm: false,   
                closeOnCancel: false
                },
                function(isConfirm){   
                  if (isConfirm){     
                    swal({
                    title: "Processo Concluído!",
                    text: "Registro excluído com sucesso!",
                    type: "success",
                    showCancelButton: false, 
                    showConfirmButton: false 
                    });
                    $.ajax({
                    url:'../controllers/Fornecedores.php',
                    type: "POST",
                    data: 'id='+id+"&botao=excluirFornecedor"
                    });
                    setTimeout('location.reload();', 1700);
                    }
                    else{     
                    swal({
                    title: "Processo Cancelado!",
                    text: "Registro não excluído!",
                    type: "error",
                    timer: 1700,
                    showCancelButton: false, 
                    showConfirmButton: false 
                    });   
                    }
                  });
                }
        

   


        

   