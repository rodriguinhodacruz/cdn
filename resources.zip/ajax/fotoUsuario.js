    //ENVIA IMAGENS DA  WEBCAM 
    Webcam.set({
      width: 150,
      height: 150,
      image_format: 'jpeg',
      jpeg_quality: 90
    });
    Webcam.attach( '#usuario' );
    //FUNCAO QUE TIRA A FOTO COM A TECLA ESPAÇO E SALVA VIA AJAX NO BD

     function tiraFoto(){
         Webcam.snap(function(data_uri) {
         var id=$('#idWebcamUser').val();
         var foto_velha=$('#foto_velha').val();
         Webcam.upload( data_uri, '../controllers/WebcamUsuario.php?id='+id+'&foto_velha='+foto_velha)    
          
            })
            $('#webcamUser').modal('hide');
            $('#fotoUsuarios').modal('hide'); 

                swal({
                    title: "Processo Concluído!",
                    text: "Foto alterada com sucesso!",
                    type: "success",
                    showCancelButton: false, 
                    showConfirmButton: false 
                    });
                setTimeout('location.reload();', 1700);
           }


        //FUNCAO ALTERAR FOTO PERFIL DO PACIENTE
        function fotoUsuarios(id){
          var id=id
          $.post('../models/UsuarioBusca.php', { id: id },
            function(data) {
            data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.  
             $('#idFoto').val(data[0].id);
             $('#img-preview').attr('src', data[0].fotoUsuario);
            });

        }
          $("#file-input").change(function() {
          var file = this.files[0];
          var imagefile = file.type;
          var reader = new FileReader();
            reader.onload = function(e){
                $(".img").html('<img src="' + e.target.result + '" />');              
            };
            reader.readAsDataURL(this.files[0]);
          }); 

          $('#file-input').change(function() {
            var id=$('#idFoto').val();
            var foto_velha=$('#foto_velha').val();
             $('#form-fotoUsuario').ajaxForm({
                    url: '../controllers/FotoUsuario.php',
                    type: 'post',
                    data:{ id: id, foto_velha:foto_velha }
             }).submit();

              $('#imagem1').modal('hide'); 
              $('#fotoUsuarios').modal('hide'); 
                swal({
                    title: "Processo Concluído!",
                    text: "Foto alterada com sucesso!",
                    type: "success",
                    showCancelButton: false, 
                    showConfirmButton: false 
                    });
                setTimeout('location.reload();', 1700);
          }); 

        


