

//FUNCAO QUE CADASTRA A ANAMNESE
        function cadastrar_anamnese(){
            var id_Paciente=$('#idPaciente').val();
            var id_usuario=$('#id_usuario').val();
            var id_paciente=$('#id_paciente').val();
            var febre_reumatica = $('input:radio[name=febre_reumatica]:checked').val(); 
            var hepatite = $('input:radio[name=hepatite]:checked').val();
            var diabetes = $('input:radio[name=diabetes]:checked').val();
            var anemia = $('input:radio[name=anemia]:checked').val();
            var portador_hiv = $('input:radio[name=portador_hiv]:checked').val();  
            var asma = $('input:radio[name=asma]:checked').val();
            var problema_cardiaco = $('input:radio[name=problema_cardiaco]:checked').val();  
            var problema_renal = $('input:radio[name=problema_renal]:checked').val();
            var problema_respiratorio = $('input:radio[name=problema_respiratorio]:checked').val();    
            var problema_cicatrizacao = $('input:radio[name=problema_cicatrizacao]:checked').val();
            var problema_anestesia = $('input:radio[name=problema_anestesia]:checked').val();
            var teve_hemorragia = $('input:radio[name=teve_hemorragia]:checked').val(); 
            var usando_medicacao=$('#usando_medicacao').val();
            var medico_assistente=$('#medico_assistente').val();
            var tratamento_medico=$('#tratamento_medico').val();
            var foi_operado=$('#foi_operado').val();
            var gravidez=$('#gravidez').val();
            var antecedentes_familiares=$('#antecedentes_familiares').val();
            var alergias=$('#alergias').val();
            var pressao_alta_baixa=$('#pressao_alta_baixa').val();
            var problema_articulacao=$('#problema_articulacao').val();
            var usa_marcapasso=$('#usa_marcapasso').val();
            var tonturas_desmaios=$('#tonturas_desmaios').val();
            var problemas_gastricos =$('#problemas_gastricos').val();
            var queixa_principal =$('#queixa_principal').val();
            var dor_mastigar =$('#dor_mastigar').val();
            var mastiga_doisLados =$('#mastiga_doisLados').val();
            var usa_alcoolDrogas=$('#usa_alcoolDrogas').val();
            var e_fumante=$('#e_fumante').val();
            var extracoes=$('#extracoes').val();
            var usa_protese=$('#usa_protese').val();
            var higiene_bucal=$('#higiene_bucal').val();
            var ranger_dentes=$('#ranger_dentes').val();
            var alteracao_bucal=$('#alteracao_bucal').val();
            var come_doces=$('#come_doces').val();
            var toma_cafe=$('#toma_cafe').val();
            var gengiva_dolorida=$('#gengiva_dolorida').val();
            var ultimo_tratamento=$('#ultimo_tratamento').val();
            var observacoes=$('#observacoes').val();

            $.ajax({
                    url:'../controllers/Anamnese.php',
                    type:'POST',
                    data:'id_usuario='+id_usuario+'&id_paciente='+id_paciente+'&febre_reumatica='+febre_reumatica+'&hepatite='+hepatite+'&diabetes='+diabetes+'&anemia='+anemia+'&portador_hiv='+portador_hiv+'&asma='+asma+'&problema_cardiaco='+problema_cardiaco+'&problema_renal='+problema_renal+'&problema_respiratorio='+problema_respiratorio+'&problema_cicatrizacao='+problema_cicatrizacao+'&problema_anestesia='+problema_anestesia+'&teve_hemorragia='+teve_hemorragia+'&usando_medicacao='+usando_medicacao+'&medico_assistente='+medico_assistente+'&tratamento_medico='+tratamento_medico+'&foi_operado='+foi_operado+'&gravidez='+gravidez+'&antecedentes_familiares='+antecedentes_familiares+'&alergias='+alergias+'&pressao_alta_baixa='+pressao_alta_baixa+'&problema_articulacao='+problema_articulacao+'&usa_marcapasso='+usa_marcapasso+'&tonturas_desmaios='+tonturas_desmaios+'&problemas_gastricos='+problemas_gastricos+'&queixa_principal='+queixa_principal+'&dor_mastigar='+dor_mastigar+'&mastiga_doisLados='+mastiga_doisLados+'&usa_alcoolDrogas='+usa_alcoolDrogas+'&e_fumante='+e_fumante+'&extracoes='+extracoes+'&usa_protese='+usa_protese+'&higiene_bucal='+higiene_bucal+'&ranger_dentes='+ranger_dentes+'&alteracao_bucal='+alteracao_bucal+'&come_doces='+come_doces+'&toma_cafe='+toma_cafe+'&gengiva_dolorida='+gengiva_dolorida+'&ultimo_tratamento='+ultimo_tratamento+'&observacoes='+observacoes+'&botao=cadastrarAnamnese'
                }).done(function(resposta){
        
               if (resposta) {
               swal({
                title: 'Deseja Imprimir a Anamnese?',
                text: "Caso cancele, poderá imprimir depois!",
                type: 'info',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sim',
                cancelButtonText: "Cancelar",   
                closeOnConfirm: false,   
                closeOnCancel: false
                },

               function(isConfirm){   
                if (isConfirm){     
                    swal({
                    title: "Processo Concluído!",
                    text: "Anamnese Impressa com sucesso!!",
                    type: "success",
                    showCancelButton: false, 
                    showConfirmButton: false 
                    });
                    window.open('imprimir/anamnese?@='+id_Paciente,'_blank');
                    setTimeout('location.reload();', 1400);
                }
                else{     
                    swal({
                    title: "Processo Cancelado!",
                    text: "Anamnese Não Impressa!",
                    type: "error",
                    timer: 1700,
                    showCancelButton: false, 
                    showConfirmButton: false 
                    });   
                    }
                });
             }
        }); 
            }


