    //INICIO CAIXA
    var date = new Date();
      
        $('#caixa').fullCalendar({

            defaultView: 'agendaDay', //agendaWeek
            hiddenDays: [0],
            minTime: "06:00:00",
            maxTime: "24:00:00",
            allDaySlot:false,
            header: {
            left: '',
            center: 'prev, title, next',
            right: ''
            },
            editable: true,
            eventLimit: true,
            selectable: true,
            selectHelper: false,
            displayEventTime: false,
            events: "../models/Caixa.php",

            select: function(start, end) {
                $('.fc-popover.click').remove();
               $(".fc-popover").hide();
            },
            
            viewRender: function(view, element) {
               
                $("#side-datetimepicker").on("dp.change",function (e) {
                $(".fc-popover").hide();
                var consulta = $("#consulta").val();
                $('#caixa').fullCalendar( 'gotoDate', consulta );
                });
              
            },

            eventRender: function(event, element) {

                element.bind('click', function() {
                    $('#id').val(event.id);
                    $('#id_paciente').val(event.id_paciente);
                    $('#title').val(event.title);
                    $('#color').val(event.color);
                    $('#start').val(event.start);
                    $('#end').val(event.end);
                    $(".fc-popover").hide();
                  
               });
             },
            
            //AQUI 'E REFERENTE AOS ELEMENTOS DA BODY POPOVER'
            eventClick: function(event, calEvent, jsEvent, view) {

            var eventEl = $(this);
            if (!$(this).hasClass('event-clicked')) {
                 $('.fc-event').removeClass('event-clicked');
                 $(this).addClass('event-clicked');
                 $('#id').val(event.id);
                 $('#id_paciente').val(event.id_paciente);
                 $('#title').val(event.title);
                 $('#color').val(event.color);
                 if(event.color == "#FF6347"){
                    statusFatura="Fatura Pendente"
                 }
                 else if (event.color == "#3CB371"){
                    statusFatura="Fatura Liquidada"
                 }
                 else{
                    statusFatura="Fatura em Análise"
                 }

                 if(event.color == "#3CB371"){
                    visualizaBoleto='';
                    excluirBoleto='';
                    buttonCobrar='';
                    buttonExclui='';
                    buttonImprime='<button type="button" class="btn btn-rounded btn-sm btn-primary-outline" onclick="imprime_2via('+event.id+')">2° Via Recibo</button>';
                 }
                 else if(event.color == "#DAA520" && event.forma_pagamento == "Boleto Bancário"){
                    visualizaBoleto='<button type="button" class="btn btn-rounded btn-sm btn-primary-outline" onclick="visualizarBoleto('+event.id+')">Visualizar</button>';
                    excluirBoleto='<button type="button" class="btn btn-rounded btn-sm btn-danger-outline" onclick="excluirFaturasBoletos('+event.id+')">Excluir</button>';
                    buttonCobrar='';
                    buttonExclui='';
                    buttonImprime='';
                 }
                 else if(event.color == "#DAA520" && event.forma_pagamento == "Cheque"){ 
                    visualizaBoleto='<button type="button" class="btn btn-rounded btn-sm btn-primary-outline" onclick="visualizarCheque('+event.id+')">Visualizar</button>';
                    excluirBoleto='<button type="button" class="btn btn-rounded btn-sm btn-danger-outline" onclick="excluirFaturasCheques('+event.id+')">Excluir</button>';
                    buttonCobrar='';
                    buttonExclui='';
                    buttonImprime='';
                 }
                 else{
                    visualizaBoleto='';
                    excluirBoleto='';
                    buttonCobrar='<button type="button" class="btn btn-rounded btn-sm btn-success-outline cobrar_evento" onclick="cobrarFatura('+event.id+')">Cobrar</button>';
                    buttonExclui='<button type="submit" class="btn btn-rounded btn-sm btn-danger-outline excluir_evento">Excluir</button>';
                    buttonImprime='';
                 }
                 $('#start').val(event.start);
                 $('#end').val(event.end);


            }
            // BODY POPOVER
            $('body').append(
                '<div class="fc-popover click" style="width:20%;">' +
                '<div class="fc-header">'+statusFatura+
                '<button type="button" class="cl"><i class="font-icon-close-2"></i></button>' +
                '</div>' +

                '<div class="fc-body main-screen">' +
                '<p><b>Fatura emitida por Dr(a) ' +event.dentista+' para o(a) Paciente '+event.paciente+' em</b>' +moment(event.start).format('<b> dddd, DD/MM/YYYY - HH:mm </b>')+'<b>horas</b>'+'</p>'+
                '<p class="color-blue-grey"><br/></p>' +
                '<div class="text-center">' +
                '<a href="#" class="prontuario">'+
                  buttonCobrar +
                '</a>'+ 
                  visualizaBoleto +
                  buttonImprime +
                '<a href="#" class="deletar">'+
                  buttonExclui +
                '</a>'+
                  excluirBoleto +'</div>' +
                '</div>' +
                '<form>'+

                '<input type="hidden" id="id" name="id" class="form-control" value='+event.id+'>'+
                '<input type="hidden" id="deletar" name="deletar" value="1">'+ 
                '</form>' +
                '</div>'
            );
       

            //classe e funcao que deleta agendamento
             $('.deletar').click(function(e){
              var id = $("#id").val();
              var deletar = $("#deletar").val();
              e.preventDefault();
              $('.fc-popover.click').remove();
            
              swal({
               title: 'Você tem certeza?',
               text: "A Fatura será excluída permanentemente!",
               type: 'warning',
               showCancelButton: true,
               confirmButtonColor: '#3085d6',
               cancelButtonColor: '#d33',
               confirmButtonText: 'Sim',
               cancelButtonText: "Cancelar",   
               closeOnConfirm: false,   
               closeOnCancel: false
               },
               function(isConfirm){   
                if (isConfirm){     
                swal({
                 title: "Processo Concluído!",
                 text: "Fatura excluída com sucesso!",
                 type: "success",
                 timer: 1700,
                 showCancelButton: false, 
                 showConfirmButton: false 
                });
                $.ajax({
                  url: '../controllers/Orcamentos.php',
                  type: "POST",
                  data: 'id='+id+"&botao=excluirFinalizado",
                  success: function(e){
                   $('#caixa').fullCalendar('refetchEvents', e);  
                   $('#caixa').fullCalendar('rerenderEvents');
                   }
                });
              }
              else{     
               swal({
                title: "Processo Cancelado!",
                text: "Fatura não excluída!",
                type: "error",
                timer: 1700,
                showCancelButton: false, 
                showConfirmButton: false 
                });   
               }
              });
            });

            // Datepicker init
            $('.fc-popover.click .datetimepicker').datetimepicker({
                widgetPositioning: {
                    horizontal: 'right'
                }
            });

            $('.fc-popover.click .datetimepicker-2').datetimepicker({
                widgetPositioning: {
                    horizontal: 'right'
                },
                format: 'LT',
                debug: true
            });
            // Position popover
            function posPopover(){
                $('.fc-popover.click').css({
                    left: eventEl.offset().left + eventEl.outerWidth()/2,
                    top: eventEl.offset().top + eventEl.outerHeight()
                });
            }
            posPopover();
            $('.fc-scroller, .calendar-page-content, body').scroll(function(){
                posPopover();
            });
            $(window).resize(function(){
               posPopover();
            });
            // Remove old popover
            if ($('.fc-popover.click').length > 1) {
                for (var i = 0; i < ($('.fc-popover.click').length - 1); i++) {
                    $('.fc-popover.click').eq(i).remove();
                }
            }
            // Close buttons
            $('.fc-popover.click .cl, .fc-popover.click .remove-popover').click(function(){
                $('.fc-popover.click').remove();
                $('.fc-event').removeClass('event-clicked');
            });
            // Actions link
            $('.fc-event-action-edit').click(function(e){
                e.preventDefault();
                $('.fc-popover.click .main-screen').hide();
                $('.fc-popover.click .edit-event').show();
            });
            $('.fc-event-action-remove').click(function(e){
                e.preventDefault();
                $('.fc-popover.click .main-screen').hide();
                $('.fc-popover.click .remove-confirm').show();
            });
          }
      });


//datetipecker
   $(function () {
     $('#side-datetimepicker').datetimepicker({
     inline: true,
     format: 'YYYY/MM/DD',
     widgetPositioning: {
          horizontal: 'right'
        }
         });
     });

  $(function () {
    $('.datetimepicker-1').datetimepicker({
        widgetPositioning: {
          horizontal: 'right'
        },
      debug: false
   });

 });
 
 $(function () {
    $('.datetimepicker-2').datetimepicker({
      format: 'DD/MM/YYYY',
       widgetPositioning: {
          horizontal: 'right'
        },
      debug: false
   });
 });

$(function () {
  $('.datetimepicker-3').datetimepicker({
    widgetPositioning: {
      horizontal: 'right'
    },
    format: 'LT',
    debug: false
  });
});


(function($, viewport){
    $(document).ready(function() {

        if(viewport.is('>=lg')) {
            $('.calendar-page-content, .calendar-page-side').matchHeight();
        }
        $(window).resize(
            viewport.changed(function() {
                if(viewport.is('<lg')) {
                    $('.calendar-page-content, .calendar-page-side').matchHeight({ remove: true });
                }
            })
        );
    });
});
//FIM CAIXA

function formatDate(data, formato) {
  if (formato == '') {
    return (data.substr(0, 10).split('-').reverse().join('/'));
  } else {
    return (data.substr(0, 10).split('/').reverse().join('-'));
  }
}
    function imprime_2via(id){
      $(".fc-popover").hide();
      var randomico=$('#randomico').val();
      var codigo = randomico+btoa(id);
      window.open('imprimir/recibo?@='+codigo, '_blank');
    }

    function voltar(){
      document.getElementById("valor_entrada").disabled = true;
      document.getElementById("parcelamento").disabled = true;
      document.getElementById('forma_pagamento').disabled = true;
      document.getElementById('desconto').disabled = true;
      document.getElementById('avista').disabled = false;
      document.getElementById('parcelar').disabled = false;
      document.getElementById('forma_pagamento_entrada').disabled = true;
      $('.a').remove();
      $('.b').remove();
      $('.c').remove();
      $('.d').remove();
      $('.e').remove();
      $('.f').remove();
      $('.g').remove();
      $('.titlecobrar').remove();
      $('.titleavista').remove();
      $('.titleparcelar').remove();
      $('#avista').prop('checked', false);
      $('#parcelar').prop('checked', false);
      $('#titulo').append("<h4 class='modal-title titlecobrar'>Cobrar Fatura</h4>");
      var id= $('#id').val();
      $.post('../models/CaixaBusca.php', { id: id },
      function(data) {
      data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.  
      $('#id').val(data[0].id);
      $('#valor_final').val(data[0].valor_final);
      $('#valor_final2').val(parseFloat(data[0].valor_final).toLocaleString('pt-br', {minimumFractionDigits: 2}));
      $('#somaTotal').val(parseFloat(data[0].valor_total).toLocaleString('pt-br', {minimumFractionDigits: 2}));
      $('#valor_parcela').val(parseFloat(data[0].valor_parcela).toLocaleString('pt-br', {minimumFractionDigits: 2}));
      $('#parcelamento').val(data[0].parcelamento);
      $('#valor_entrada').val(parseFloat(data[0].valor_entrada).toLocaleString('pt-br', {minimumFractionDigits: 2}));
      $('#desconto').val(data[0].desconto);
      $('.opParcelar').remove();
      $('.opDinheiro').remove();
      $('.opDebito').remove();
      $('.boletos').remove();
      $('.cheque').remove();
      $('.op5').remove();
      $('.op6').remove();
      $('.op7').remove();
      $('.op8').remove();
      $('.op9').remove();
      $('.opSelecione').remove();
      $('#forma_pagamento_entrada').append('<option class="op5" value="'+data[0].forma_pagamento_entrada+'">'+data[0].forma_pagamento_entrada+'</option>'+'<option class="op7" value="Dinheiro">Dinheiro</option><option class="op8" value="Cartão de Débito">Cartão de Débito</option><option class="op9" value="Cartão de Crédito">Cartão de Crédito</option>');
      $('#forma_pagamento').append('<option class="op1" value="'+data[0].forma_pagamento+'">'+data[0].forma_pagamento+'</option>'+'<option class="op2" value="Dinheiro">Dinheiro</option>'+'<option class="op3" value="Cartão de Crédito">Cartão de Crédito</option>'+'<option class="op4" value="Cartão de Débito">Cartão de Débito</option>');
      
      if (data[0].forma_pagamento == "Dinheiro") {
          document.getElementById('recebido').disabled = false;
          document.getElementById('troco').disabled = false;
          $('.avista').show();
          $('.boleto').hide();
          $('.cheques').hide();
          $('.opSelecione').remove();
          $('.cartao_credito').hide();
          $('.valorRestante').hide();
          $('.del').hide();
          $('.cf').hide();
          $('#botoes').append("<button class='btn btn-rounded btn-inline btn-default f' data-dismiss='modal'>Cancelar</button><button class='btn btn-rounded btn-inline btn-success-outline c' onclick='dinheiro()'>Confirmar</button>");
        }
        else if (data[0].forma_pagamento == "Cartão de Débito") {
          $('.avista').hide();
          $('.boleto').hide();
          $('.cheques').hide();
          $('.opSelecione').remove();
          $('.cartao_credito').hide();
          $('.valorRestante').hide();
          $('.del').hide();
          $('.cf').hide();
          $('#botoes').append("<button class='btn btn-rounded btn-inline btn-default f' data-dismiss='modal'>Cancelar</button><button id='btnSend' class='btn btn-rounded btn-inline btn-success-outline c ok' onclick='cartaoDebito()'>Confirmar</button>");
        }
        else if (data[0].forma_pagamento == "Cartão de Crédito") {
          $('.avista').hide();
          $('.boleto').hide();
          $('.cheques').hide();
          $('.opSelecione').remove();
          $('.cartao_credito').show();
          $('.valorRestante').hide();
          $('.del').hide();
          $('.cf').hide();
          $('#botoes').append("<button class='btn btn-rounded btn-inline btn-default f' data-dismiss='modal'>Cancelar</button><button id='btnSend' class='btn btn-rounded btn-inline btn-success-outline c ok' onclick='cartaoCredito()'>Confirmar</button>");

        }
        else if(data[0].forma_pagamento == "Boleto Bancário"){
          $('.avista').hide();
          $('.boleto').show();
          $('.cheques').hide();
          $('.opSelecione').remove();
          $('.cartao_credito').hide();
          $('.valorRestante').hide();
          $('.del').hide();
          $('.cf').hide();
          document.getElementById('data_boleto').disabled = false;
          document.getElementById('id_lote').disabled = false;
          $('#botoes').append("<button class='btn btn-rounded btn-inline btn-default f' data-dismiss='modal'>Cancelar</button><button class='btn btn-rounded btn-inline btn-success-outline c' onclick='gerarBoletos()'>Gerar Boletos</button>");
        }
        else if(data[0].forma_pagamento == "Cheque"){
          $('.avista').hide();
          $('.boleto').hide();
          $('.opSelecione').remove();
          $('.cartao_credito').hide();
          $('.cheques').show();
          $('.valorRestante').show();
          $('.g').show();
          $('.del').show();
          $('.cf').show();
          $('#botoes').append("<button class='btn btn-rounded btn-inline btn-default f' data-dismiss='modal' onclick='cheq()'>Cancelar</button><button type='button' class='g btn btn-rounded btn-inline btn-primary' id='add_Cheques' onclick='addCheque()'><i class='fa fa-plus'></i> Cheque</button>");
        }
        else{
          $('.avista').show();
          $('.boleto').hide();
          $('.cheques').hide();
          $('.opSelecione').remove();
          $('.cartao_credito').hide();
          $('.valorRestante').hide();
          $('#botoes').append("<button class='btn btn-rounded btn-inline btn-default f' data-dismiss='modal'>Cancelar</button><button class='btn btn-rounded btn-inline btn-success-outline c' onclick='convenios()'>Confirmar</button>");
        }
      });
    }

   function desabilita(){ 
      if(document.getElementById('avista').checked){     
         document.getElementById("valor_entrada").disabled = true;
         document.getElementById("parcelamento").disabled = true;
         document.getElementById('avista').disabled = true;
         document.getElementById('parcelar').disabled = false;
         document.getElementById('forma_pagamento').disabled = false;
         document.getElementById('desconto').disabled = false;
         document.getElementById('forma_pagamento_entrada').disabled = false;
         var subTotal=$('#somaTotal').val();
         $('#titulo').append("<h4 class='modal-title titleavista'>Alterar Fatura</h4>");
         $('.titlecobrar').remove();
         $('.titleparcelar').remove();
         $('#parcelamento').val("1");
         $('#valor_parcela').val(subTotal);
         $('#valor_final2').val(subTotal);
         $('#valor_entrada').val("");
         $('#desconto').val("");
         $('.valorRestante').hide();
         $('.avista').hide();
         $('.b').remove(); 
         $('.c').remove();
         $('.e').remove();
         $('.f').remove();
         $('.g').remove();
         $('.op1').remove();
         $('.op2').remove();
         $('.op3').remove();
         $('.op4').remove();
         $('.op5').remove();
         $('.op6').remove();
         $('.op7').remove();
         $('.op8').remove();
         $('.op9').remove();
         $('.cheques').hide();
         $('.del').hide();
         $('.cf').hide();
         $('.opSelecione').remove();
         $('.opDinheiro').remove();
         $('.opParcelar').remove();
         $('.opDebito').remove();
         $('.boletos').remove();
         $('.cheque').remove();
         $('#forma_pagamento').append('<option class="opSelecione">Selecione a Forma de Pagamento</option><option class="opDinheiro" value="Dinheiro">Dinheiro</option><option class="opDebito" value="Cartão de Débito">Cartão de Débito</option><option class="cheque" value="Cheque">Cheque</option>');
         $('#forma_pagamento_entrada').append('<option class="op6" value="">Forma de Pagamento da Entrada</option><option class="op7" value="Dinheiro">Dinheiro</option><option class="op8" value="Cartão de Débito">Cartão de Débito</option><option class="op9" value="Cartão de Crédito">Cartão de Crédito</option>');
         $('#botoes').append("<button class='btn btn-rounded btn-inline btn-default d' data-dismiss='modal' onclick='voltar()'>Cancelar</button><button class='btn btn-rounded btn-inline btn-success-outline a' onclick='mudarFormaPagto()'>Salvar</button>");
      
      }
      if(document.getElementById('parcelar').checked){
         document.getElementById("valor_entrada").disabled = false;
         document.getElementById("parcelamento").disabled = false;
         document.getElementById('avista').disabled = false;
         document.getElementById('parcelar').disabled = true;
         document.getElementById('forma_pagamento').disabled = false;
         document.getElementById('desconto').disabled = false;
         document.getElementById('forma_pagamento_entrada').disabled = false;
         $('#titulo').append("<h4 class='modal-title titleparcelar'>Alterar Fatura</h4>");
         $('.titlecobrar').remove();
         $('.titleavista').remove();
         $('#parcelamento').val("1");
         $('#valor_parcela').val("");
         $('#valor_final2').val("");
         $('#valor_entrada').val("");
         $('#desconto').val("");
         $('.valorRestante').hide();
         $('.avista').hide();
         $('.a').remove();
         $('.c').remove();
         $('.d').remove();
         $('.f').remove();
         $('.g').remove();
         $('.op1').remove();
         $('.op2').remove();
         $('.op3').remove();
         $('.op4').remove();
         $('.op5').remove();
         $('.op6').remove();
         $('.op7').remove();
         $('.op8').remove();
         $('.op9').remove();
         $('.cheques').hide();
         $('.del').hide();
         $('.cf').hide();
         $('.opSelecione').remove();
         $('.opDinheiro').remove();
         $('.opParcelar').remove();
         $('.opDebito').remove();
         $('.boletos').remove();
         $('.cheque').remove();
         $('#forma_pagamento_entrada').append('<option class="op6" value="">Forma de Pagamento da Entrada</option><option class="op7" value="Dinheiro">Dinheiro</option><option class="op8" value="Cartão de Débito">Cartão de Débito</option><option class="op9" value="Cartão de Crédito">Cartão de Crédito</option>');
         $('#forma_pagamento').append('<option class="opSelecione">Selecione a Forma de Pagamento</option><option class="opDinheiro" value="Dinheiro">Dinheiro</option><option class="opDebito" value="Cartão de Débito">Cartão de Débito</option><option class="opParcelar" value="Cartão de Crédito">Cartão de Crédito</option><option class="boletos" value="Boleto Bancário">Boleto Bancário</option><option class="cheque" value="Cheque">Cheque</option>');
         $('#botoes').append("<button class='btn btn-rounded btn-inline btn-default e' data-dismiss='modal' onclick='voltar()'>Cancelar</button><button class='btn btn-rounded btn-inline btn-success-outline b' onclick='mudarFormaPagto()'>Salvar</button>");
         }
       }

         $('#titulo').append("<h4 class='modal-title titlecobrar'>Cobrar Fatura</h4>");
         $('#convenio').val("Particular");
         $('#avista').attr('checked','checked');
         $('#parcelamento').val("1");
         document.getElementById("valor_entrada").disabled = true;
         document.getElementById("parcelamento").disabled = true;
         document.getElementById('forma_pagamento').disabled = true;
         document.getElementById('desconto').disabled = true;
         document.getElementById('forma_pagamento_entrada').disabled = true;


     // FUNCAO COBRAR FATURA NO CAIXA
     function cobrarFatura(id){
         var id= id
         $.post('../models/CaixaBusca.php', { id: id },
         function(data) {
         data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.  
         $('#id').val(data[0].id);
         $('#id_usuario').val(data[0].id_usuario);
         $('#id_paciente').val(data[0].id_paciente);
         $('#dentista').val(data[0].dentista);
         $('#id_fatura').val(data[0].id);
         $('.id_fatura').val(data[0].id);
         $('.id_usuario').val(data[0].id_usuario);
         $('.id_paciente').val(data[0].id_paciente);
         $('#plano').append('<option value="'+data[0].plano+'">'+data[0].plano+'</option>'+'<option value="Particular">Particular</option>'+'<option value="Convênio">Convênio</option>');
         $('#convenio').val(data[0].convenio);
         $('#valor_final').val(data[0].valor_final);
         $('#valor_final2').val(parseFloat(data[0].valor_final).toLocaleString('pt-br', {minimumFractionDigits: 2}));
         $('#valor_restante').val(parseFloat(data[0].valor_restante).toLocaleString('pt-br', {minimumFractionDigits: 2}));
         $('#somaTotal').val(parseFloat(data[0].valor_total).toLocaleString('pt-br', {minimumFractionDigits: 2}));
         $('#valor_parcela').val(parseFloat(data[0].valor_parcela).toLocaleString('pt-br', {minimumFractionDigits: 2}));
         $('#parcelamento').val(data[0].parcelamento);
         $('#desconto').val(data[0].desconto);
         $('.opSelecione').remove();
         $('.opParcelar').remove();
         $('.opDinheiro').remove();
         $('.opDebito').remove();
         $('.boletos').remove();
         $('.cheque').remove();
         $('.op1').remove();
         $('.op2').remove();
         $('.op3').remove();
         $('.op4').remove();
         $('.op5').remove();
         $('.op6').remove();
         $('.op7').remove();
         $('.op8').remove();
         $('.op9').remove();
         $('#forma_pagamento').append('<option class="op1" value="'+data[0].forma_pagamento+'">'+data[0].forma_pagamento+'</option>');
         $('#forma_pagamento_entrada').append('<option class="op5" value="'+data[0].forma_pagamento_entrada+'">'+data[0].forma_pagamento_entrada+'</option>');
       
         if(data[0].valor_entrada == 0.00){
           $('#valor_entrada').val("");
         }
         else{
           $('#valor_entrada').val(parseFloat(data[0].valor_entrada).toLocaleString('pt-br', {minimumFractionDigits: 2}));
         }

        if(data[0].forma_pagamento == "Dinheiro") {
           document.getElementById('recebido').disabled = false;
           document.getElementById('troco').disabled = false;
           $('.avista').show();
           $('.boleto').hide();
           $('.cheques').hide();
           $('.valorRestante').hide();
           $('.cartao_credito').hide();
           $('.del').hide();
           $('.cf').hide();

           $('#botoes').append("<button class='btn btn-rounded btn-inline btn-default f' data-dismiss='modal'>Cancelar</button><button class='btn btn-rounded btn-inline btn-success-outline c' onclick='dinheiro()'>Confirmar</button>");
        }
        else if (data[0].forma_pagamento == "Cartão de Débito") {
            $('.avista').hide();
            $('.boleto').hide();
            $('.cheques').hide();
            $('.cartao_credito').hide();
            $('.valorRestante').hide();
            $('.del').hide();
            $('.cf').hide();
            $('#botoes').append("<button class='btn btn-rounded btn-inline btn-default f' data-dismiss='modal'>Cancelar</button><button id='btnSend' class='btn btn-rounded btn-inline btn-success-outline c ok' onclick='cartaoDebito()'>Confirmar</button>");

        }
        else if (data[0].forma_pagamento == "Cartão de Crédito") {
            $('.avista').hide();
            $('.boleto').hide();
            $('.cheques').hide();
            $('.cartao_credito').show();
            $('.valorRestante').hide();
            $('.del').hide();
            $('.cf').hide();
            $('#botoes').append("<button class='btn btn-rounded btn-inline btn-default f' data-dismiss='modal'>Cancelar</button><button id='btnSend' class='btn btn-rounded btn-inline btn-success-outline c ok' onclick='cartaoCredito()'>Confirmar</button>");

        }
        else if(data[0].forma_pagamento == "Boleto Bancário"){
            $('.avista').hide();
            $('.boleto').show();
            $('.cheques').hide();
            $('.cartao_credito').hide();
            $('.valorRestante').hide();
            $('.del').hide();
            $('.cf').hide();
            document.getElementById('data_boleto').disabled = false;
            document.getElementById('id_lote').disabled = false;
            $('#botoes').append("<button class='btn btn-rounded btn-inline btn-default f' data-dismiss='modal'>Cancelar</button><button class='btn btn-rounded btn-inline btn-success-outline c' onclick='gerarBoletos()'>Gerar Boletos</button>");
        }
        else if(data[0].forma_pagamento == "Cheque"){
            $('.avista').hide();
            $('.boleto').hide();
            $('.cartao_credito').hide();
            $('.cheques').show();
            $('.valorRestante').show();
            $('.del').show();
            $('.cf').show();
            $('#botoes').append("<button class='btn btn-rounded btn-inline btn-default f' data-dismiss='modal' onclick='cheq()'>Cancelar</button><button type='button' class='g btn btn-rounded btn-inline btn-primary' id='add_Cheques' onclick='addCheque()'><i class='fa fa-plus'></i> Cheque</button>");

        }
        else{
            $('.avista').show();
            $('.boleto').hide();
            $('.cheques').hide();
            $('.valorRestante').hide();
            $('.cartao_credito').hide();
            $('#botoes').append("<button class='btn btn-rounded btn-inline btn-default f' data-dismiss='modal'>Cancelar</button><button class='btn btn-rounded btn-inline btn-success-outline c' onclick='convenios()'>Confirmar</button>");

        }

        if(data[0].forma_pagamento == "Convênio"){
           $('#avista').prop('disabled', true);
           $('#parcelar').prop('disabled', true);
           document.getElementById("valor_entrada").disabled = true;
           document.getElementById("parcelamento").disabled = true;
           document.getElementById('forma_pagamento').disabled = true;
           document.getElementById('desconto').disabled = true;
           document.getElementById("valor_final2").disabled = true;
           document.getElementById('recebido').disabled = true;
           document.getElementById('troco').disabled = true;
           document.getElementById('forma_pagamento_entrada').disabled = true;
        }

        for(var i=0; data.length > i; i++){
            $('#procedimentos_aprovados').append('<div>'+data[i].procedimentos_aprovados+'</div>');
           }

         if(data[0].valor_restante == 0){
             ChequeLiquidou();       
         }

        });
          $('#avista').prop('checked', false);
          $('#parcelar').prop('checked', false);
          $(".fc-popover").hide();
          $('.f').hide();
          $('.c').hide();
          $('.g').remove();
          $('#cobrarFatura').modal('show');


     }            
    

    //FUNCAO PARA ALTERAR OS MEIOS DE PAGAMENTO
    function mudarFormaPagto(){
        var id=$('#id').val();
        var randomico=$('#randomico').val();
        var codigo = randomico+btoa(id);
        var plano=$('#plano').val();
        var convenio=$('#convenio').val();
        var valor_total=$('#somaTotal').val();
        var parcelamento=$('#parcelamento').val();
        var valor_entrada=$('#valor_entrada').val();
        var desconto=$('#desconto').val();
        var forma_pagamento=$('#forma_pagamento').val();
        var forma_pagamento_entrada=$('#forma_pagamento_entrada').val();
        if(forma_pagamento == "Selecione a Forma de Pagamento"){
        swal({
          title: 'Selecione a Forma de Pagamento!',
          text: "O campo Forma de Pagamento é Obrigatório!",
          type: 'warning',
          showCancelButton: false,
          showConfirmButton: false,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Sim',
          cancelButtonText: "Cancelar",   
          closeOnConfirm: false,   
          closeOnCancel: false,
          timer:1800
          });
        }
        else{
        $.ajax({
          url: '../controllers/Orcamentos.php',
          type: 'POST',
          data:'id='+id+'&plano='+plano+'&convenio='+convenio+'&valor_total='+valor_total+'&parcelamento='+parcelamento+'&valor_entrada='+valor_entrada+'&desconto='+desconto+'&forma_pagamento='+forma_pagamento+'&forma_pagamento_entrada='+forma_pagamento_entrada+'&botao=mudarFormaPagamento'
        }).done(function(resposta){
        $.post('../models/CaixaBusca.php', { id: id },
        function(data) {
           data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.  
           $('#id').val(data[0].id);
           $('#convenio').val(data[0].convenio);
           $('#valor_final').val(data[0].valor_final);
           $('#valor_final2').val(parseFloat(data[0].valor_final).toLocaleString('pt-br', {minimumFractionDigits: 2}));
           $('#valor_restante').val(parseFloat(data[0].valor_restante).toLocaleString('pt-br', {minimumFractionDigits: 2}));
           $('#somaTotal').val(parseFloat(data[0].valor_total).toLocaleString('pt-br', {minimumFractionDigits: 2}));
           $('#valor_parcela').val(parseFloat(data[0].valor_parcela).toLocaleString('pt-br', {minimumFractionDigits: 2}));
           $('#parcelamento').val(data[0].parcelamento);
           $('#valor_entrada').val(parseFloat(data[0].valor_entrada).toLocaleString('pt-br', {minimumFractionDigits: 2}));
           $('#desconto').val(data[0].desconto);
         });

           document.getElementById('avista').disabled = false;
           document.getElementById('parcelar').disabled = false;
           document.getElementById('valor_final2').disabled = true;
           document.getElementById('somaTotal').disabled = true;
           document.getElementById('valor_parcela').disabled = true;
           document.getElementById('parcelamento').disabled = true;
           document.getElementById('valor_entrada').disabled = true;
           document.getElementById('forma_pagamento').disabled = true;
           document.getElementById('desconto').disabled = true;
           document.getElementById('forma_pagamento_entrada').disabled = true;
           $('.a').remove();
           $('.b').remove();
           $('.d').remove();
           $('.e').remove();
           $('.g').remove();
           $('.opSelecione').remove();
           $('.opSelecione').remove();
           $('.titleavista').remove();
           $('.titleparcelar').remove();
           $('#avista').prop('checked', false);
           $('#parcelar').prop('checked', false);
           $('#titulo').append("<h4 class='modal-title titlecobrar'>Cobrar Fatura</h4>");
      
          if (forma_pagamento == "Dinheiro") {
              document.getElementById('recebido').disabled = false;
              document.getElementById('troco').disabled = false;
              $('.avista').show();
              $('.boleto').hide();
              $('.cheques').hide();
              $('.cartao_credito').hide();
              $('.valorRestante').hide();
              $('.del').hide();
              $('.cf').hide();
              $('#botoes').append("<button class='btn btn-rounded btn-inline btn-default f' data-dismiss='modal'>Cancelar</button><button class='btn btn-rounded btn-inline btn-success-outline c' onclick='dinheiro()'>Confirmar</button>");
              
           }
           else if (forma_pagamento == "Cartão de Débito") {
              $('.avista').hide();
              $('.boleto').hide();
              $('.cheques').hide();
              $('.cartao_credito').hide();
              $('.valorRestante').hide();
              $('.del').hide();
              $('.cf').hide();
              $('#botoes').append("<button class='btn btn-rounded btn-inline btn-default f' data-dismiss='modal'>Cancelar</button><button id='btnSend' class='btn btn-rounded btn-inline btn-success-outline c ok' onclick='cartaoDebito()'>Confirmar</button>");

           }
           else if (forma_pagamento == "Cartão de Crédito") {
              $('.avista').hide();
              $('.boleto').hide();
              $('.cheques').hide();
              $('.cartao_credito').show();
              $('.valorRestante').hide();
              $('.del').hide();
              $('.cf').hide();
              $('#botoes').append("<button class='btn btn-rounded btn-inline btn-default f' data-dismiss='modal'>Cancelar</button><button id='btnSend' class='btn btn-rounded btn-inline btn-success-outline c ok' onclick='cartaoCredito()'>Confirmar</button>");

            }
            else if(forma_pagamento == "Boleto Bancário"){
              $('.avista').hide();
              $('.boleto').show();
              $('.cheques').hide();
              $('.cartao_credito').hide();
              $('.valorRestante').hide();
              $('.del').hide();
              $('.cf').hide();
              document.getElementById('data_boleto').disabled = false;
              document.getElementById('id_lote').disabled = false;
              $('#botoes').append("<button class='btn btn-rounded btn-inline btn-default f' data-dismiss='modal'>Cancelar</button><button class='btn btn-rounded btn-inline btn-success-outline c' onclick='gerarBoletos()'>Gerar Boletos</button>");
           }
           else if(forma_pagamento == "Cheque"){
              $('.avista').hide();
              $('.boleto').hide();
              $('.cartao_credito').hide();
              $('.valorRestante').show();
              $('.cheques').show();
              $('.del').show();
              $('.cf').show();
              $('#botoes').append("<button class='btn btn-rounded btn-inline btn-default f' data-dismiss='modal' onclick='cheq()'>Cancelar</button><button type='button' class='g btn btn-rounded btn-inline btn-primary' id='add_Cheques' onclick='addCheque()'><i class='fa fa-plus'></i> Cheque</button>");

           }
           else{
              $('.avista').show();
              $('.boleto').hide();
              $('.cheques').hide();
              $('.cartao_credito').hide();
              $('.valorRestante').hide();
              $('#botoes').append("<button class='btn btn-rounded btn-inline btn-default f' data-dismiss='modal'>Cancelar</button><button class='btn btn-rounded btn-inline btn-success-outline c' onclick='convenios()'>Confirmar</button>");
             }
            }); 
           }
         }
       
           //FUNCAO CALCULAR TROCO PDV
           $(document).ready(function() {
             $("#valor_final,#recebido").on('keyup', function() {
              var recebido = $("#recebido").val().replace(/[.]/g, "").replace(",", ".");
              var valor_final = $("#valor_final").val();
              var trocoCalculado = recebido - valor_final;
              if(recebido == ""){
              $('#troco').val("");
              }
              else{
              $('#troco').val(parseFloat(trocoCalculado).toLocaleString('pt-br', {minimumFractionDigits: 2}));
              }
            });
          });



          //FUNCAO COBRAR COM DINHEIRO, AQUI SO DA BAIXA NO SISTEMA E TEM A OPCAO DE TROCO  
          function dinheiro(){
             var id=$('#id').val();
             var randomico=$('#randomico').val();
             var codigo = randomico+btoa(id);
             $('#cobrarFatura').modal('hide');
              swal({
              title: 'Você tem certeza?',
              text: "Deseja cobrar a fatura e contabilizar? ",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Sim',
              cancelButtonText: "Cancelar",   
              closeOnConfirm: false,   
              closeOnCancel: false
             },
             function(isConfirm){  
             if(isConfirm){
               $.ajax({
                 url: '../controllers/Orcamentos.php',
                 type: 'POST',
                 data:'id='+id+'&botao=finalizarVenda'
               });
              $("#caixa").fullCalendar( 'refetchEvents' );  
              swal({
              title: 'Fatura cobrada com sucesso!',
              text: "Deseja emitir o recibo?",
              type: 'success',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Sim',
              cancelButtonText: "Cancelar",   
              closeOnConfirm: true,   
              closeOnCancel: true
             },
             function(isConfirm){   
             if(isConfirm){     
                window.open('imprimir/recibo?@='+codigo, '_blank');
                $("#caixa").fullCalendar( 'refetchEvents' );
                Atualizar();
             }
             else{     
              swal({
              title: "Processo Cancelado!",
              text: "Recibo não Impresso!",
              type: "error",
              timer: 1700,
              showCancelButton: false, 
              showConfirmButton: false 
              });  
                $("#caixa").fullCalendar( 'refetchEvents' );
                Atualizar();
                }
              });
             }
             else{     
              swal({
              title: "Processo Cancelado!",
              text: "A fatura ficou Pendente",
              type: "error",
              timer: 1700,
              showCancelButton: false, 
              showConfirmButton: false 
              });  
              $("#caixa").fullCalendar( 'refetchEvents' );
              Atualizar();
              }
            });
          }

          //FUNCAO COBRAR COM CARTAO DE DEBITO VIA MAQUINA, AQUI SO DA BAIXA NO SISTEMA 
          function cartaoDebito(){
            var id=$('#id').val();
            var randomico=$('#randomico').val();
            var codigo = randomico+btoa(id);
            $('#cobrarFatura').modal('hide');
            $("#load_meio_pgto").modal('show');
            var channel;
            do {
               channel = $('#tokenPagSeguro').val();
            } while(channel == null || channel == '');

            var plugpag = new PlugPag(channel);
            operation = $('#operation').val();
            forma_pagamento = $('#forma_pagamento').val();

            if (forma_pagamento == "Cartão de Crédito"){
                 method = "1";
            }
            else if(forma_pagamento == "Cartão de Débito"){
                 method = "2";
            }
            else if(forma_pagamento == "Voucher"){
                 method = "3";
            }
            else{
                 method = "0";
            }

            installments = "1";
            installment = $('#parcelamento').val();
            amount = $('#valor_final').val();
            $('#btnSend').attr('disabled', true);
            plugpag.payment(method, installments, installment, amount, function(data, error) {
            $('#btnSend').removeAttr('disabled');
             console.log('Erro na operação:', error);
             console.log('Dados de retorno da transação:', data);
             var erros = data["error_value"];
             var resultado = data["message"];

                if (resultado == "Transacao nao realizada"){
                   $("#load_meio_pgto").modal('hide');
                    swal({
                     title: "Transação Cancelada!",
                     text: "Transacao não realizada",
                     type: "error",
                     timer: 2100,
                     showCancelButton: false, 
                     showConfirmButton: false 
                    });  
                 }
              
                if(resultado == "Transacao realizada com sucesso"){
                  $("#load_meio_pgto").modal('hide');
                    $.ajax({
                     url: '../controllers/Orcamentos.php',
                     type: 'POST',
                     data:'id='+id+'&botao=finalizarVenda'
                    });
                    $("#caixa").fullCalendar( 'refetchEvents' ); 
                    swal({
                     title: 'Fatura cobrada com Sucesso!',
                     text: "Deseja emitir o recibo?",
                     type: 'success',
                     showCancelButton: true,
                     confirmButtonColor: '#3085d6',
                     cancelButtonColor: '#d33',
                     confirmButtonText: 'Sim',
                     cancelButtonText: "Cancelar",   
                     closeOnConfirm: true,   
                     closeOnCancel: true
                     },
                     function(isConfirm){   
                     if(isConfirm){     
                        window.open('imprimir/recibo?@='+codigo, '_blank');
                        $("#caixa").fullCalendar( 'refetchEvents' );
                        Atualizar();
                     }
                     else{     
                      swal({
                       title: "Processo Cancelado!",
                       text: "Recibo não Impresso!",
                       type: "error",
                       timer: 1700,
                       showCancelButton: false, 
                       showConfirmButton: false 
                      });  
                        $("#caixa").fullCalendar( 'refetchEvents' );
                        Atualizar();
                        }
                    }); 
                 }
                 
                if(erros == "-2001"){
                  $("#load_meio_pgto").modal('hide');
                  swal({
                     title: 'Sua Máquina de cartão não está Conectada!',
                     text: "Deseja realizar a transação somente no sistema?",
                     type: 'warning',
                     showCancelButton: true,
                     confirmButtonColor: '#3085d6',
                     cancelButtonColor: '#d33',
                     confirmButtonText: 'Sim',
                     cancelButtonText: "Cancelar",   
                     closeOnConfirm: false,   
                     closeOnCancel: false
                   },
                   function(isConfirm){  
                   if(isConfirm){
                      $.ajax({
                        url: '../controllers/Orcamentos.php',
                        type: 'POST',
                        data:'id='+id+'&botao=finalizarVenda'
                      });
                    $("#caixa").fullCalendar( 'refetchEvents' ); 
                    swal({
                     title: 'Fatura cobrada com sucesso!',
                     text: "Deseja emitir o recibo?",
                     type: 'success',
                     showCancelButton: true,
                     confirmButtonColor: '#3085d6',
                     cancelButtonColor: '#d33',
                     confirmButtonText: 'Sim',
                     cancelButtonText: "Cancelar",   
                     closeOnConfirm: true,   
                     closeOnCancel: true
                    },
                    function(isConfirm){   
                    if(isConfirm){     
                       window.open('imprimir/recibo?@='+codigo, '_blank');
                       $("#caixa").fullCalendar( 'refetchEvents' );
                       Atualizar();
                    }
                    else{     
                    swal({
                     title: "Processo Cancelado!",
                     text: "Recibo não Impresso!",
                     type: "error",
                     timer: 1700,
                     showCancelButton: false, 
                     showConfirmButton: false 
                    });  
                    $("#caixa").fullCalendar( 'refetchEvents' );
                    Atualizar();
                    }
                    });
                   }
                   else{     
                   swal({
                    title: "Processo Cancelado!",
                    text: "A fatura ficou Pendente",
                    type: "error",
                    timer: 1700,
                    showCancelButton: false, 
                    showConfirmButton: false 
                   });  
                   $("#caixa").fullCalendar( 'refetchEvents' );
                   Atualizar();
                  }
                });
               }
              });
            }
//         
          //FUNCAO COBRAR COM CARTAO DE CREDITO VIA API PAGSEGURO E MAQUINA (OBS: AQUI SALVE-SE OS DADOS DO CARTAO DE CREDITO)
          function cartaoCredito(){
            var id=$('#id').val();
            var randomico=$('#randomico').val();
            var codigo = randomico+btoa(id);
            $('#cobrarFatura').modal('hide');
            $("#load_meio_pgto").modal('show');
            var channel;
            do {
               channel = $('#tokenPagSeguro').val();
            } while(channel == null || channel == '');
            var plugpag = new PlugPag(channel);
            operation = $('#operation').val();
            forma_pagamento = $('#forma_pagamento').val();

            if (forma_pagamento == "Cartão de Crédito"){
                 method = "1";
            }
            else if(forma_pagamento == "Cartão de Débito"){
                 method = "2";
            }
            else if(forma_pagamento == "Voucher"){
                 method = "3";
            }
            else{
                 method = "0";
            }

            installments = "1";
            installment = $('#parcelamento').val();
            amount = $('#valor_final').val();
            $('#btnSend').attr('disabled', true);
            plugpag.payment(method, installments, installment, amount, function(data, error) {
            $('#btnSend').removeAttr('disabled');
             console.log('Erro na operação:', error);
             console.log('Dados de retorno da transação:', data);
             var erros = data["error_value"];
             var resultado = data["message"];
                
                if (resultado == "Transacao nao realizada"){
                   $("#load_meio_pgto").modal('hide');
                    swal({
                     title: "Transação Cancelada!",
                     text: "Transacao não realizada",
                     type: "error",
                     timer: 1700,
                     showCancelButton: false, 
                     showConfirmButton: false 
                    });  
                 }
              
                if(resultado == "Transacao realizada com sucesso"){
                  $("#load_meio_pgto").modal('hide');
                    $.ajax({
                     url: '../controllers/Orcamentos.php',
                     type: 'POST',
                     data:'id='+id+'&botao=finalizarVenda'
                    });
                    $("#caixa").fullCalendar( 'refetchEvents' ); 
                    swal({
                     title: 'Fatura cobrada com Sucesso!',
                     text: "Deseja emitir o recibo?",
                     type: 'success',
                     showCancelButton: true,
                     confirmButtonColor: '#3085d6',
                     cancelButtonColor: '#d33',
                     confirmButtonText: 'Sim',
                     cancelButtonText: "Cancelar",   
                     closeOnConfirm: true,   
                     closeOnCancel: true
                     },
                     function(isConfirm){   
                     if(isConfirm){     
                        window.open('imprimir/recibo?@='+codigo, '_blank');
                        $("#caixa").fullCalendar( 'refetchEvents' );
                        Atualizar();
                     }
                     else{     
                      swal({
                       title: "Processo Cancelado!",
                       text: "Recibo não Impresso!",
                       type: "error",
                       timer: 1700,
                       showCancelButton: false, 
                       showConfirmButton: false 
                      });  
                        $("#caixa").fullCalendar( 'refetchEvents' );
                        Atualizar();
                        }
                    }); 
                 }
                 
                if(erros == "-2001"){
                  $("#load_meio_pgto").modal('hide');
                  swal({
                     title: 'Sua Máquina de cartão não está Conectada!',
                     text: "Deseja realizar a transação somente no sistema?",
                     type: 'warning',
                     showCancelButton: true,
                     confirmButtonColor: '#3085d6',
                     cancelButtonColor: '#d33',
                     confirmButtonText: 'Sim',
                     cancelButtonText: "Cancelar",   
                     closeOnConfirm: false,   
                     closeOnCancel: false
                   },
                   function(isConfirm){  
                   if(isConfirm){
                      $.ajax({
                        url: '../controllers/Orcamentos.php',
                        type: 'POST',
                        data:'id='+id+'&botao=finalizarVenda'
                      });
                    $("#caixa").fullCalendar( 'refetchEvents' ); 
                    swal({
                     title: 'Fatura cobrada com sucesso!',
                     text: "Deseja emitir o recibo?",
                     type: 'success',
                     showCancelButton: true,
                     confirmButtonColor: '#3085d6',
                     cancelButtonColor: '#d33',
                     confirmButtonText: 'Sim',
                     cancelButtonText: "Cancelar",   
                     closeOnConfirm: true,   
                     closeOnCancel: true
                    },
                    function(isConfirm){   
                    if(isConfirm){     
                       window.open('imprimir/recibo?@='+codigo, '_blank');
                       $("#caixa").fullCalendar( 'refetchEvents' );
                       Atualizar();
                    }
                    else{     
                    swal({
                     title: "Processo Cancelado!",
                     text: "Recibo não Impresso!",
                     type: "error",
                     timer: 1700,
                     showCancelButton: false, 
                     showConfirmButton: false 
                    });  
                    $("#caixa").fullCalendar( 'refetchEvents' );
                    Atualizar();
                    }
                    });
                   }
                   else{     
                   swal({
                    title: "Processo Cancelado!",
                    text: "A fatura ficou Pendente",
                    type: "error",
                    timer: 1700,
                    showCancelButton: false, 
                    showConfirmButton: false 
                   });  
                   $("#caixa").fullCalendar( 'refetchEvents' );
                   Atualizar();
                  }
                });
               }
              });
             }
          //FUNCAO COBRAR COM BOLETOS VIA API PAGSEGURO, AQUI OS BOLETOS SAO GERADOS PARA IMPRESSAO OU ENVIO POR EMAIL 
          function gerarBoletos(){
           $('#cobrarFatura').modal('hide');
           $("#load_boletos").modal('show');
           var id=$('#id').val();
           var id_usuario = $('#id_usuario').val();
           var id_paciente = $('#id_paciente').val();
           var id_fatura = $('#id_fatura').val();
           var dentista = $('#dentista').val();
           $.post('../models/PacienteBusca.php', { id: id_paciente },
             function(data) {
             data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.  
             var nome = data[0].nome;
             var email = data[0].email;
             var cpf = data[0].cpf;
             var telefone = data[0].telefone_celular;
             var cep = data[0].cep;
             var rua = data[0].rua;
             var numero = data[0].numero;
             var bairro = data[0].bairro;
             var cidade = data[0].cidade;
             var uf = data[0].estado;
             var dt_boleto = formatDate($("#data_boleto").val());
             var procedimento = $("#id_lote").val();
             var juro_vencimento = $("#juro_vencimento").val();
             var mora_vencimento = $("#mora_vencimento").val();
             if (juro_vencimento == ""){
                var juro_mora_vencimento = "";
             } 
             else if(mora_vencimento == "") {
                var juro_mora_vencimento = "";
             }
             else{
                var juro_mora_vencimento = "Após o vencimento cobrar juros de "+juro_vencimento+"% ao dia e mora de R$ " + mora_vencimento;
             }
             var valor = $("#valor_parcela").val();
             var parcelas = $("#parcelamento").val();
             $.ajax({
                url:'../views/boleto.php',
                type:'POST',
                data:'nome='+nome+'&email='+email+'&cpf='+cpf+'&telefone='+telefone+'&cep='+cep+'&rua='+rua+'&numero='+numero+'&bairro='+bairro+'&cidade='+cidade+'&uf='+uf+'&dt_boleto='+dt_boleto+'&procedimento='+procedimento+'&juro_mora_vencimento='+juro_mora_vencimento+'&valor='+valor+'&parcelas='+parcelas+'&id='+id+'&id_usuario='+id_usuario+'&id_paciente='+id_paciente+'&id_fatura='+id_fatura+'&dentista='+dentista
              }).done(function(data){
                  $("#load_boletos").modal('hide');
                  $('#imprime').html(data);
                  $("#caixa").fullCalendar( 'refetchEvents' );
                  window.setTimeout(function () {
                    Atualizar();
                  }, 2500);
                  
                  if(data){
                    $("#load_boletos").modal('hide');
                    swal({
                    title: "Atenção",
                    text: "A data permitida para a emissão de boletos precisa ser no máximo em 30 dia para o vencimento e nunca retroativa!",
                    type: 'warning',
                    timer:5000,
                    showCancelButton: false, 
                    showConfirmButton: false 
                    });
                  }
               });
            });
          }     
  


          //FUNCAO PARA ADICIONAR CHEQUES, AQUI CADASTRA MAIS DE UM CHEQUE
          function addCheque(){
            var v_conta = parseFloat($("#valor_restante").val());
            var v_pago  =  parseFloat($("#valor").val());
            if(v_pago > v_conta){
              swal({
              title: "Processo Cancelado!",
              text: "Você não pode adicionar um Cheque com valor superior ao saldo devedor!",
              type: "error",
              timer: 1900,
              showCancelButton: false, 
              showConfirmButton: false 
              });
            }
            else{
            var id=$('#id').val();
            var randomico=$('#randomico').val();
            var codigo = randomico+btoa(id);
            $('#cobrarFatura').modal('hide');

            if (form_cheques.comp.value == "")
            {
            form_cheques.comp.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Comp do Cheque!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            }); 
            cobrarFatura(id);
            return (false);     
            }
            
            if (form_cheques.banco.value == "")
            {
            form_cheques.banco.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Banco do Cheque!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            }); 
            cobrarFatura(id);
            return (false);
            }
                      
            if (form_cheques.agencia.value == "")
            {
            form_cheques.agencia.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha a Agência do Cheque!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });
            cobrarFatura(id);
            return (false);
            }

            if (form_cheques.c1.value == "")
            {
            form_cheques.c1.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o C1 do Cheque!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });       
            cobrarFatura(id);
            return (false);
            }

            if (form_cheques.conta.value == "")
            {
            form_cheques.conta.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Nº da Conta do Cheque!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });               
            cobrarFatura(id);
            return (false);
            }

            if (form_cheques.c2.value == "")
            {
            form_cheques.c2.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o C2 do Cheque!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });               
            cobrarFatura(id);
            return (false);
            }

            if (form_cheques.serie.value == "")
            {
            form_cheques.serie.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha a Serie do Cheque!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });               
            cobrarFatura(id);
            return (false);
            }

            if (form_cheques.cheque_numero.value == "")
            {
            form_cheques.cheque_numero.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Nº do Cheque!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });               
            cobrarFatura(id);
            return (false);
            }

            if (form_cheques.c3.value == "")
            {
            form_cheques.c3.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o C3 do Cheque!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });               
            cobrarFatura(id);
            return (false);
            }


            if (form_cheques.valor.value == "")
            {
            form_cheques.valor.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Valor do Cheque!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });               
            cobrarFatura(id);
            return (false);
            }

            if (form_cheques.pre_datado.value == "")
            {
            form_cheques.pre_datado.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Pré-Datado do Cheque!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });               
            cobrarFatura(id);
            return (false);
            }

            if (form_cheques.titular.value == "")
            {
            form_cheques.titular.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Titular do Cheque!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });               
            cobrarFatura(id);
            return (false);
            }

            if (form_cheques.cpf_cnpj.value == "")
            {
            form_cheques.cpf_cnpj.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o CPF/CNPJ do Cheque!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });               
            cobrarFatura(id);
            return (false);
            }

            if (form_cheques.cliente_desde.value == "")
            {
            form_cheques.cliente_desde.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha Cliente Desde do Cheque!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });               
            cobrarFatura(id);
            return (false);
            }

            if (form_cheques.telefone.value == "")
            {
            form_cheques.telefone.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha Telefone do Titular do Cheque!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });               
            cobrarFatura(id);
            return (false);
            }
            swal({
              title: 'Você tem certeza?',
              text: "Deseja adicionar o Cheque?",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Sim',
              cancelButtonText: "Cancelar",   
              closeOnConfirm: false,   
              closeOnCancel: false
             },
             function(isConfirm){   
             if(isConfirm){ 
              var dados = $( "#form_cheques" ).serialize();
              $.ajax({
                url: "../controllers/Cheques.php",
                type: "POST",
                data: dados
              });
              //AJAX QUE DIMINUI O VALOR DADO EM CHEQUE MENOS O VALOR FINAL
              var valor_restante=$("#valor_restante").val().replace(/[.]/g, "").replace(",", ".");
              var valor=$("#valor").val().replace(/[.]/g, "").replace(",", ".");
              var valor_final =  valor_restante - valor;
              $.ajax({
                url: '../controllers/Orcamentos.php',
                type: "POST",
                data:'id='+id+'&valor_final='+valor_final+'&botao=valorRestante'
              });

                //AJAX QUE ATUALIZA O VALOR NO INPUT TOTAL
              $.post('../models/CaixaBusca.php', { id: id },
                function(data) {
                  data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.  
                  $('#id').val(data[0].id);
                  $('#valor_restante').val(parseFloat(data[0].valor_restante).toLocaleString('pt-br', {minimumFractionDigits: 2}));
                  $("#caixa").fullCalendar( 'refetchEvents' ); 
                  valorRestante(id);
               });  
                           
              $("#form_cheques input").each(function(){
               $(this).val("");
              });
             }
             else{     
              swal({
              title: "Processo Cancelado!",
              text: "Cheque não adicionado",
              type: "error",
              timer: 1700,
              showCancelButton: false, 
              showConfirmButton: false 
              });  
              }
            });
          }
        }
         //FUNCAO QUE MOSTRA ALERT DE CHEQUE ADICIONADO COM VALOR PENDENTE!
           function valorRestante(id){
              var valor_restante=$('#valor_restante').val();
              swal({
              title: "Cheque adicionado com sucesso!",
              text: "Porém resta um débito de " + parseFloat(valor_restante).toLocaleString('pt-br', {minimumFractionDigits: 2}) + " em aberto!",
              type: 'success'
              });
              cobrarFatura(id);
           }
          //FUNCAO COBRA E MUDA O STATUS PARA EM ANÁLISE, QUANDO O VALOR TOTAL FOR LIQUIDADO COM OS CHEQUES
          function ChequeLiquidou(id){
             var id=$('#id').val();
             var randomico=$('#randomico').val();
             var codigo = randomico+btoa(id);
             $('#cobrarFatura').modal('hide');
               $.ajax({
                 url: '../controllers/Orcamentos.php',
                 type: 'POST',
                 data:'id='+id+'&botao=finalizarVenda2'
               });
              $("#caixa").fullCalendar( 'refetchEvents' );  
              swal({
               title: 'Fatura cobrada com sucesso!',
               text: "Deseja emitir o recibo?",
               type: 'success',
               showCancelButton: true,
               confirmButtonColor: '#3085d6',
               cancelButtonColor: '#d33',
               confirmButtonText: 'Sim',
               cancelButtonText: "Cancelar",   
               closeOnConfirm: true,   
               closeOnCancel: true
             },
             function(isConfirm){   
             if(isConfirm){     
                window.open('imprimir/recibo?@='+codigo, '_blank');
                $("#caixa").fullCalendar( 'refetchEvents' );
                Atualizar();
             }
             else{     
                swal({
                 title: "Processo Cancelado!",
                 text: "Recibo não Impresso!",
                 type: "error",
                 timer: 1700,
                 showCancelButton: false, 
                 showConfirmButton: false 
                });  
                $("#caixa").fullCalendar( 'refetchEvents' );
                Atualizar();
                }
              });
             }

         
         //FUNCAO COBRAR COM CONVENIO, AQUI SO DA BAIXA NO SISTEMA
          function convenios(){
             var id=$('#id').val();
             var randomico=$('#randomico').val();
             var codigo = randomico+btoa(id);
             $('#cobrarFatura').modal('hide');
              swal({
              title: 'Você tem certeza?',
              text: "Deseja cobrar a fatura e contabilizar? ",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Sim',
              cancelButtonText: "Cancelar",   
              closeOnConfirm: false,   
              closeOnCancel: false
             },
             function(isConfirm){  
             if(isConfirm){
               $.ajax({
                 url: '../controllers/Orcamentos.php',
                 type: 'POST',
                 data:'id='+id+'&botao=finalizarVenda'
               });
              $("#caixa").fullCalendar( 'refetchEvents' );  
              swal({
              title: 'Fatura cobrada com sucesso!',
              text: "Deseja emitir o recibo?",
              type: 'success',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Sim',
              cancelButtonText: "Cancelar",   
              closeOnConfirm: true,   
              closeOnCancel: true
             },
             function(isConfirm){   
             if(isConfirm){     
                window.open('imprimir/recibo?@='+codigo, '_blank');
                $("#caixa").fullCalendar( 'refetchEvents' );
                Atualizar();
             }
             else{     
              swal({
              title: "Processo Cancelado!",
              text: "Recibo não Impresso!",
              type: "error",
              timer: 1700,
              showCancelButton: false, 
              showConfirmButton: false 
              });  
                $("#caixa").fullCalendar( 'refetchEvents' );
                Atualizar();
                }
              });
             }
             else{     
              swal({
              title: "Processo Cancelado!",
              text: "A fatura ficou Pendente",
              type: "error",
              timer: 1700,
              showCancelButton: false, 
              showConfirmButton: false 
              });  
              $("#caixa").fullCalendar( 'refetchEvents' );
              Atualizar();
              }
            });
          }


      //INICIO API MAQUINA DE CARTAO
        var PlugPag = function(channel) {
        var WS_HOST = 'wss://cloud.achex.ca';
        var busy = false;
        var generateToken = function() {
        var token = '';
        for(var i = 30; i > 0; --i) {
            token += (Math.floor(Math.random() * 256)).toString(16);
          }
          return token;
        }

        var sendRequest = function(request_data, callback) {
        token = generateToken();
        request_message = {
          'to': 'server@' + channel,
          'token': token,
          'type': 'request',
          'request_data': request_data
        };

        ws = new WebSocket(WS_HOST);
        ws.onopen = function() {
            ws.send(JSON.stringify({
                'auth': 'client@' + channel
            }));
        }
        ws.onmessage = function(message) {
           message_json = JSON.parse(message['data']);
        if(typeof message_json['auth'] != 'undefined' && message_json['auth'] == 'OK') {
           ws.send(JSON.stringify(request_message));
        } else if(typeof message_json['FROM'] != 'undefined' && message_json['FROM'] == 'server@' + channel) {
               if(typeof message_json['token'] != 'undefined' && message_json['token'] == token) {
               if(typeof message_json['type'] != 'undefined' && message_json['type'] == 'response') {
                  ws.close();
                  busy = false;
                  callback(message_json['response_data']['transaction_result'], message_json['response_data']['error']);
                }
              }
            }
          }        
        }
        this.payment = function(method, installments, installment, amount, callback) {
        if(!busy) {
            busy = true;
            request_data = {
              'operation': 'payment',
              'operation_data': {
              'method': method,
              'installments': installments,
              'installment': installment,
              'amount': amount
              }
            };

            sendRequest(request_data, callback);
         } else {
            callback({}, true);
           }
         }

        this.cancelPayment = function(callback) {
        if(!busy) {
            busy = true;
            request_data = {
              'operation': 'cancel_payment',
              'operation_data': {}
            };
            sendRequest(request_data, callback);
          } else {
            callback({}, true);
          }
        }

        this.queryLastTransaction = function(callback) {
        if(!busy) {
            busy = true;
            request_data = {
              'operation': 'query_last_transaction',
              'operation_data': {}
            };

            sendRequest(request_data, callback);
           } else {
            callback({}, true);
            }
          }
        }
        if(typeof exports !== 'undefined') exports.PlugPag = PlugPag;
        if(typeof define !== 'undefined') define(function() { return PlugPag; });
      //FIM API MAQUINA DE CARTAO

