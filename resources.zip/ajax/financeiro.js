 $('#relatorios').modal('show');
 $('.periodo_retroativo').hide();
 $('.dt_inicial').hide();
 $('.dt_final').hide();
 $('.status').hide();
 $('.relatorio').hide();
 $('.convenios').hide();
//FUNCAO QUE BUSCA OS DADOS 
 fluxo_Caixa();
  function fluxo_Caixa(){
    var id_usuario = $("#id_usuario").val();
     $.post('../models/FinanceiroBusca.php', { id_usuario: id_usuario },
      function(data) {
       data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.  
        var jan  = 0; 
        var fev  = 0; 
        var mar  = 0; 
        var abr  = 0; 
        var maio = 0; 
        var jun  = 0; 
        var jul  = 0; 
        var ago  = 0; 
        var set  = 0; 
        var out  = 0; 
        var nov  = 0; 
        var dez  = 0;
        for(var i=0; data.length > i; i++){
        var mes = (data[i].data_pagamento).split("-")[1];
        
        if(mes == "01"){
           jan += parseFloat(data[i].valor_final); 
        }
        if(mes == "02"){
           fev += parseFloat(data[i].valor_final); 
        }
        if(mes == "03"){
           mar += parseFloat(data[i].valor_final); 
        }
        if(mes == "04"){
           abr += parseFloat(data[i].valor_final); 
        }
        if(mes == "05"){
           maio += parseFloat(data[i].valor_final); 
        }
        if(mes == "06"){
           jun += parseFloat(data[i].valor_final); 
        }
        if(mes == "07"){
           jul += parseFloat(data[i].valor_final); 
        }
        if(mes == "08"){
           ago += parseFloat(data[i].valor_final); 
        }
        if(mes == "09"){
           set += parseFloat(data[i].valor_final); 
        }
        if(mes == "10"){
           out += parseFloat(data[i].valor_final);
        }
        if(mes == "11"){
           nov += parseFloat(data[i].valor_final); 
        }
        if(mes == "12"){
           dez += parseFloat(data[i].valor_final);
        }

        var caixa;
        var anoAtual = new Date;
        var DadosCaixa = [
        {
        "caixaMes": "JAN",
        "valores": jan,
        "color": "#FF0F00"
        },
        {
        "caixaMes": "FEV",
        "valores": fev,
        "color": "#FF6600"
        },
        {
        "caixaMes": "MAR",
        "valores": mar,
        "color": "#FF9E01"
        },
        {
        "caixaMes": "ABR",
        "valores": abr,
        "color": "#FCD202"
        },
        {
        "caixaMes": "MAIO",
        "valores": maio,
        "color": "#F8FF01"
        },
        {
        "caixaMes": "JUN",
        "valores": jun,
        "color": "#B0DE09"
        },
        {
        "caixaMes": "JUL",
        "valores": jul,
        "color": "#04D215"
        },
        {
        "caixaMes": "AGO",
        "valores": ago,
        "color": "#04D215"
        },
        {
        "caixaMes": "SET",
        "valores": set,
        "color": "#04D215"
        },
        {
        "caixaMes": "OUT",
        "valores": out,
        "color": "#04D215"
        },
        {
        "caixaMes": "NOV",
        "valores": nov,
        "color": "#04D215"
        },
        {
        "caixaMes": "DEZ",
        "valores": dez,
        "color": "#04D215"
        }];

     var caixa = AmCharts.makeChart("fluxoCaixa", {
        type: "serial",
        dataProvider: DadosCaixa,
        categoryField: "caixaMes",
        depth3D: 20,
        angle: 30,
        startDuration: 2,

        categoryAxis: {
            labelRotation: 90,
            gridPosition: "start"
        },
    
        graphs: [{
            balloonText: "<b>R$ [[value]]</b>",
            valueField: "valores",
            colorField: "color",
            type: "column",
            lineAlpha: 0.5,
            fillAlphas: 1,
            lineColor: "#FFFFFF"
        }],

        chartCursor: {
            cursorAlpha: 0,
            zoomable: false,
            categoryBalloonEnabled: false,
            valueLineEnabled: true,
            valueLineBalloonEnabled: true,
            valueLineAlpha: 1
        },
        "export": {
            "enabled": false
         }
       });
      }
    });
   } 

   $('#tipo_relatorio').on('change', function() {
     if($("#tipo_relatorio").val() == "entre_datas"){
        $('.relatorio').show();
        $('.periodo_retroativo').hide();
        $('.dt_inicial').show();
        $('.dt_final').show();
        $('.status').show();
     }
     if($("#tipo_relatorio").val() == "periodo_retroativo"){
        $('.relatorio').show();
        $('.periodo_retroativo').show();
        $('.dt_inicial').hide();
        $('.dt_final').hide();
        $('.status').show();
      }
   });

   $('#relatorio').on('change', function() {
     if($("#relatorio").val() == "Convenios"){
        $('.convenios').show();
     }
     else{
        $('.convenios').hide();
     }
   });

function buscar_relatorio(){
   var tipo_relatorio = $('#tipo_relatorio').val();
   var relatorio = $("#relatorio").val();
   var convenio = $("#convenio").val();
   var status_ = $('#status').val();
   var periodo_retro = $('#periodo_retroativo').val();
   var dt_inicial = $('#dt_inicial').val();
   var dt_final = $('#dt_final').val();

   if (tipo_relatorio == "") {
      $('#relatorios').modal('hide');
      swal({
      title:"Campo Obrigatório!",
      text: "Por Favor, Escolha o Critério de Busca!",
      type: "error",
      timer: 1800,
      showCancelButton: false, 
      showConfirmButton: false 
      }); 
      window.setTimeout(function() {
        $('#relatorios').modal('show');
      }, 2000);     
   }
   else if (relatorio == "") {
      $('#relatorios').modal('hide');
      swal({
      title:"Campo Obrigatório!",
      text: "Por Favor, Escolha um Relatório!",
      type: "error",
      timer: 1800,
      showCancelButton: false, 
      showConfirmButton: false 
      });
      window.setTimeout(function() {
        $('#relatorios').modal('show');
      }, 2000);
   } 
   else if (status_ == "") {
      $('#relatorios').modal('hide');
      swal({
      title:"Campo Obrigatório!",
      text: "Por Favor, Escolha o Status!",
      type: "error",
      timer: 1800,
      showCancelButton: false, 
      showConfirmButton: false 
      }); 
      window.setTimeout(function() {
        $('#relatorios').modal('show');
      }, 2000);
   }
   else{  
   var Tipo_relatorio = btoa(tipo_relatorio);
   var relatorios = btoa(relatorio);
   var convenios = btoa(convenio);
   var status = btoa(status_);
   var periodo_retroativo = btoa(periodo_retro);
   var inicial = btoa(dt_inicial);
   var final = btoa(dt_final);

   window.open('imprimir/relatorio?tr='+Tipo_relatorio+'&r='+relatorios+'&c='+convenios+'&s='+status+'&p='+periodo_retroativo+'&i='+inicial+'&f='+final, '_blank');
  
   $('.cb').remove();
   $('.rt').remove();
   $('.st').remove();
   $('.pr').remove();
   $('#tipo_relatorio').append('<option value="" class="cb">Escolha o Critério</option><option class="cb" value="entre_datas">Período entre Datas</option><option class="cb" value="periodo_retroativo">Período Retroativo</option>');
   $('#relatorio').append('<option class="rt" value="" class="rt">Escolha um Relatório</option><option class="rt" value="Balancete_Geral">Balancete Geral</option><option class="rt" value="Pagar">Contas a Pagar</option><option class="rt" value="Receber">Contas a Receber</option><option class="rt" value="Dinheiro">Dinheiro</option><option class="rt" value="Cheques">Cheques</option><option class="rt" value="Boletos">Boletos</option><option class="rt" value="Convenios">Convênios</option><option class="rt" value="Debito">Cartão de Débito</option><option class="rt" value="Credito">Cartão de Crédito</option>');
   $('#status').append('<option value="" class="st">Escolha o Status</option><option class="st" value="Liquidada">Liquidadas</option><option class="st" value="Pendente">Pendentes</option><option class="st" value="Todos">Todos</option>');
   $('#periodo_retroativo').append('<option value="" class="pr">Escolha o Período</option><option class="pr" value="7">  Últimos  07 dias</option><option class="pr" value="15"> Últimos  15 dias</option><option class="pr" value="30"> Últimos  30 dias</option><option class="pr" value="60"> Últimos  60 dias</option><option class="pr" value="90"> Últimos  90 dias</option><option class="pr" value="120">Últimos  04 meses</option><option class="pr" value="150">Últimos  05 meses</option><option class="pr" value="180">Últimos  06 meses</option><option class="pr" value="220">Últimos  07 meses</option><option class="pr" value="250">Últimos  08 meses</option><option class="pr" value="280">Últimos  09 meses</option><option class="pr" value="305">Últimos  10 meses</option><option class="pr" value="335">Últimos  11 meses</option><option class="pr" value="365">Últimos  12 meses</option><option class="pr" value="36500">Todos os Períodos</option>');
   $('#dt_inicial').val("");
   $('#dt_final').val("");

   $('.relatorio').hide();
   $('.periodo_retroativo').hide();
   $('.dt_inicial').hide();
   $('.dt_final').hide();
   $('.status').hide();
   $('.convenios').hide();
   $('#relatorios').modal('show');
 } 
}  
$('.f2').hide();
document.getElementById('ImprimeGraficos').onclick = function() {
  $('.f2').show();
  var conteudo = document.getElementById('graficos').innerHTML,
      tela_impressao = window.open('_blank');

  tela_impressao.document.write(conteudo);
  tela_impressao.window.print($('.f2').hide());
  tela_impressao.window.close($('.f2').hide());
};