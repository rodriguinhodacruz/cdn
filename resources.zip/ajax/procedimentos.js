if($("#tbs tr").length == 1){
  $("#tbs").css("display", "none");
  $("#smile").show();
}
else{
  var tb = ($("#tbs  tr").length)-1;
  $("#smile").hide();
}

//FUNCAO QUE BUSCA OS CONVENIOS PARA CADASTRO PROCEDIMENTO
  $('#convenio').append('<option class="particular" value="Particular">Particular</option>');
   $('#plano').on('change', function() {
    if($('#plano').val() == 'Particular') {
       $('.convenio').remove();
       $('#convenio').append('<option class="particular" value="Particular">Particular</option>');
    }
    else{
         $('.particular').remove();
         //AJAX BUSCA CONVENIOS
         var id_usuario=$('#id_usuario').val();
         $.post('../models/ConvenioProcedimentos.php', { id_usuario: id_usuario },
            function(data) {
            data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.
            for(var i=0; data.length > i; i++){  
             $('#convenio').append('<option  class="convenio" value="'+data[i].convenio+'">'+data[i].convenio+'</option>');
            }
         });
       }
    });


     //FUNCAO QUE CADASTRA O PROCEDIMENTO
        function cadastrar_procedimento(){
            var id_usuario=$('#id_usuario').val();
            var plano=$('#plano').val();
            var convenio=$('#convenio').val();
            var especialidade_procedimento=$('#especialidade_procedimento').val();
            var nome_procedimento=$('#nome_procedimento').val();
            var valor_procedimento=$('#valor_procedimento').val();
           
            if (cadastroProcedimento.plano.value == "")
            {
            cadastroProcedimento.plano.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha com o Plano!",
            type: "error",
            timer: 1300,
            showCancelButton: false, 
            showConfirmButton: false 
            });            
            return (false);
            }

            if (cadastroProcedimento.convenio.value == "")
            {
            cadastroProcedimento.convenio.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha com o Convênio!",
            type: "error",
            timer: 1300,
            showCancelButton: false, 
            showConfirmButton: false 
            });            
            return (false);
            }

            if (cadastroProcedimento.especialidade_procedimento.value == "")
            {
            cadastroProcedimento.especialidade_procedimento.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha com a Especialidade!",
            type: "error",
            timer: 1300,
            showCancelButton: false, 
            showConfirmButton: false 
            });            
            return (false);
            }
            
            if (cadastroProcedimento.nome_procedimento.value == "")
            {
            cadastroProcedimento.nome_procedimento.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha com o Procedimento!",
            type: "error",
            timer: 1300,
            showCancelButton: false, 
            showConfirmButton: false 
            });            
            return (false);
            }
            $.ajax({
              url:'../controllers/Procedimentos.php',
              type:'POST',
              data:'id_usuario='+id_usuario+'&plano='+plano+'&convenio='+convenio+'&especialidade_procedimento='+especialidade_procedimento+'&nome_procedimento='+nome_procedimento+'&valor_procedimento='+valor_procedimento+'&botao=cadastrarProcedimento'
            }).done(function(resposta){
                    if (resposta) {
                      $('#CadastroProcedimento').modal('hide'); 
                        swal({
                         title: "Processo Concluído!",
                         text: "Procedimento cadastrado com sucesso!",
                         type: "success",
                         showCancelButton: false, 
                         showConfirmButton: false 
                        });
                      setTimeout('location.reload();', 1700);
                    }  
                });
            }

//FUNCAO QUE BUSCA OS CONVENIOS PARA EDICAO PROCEDIMENTO
   $('#planos').on('change', function() {
    if($('#planos').val() == 'Particular') {
       $('.convenio').remove();
       $('#convenios').append('<option class="particular" value="Particular">Particular</option>');
    } 
    else if($('#planos').val() == 'Particular') {
       $('.convenio').remove();
       $('#convenios').append('<option class="particular" value="Particular">Particular</option>');
    }
    else{
         $('.particular').remove();
         $('#convenios').html("");
         var id_usuario=$('#id_usuario').val();
         $.post('../models/ConvenioProcedimentos.php', { id_usuario: id_usuario },
            function(data) {
            data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.
            for(var i=0; data.length > i; i++){  
             $('#convenios').append('<option  class="convenio" value="'+data[i].convenio+'">'+data[i].convenio+'</option>');
            }
         });
       }
    });

    //FUNCAO QUE BUSCA OS DADOS PARA EDICAO
        function editarProcedimento(id){
          var id=id
          $.post('../models/dados_procedimento.php', { id: id },
            function(data) {
            data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.  
             $('#ids').val(data[0].id);
             $('#planos').append('<option value='+data[0].plano+'>'+data[0].plano+'</option><option value="Particular">Particular</option><option value="Convênio">Convênio</option>');
             $('#convenios').append('<option class="convenio" value='+data[0].convenio+'>'+data[0].convenio+'</option>');
             $('#especialidade_procedimentos').append('<option value='+data[0].especialidade_procedimento+'>'+data[0].especialidade_procedimento+'<option value="Clínico Geral">Clínico Geral</option><option value="Ortodontia">Ortodontia</option><option value="Endodontia">Endodontia</option><option value="Implantodontia">Implantodontia</option><option value="Prótese">Prótese</option><option value="Dentística">Dentística</option><option value="Periodontia">Periodontia</option><option value="Odontopediatria">Odontopediatria</option><option value="Bucomaxilofacial">Bucomaxilofacial</option><option value="Cirurgia e Traumatologia Buco">Cirurgia e Traumatologia Buco</option><option value="Radiologia">Radiologia</option><option value="Dentística Restauradora">Dentística Restauradora</option><option value="Ortodontia e Ortopedia Facial">Ortodontia e Ortopedia Facial</option><option value="Ortopedia Funcional dos Maxilares">Ortopedia Funcional dos Maxilares</option><option value="Saúde Coletiva">Saúde Coletiva</option><option value="Estomatologia">Estomatologia</option><option value="Patologia Bucal">Patologia Bucal</option><option value="Odontologia do Trabalho">Odontologia do Trabalho</option>');
             $('#nome_procedimentos').val(data[0].nome_procedimento);
             $('#valor_procedimentos').val(parseInt(data[0].valor_procedimento).toLocaleString('pt-br', {minimumFractionDigits: 2}));
            });
          $('#editar_Procedimento').modal('show');
        }

      //EDICAO DADOS PROCEDIMENTO
        function editar_procedimento(){
            var id=$('#ids').val();
            var plano=$('#planos').val();
            var convenio=$('#convenios').val();
            var especialidade_procedimento=$('#especialidade_procedimentos').val();
            var nome_procedimento=$('#nome_procedimentos').val();
            var valor_procedimento=$('#valor_procedimentos').val();
            $.ajax({
              url:'../controllers/Procedimentos.php',
              type:'POST',
              data:'id='+id+'&plano='+plano+'&convenio='+convenio+'&especialidade_procedimento='+especialidade_procedimento+'&nome_procedimento='+nome_procedimento+'&valor_procedimento='+valor_procedimento+'&botao=editarProcedimento'
            }).done(function(resposta){
                    if (resposta) {
                        $('#editar_Procedimento').modal('hide');
                        swal({
                         title: "Processo Concluído!",
                         text: "Procedimento atualizado com sucesso!",
                         type: "success",
                         showCancelButton: false, 
                         showConfirmButton: false 
                        });
                       window.setTimeout("location.href='procedimentos'",1700)
                    }
                });            
            }


             function deletar(id){
                var id=id        
                    swal({
                        title: 'Você tem certeza?',
                        text: "O Procedimento será excluído permanentemente!",
                        type: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Sim',
                        cancelButtonText: "Cancelar",   
                        closeOnConfirm: false,   
                        closeOnCancel: false
                        },

                    function(isConfirm){   
                        if (isConfirm){     
                            swal({
                            title: "Processo Concluído!",
                            text: "Procedimento excluído com sucesso!",
                            type: "success",
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });
                        $.ajax({
                            url:'../controllers/Procedimentos.php',
                            type: "POST",
                            data: 'id='+id+"&botao=excluirProcedimento"
                        });
                         setTimeout('location.reload();', 1700);
                        }
                        else{     
                            swal({
                            title: "Processo Cancelado!",
                            text: "Procedimento não excluído!",
                            type: "error",
                            timer: 1700,
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });   
                           }
                          });
                        }
        

   

        

   