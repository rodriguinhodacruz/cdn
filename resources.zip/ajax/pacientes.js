if($("#tbPacientes tr").length == 1){
  $("#tbPacientes").css("display", "none");
  $("#smile").show();
}
else{
  var tb = ($("#tbPacientes  tr").length)-1;
  $("#smile").hide();
}
//FUNCAO QUE CADASTRA O PACIENTE
        function cadastrar_paciente(){
            var id_usuario=$('#id_usuario').val();
            var nome=$('#nome').val();
            var dt_nascimento=$('#dt_nascimento').val();
            var cpf=$('#cpf').val();
            var rg=$('#rg').val();
            var profissao=$('#profissao').val();
            var email=$('#email').val();
            var telefone_residencial=$('#telefoneFixo').val();
            var telefone_celular=$('#celular').val();
            var cep=$('#cep').val();
            var numero=$('#numero').val();
            var rua=$('#rua').val();
            var bairro=$('#bairro').val();
            var cidade=$('#cidade').val();
            var uf=$('#uf').val();

            if (cadastroPaciente.nome.value == "")
            {
            cadastroPaciente.nome.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Nome do Paciente!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });            
            return (false);
            }
            
            if (cadastroPaciente.dt_nascimento.value == "")
            {
            cadastroPaciente.dt_nascimento.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha a data de nascimento!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });           
            return (false);
            }
            
            if (cadastroPaciente.cpf.value == "")
            {
            cadastroPaciente.cpf.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o CPF do Paciente!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });       
            return (false);
            }
            
            if (cadastroPaciente.rg.value == "")
            {
            cadastroPaciente.rg.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o RG do Paciente!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });       
            return (false);
            }

            if (cadastroPaciente.celular.value == "")
            {
            cadastroPaciente.celular.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Telefone Celular!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });               
            return (false);
            }

            $.ajax({
                    url:'../controllers/Paciente.php',
                    type:'POST',
                    data:'id_usuario='+id_usuario+'&nome='+nome+'&dt_nascimento='+dt_nascimento+'&cpf='+cpf+'&rg='+rg+'&profissao='+profissao+'&email='+email+'&telefone_residencial='+telefone_residencial+'&telefone_celular='+telefone_celular+'&cep='+cep+'&numero='+numero+'&rua='+rua+'&bairro='+bairro+'&cidade='+cidade+'&uf='+uf+'&botao=cadastrarPaciente'
                }).done(function(resposta){
                    if (resposta) {
                      $('#CadastroPacientes').modal('hide'); 
                        swal({
                            title: "Processo Concluído!",
                            text: "Cadastro realizado com sucesso!",
                            type: "success",
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });
                      setTimeout('location.reload();', 1700);
                    }

                    
                });
            
            }



//FUNCAO QUE BUSCA OS DADOS PARA EDICAO
        function editar(id){
          var id=id
           $.post('../models/PacienteBusca.php', { id: id },
            function(data) {
            data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.  
             $('#id').val(data[0].id);
             $('#nomes').val(data[0].nome);
             $('#dt_nascimentos').val(moment(data[0].dt_nascimento).format('DD/MM/YYYY'));
             $('#cpfs').val(data[0].cpf);
             $('#rgs').val(data[0].rg);
             $('#profissaos').val(data[0].profissao);
             $('#emails').val(data[0].email);
             $('#telefoneFixos').val(data[0].telefone_residencial);
             $('#celulars').val(data[0].telefone_celular);
             $('#ceps').val(data[0].cep);
             $('#numeros').val(data[0].numero);
             $('#ruas').val(data[0].rua);
             $('#bairros').val(data[0].bairro);
             $('#cidades').val(data[0].cidade);
             $('#ufs').val(data[0].estado);
            });
        }

      //EDICAO DADOS DO PACIENTE
        function editar_paciente(){
            var id=$('#id').val();
            var nome=$('#nomes').val();
            var dt_nascimento=$('#dt_nascimentos').val();
            var cpf=$('#cpfs').val();
            var rg=$('#rgs').val();
            var profissao=$('#profissaos').val();
            var email=$('#emails').val();
            var telefone_residencial=$('#telefoneFixos').val();
            var telefone_celular=$('#celulars').val();
            var cep=$('#ceps').val();
            var numero=$('#numeros').val();
            var rua=$('#ruas').val();
            var bairro=$('#bairros').val();
            var cidade=$('#cidades').val();
            var uf=$('#ufs').val();

     
            if (editaPaciente.nomes.value == "")
            {
            editaPaciente.nomes.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Nome do Paciente!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });            
            return (false);
            }
            
            if (editaPaciente.dt_nascimentos.value == "")
            {
            editaPaciente.dt_nascimentos.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha a data de nascimento!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });           
            return (false);
            }
            
            if (editaPaciente.cpfs.value == "")//form
            {
            editaPaciente.cpfs.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o CPF do Paciente!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });       
            return (false);
            }
            
            if (editaPaciente.rgs.value == "")
            {
            editaPaciente.rgs.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o RG do Paciente!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });       
            return (false);
            }

            if (editaPaciente.celulars.value == "")
            {
            editaPaciente.celulars.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Telefone Celular!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });               
            return (false);
            }

            $.ajax({
                    url:'../controllers/Paciente.php',
                    type:'POST',
                    data:'id='+id+'&nome='+nome+'&dt_nascimento='+dt_nascimento+'&cpf='+cpf+'&rg='+rg+'&profissao='+profissao+'&email='+email+'&telefone_residencial='+telefone_residencial+'&telefone_celular='+telefone_celular+'&cep='+cep+'&numero='+numero+'&rua='+rua+'&bairro='+bairro+'&cidade='+cidade+'&uf='+uf+'&botao=editarPaciente'
                }).done(function(resposta){
                    if (resposta) {
                      $('#EditarPacientes').modal('hide'); 
                        swal({
                            title: "Processo Concluído!",
                            text: "Registro atualizado com sucesso!",
                            type: "success",
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });
                      setTimeout('location.reload();', 1700);
                    }

                    
                });
            
            }


             function deletar(id){
                var id=id          
                    swal({
                        title: 'Você tem certeza?',
                        text: "O Registro será excluído permanentemente!",
                        type: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Sim',
                        cancelButtonText: "Cancelar",   
                        closeOnConfirm: false,   
                        closeOnCancel: false
                        },

                    function(isConfirm){   
                        if (isConfirm){     
                            swal({
                            title: "Processo Concluído!",
                            text: "Registro excluído com sucesso!",
                            type: "success",
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });
                        $.ajax({
                            url: '../controllers/Paciente.php',
                            type: "POST",
                            data: 'id='+id+"&botao=excluirPaciente"
                        });
                         setTimeout('location.reload();', 1700);
                        }
                        else{     
                            swal({
                            title: "Processo Cancelado!",
                            text: "Registro não excluído!",
                            type: "error",
                            timer: 1700,
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });   
                           }
                          });
                        }
        

   


        

   