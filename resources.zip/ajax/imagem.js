
 if($("#tbImagem tr").length == 1){
  $("#tbImagem").css("display", "none");
  $("#smile").show();
  }
  else{
  $("#smile").hide();
 }

//ENVIA IMAGENS DA CAMERA INTRA-ORAL
  Webcam.set({
    width: 600,
    height: 480,
    image_format: 'jpeg',
    jpeg_quality: 90
  });
  Webcam.attach( '#my_camera' );
  //FUNCAO QUE TIRA A FOTO COM A TECLA ESPAÇO E SALVA VIA AJAX NO BD
  $(document).ready(function(){
    $(document).keypress(function(e){
    if(e.wich == 32 || e.keyCode == 32){
      Webcam.snap(function(data_uri) {
      var id_paciente=$('#id_paciente').val();
      var id_usuario=$('#id_usuario').val();
      var nome=$('#nome').val();
      Webcam.upload( data_uri, '../controllers/Webcam.php?id_paciente='+id_paciente+'&id_usuario='+id_usuario+'&nome='+nome);    
      $('.results').append('<img  src="'+data_uri+'" width="600" height="455" style="position:relative; top:-465px;">');
       window.setTimeout(function () {
         $('.results').html("");
         Webcam.attach( '#my_camera' );
       }, 1800); 
     })
    }
  })
})


     //DELETAR IMAGEM!
    function deletar(id){
    var id=id          
        swal({
            title: 'Você tem certeza?',
            text: "O Registro será excluído permanentemente!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Sim',
            cancelButtonText: "Cancelar",   
            closeOnConfirm: false,   
            closeOnCancel: false
            },

    function(isConfirm){   
        if (isConfirm){     
            swal({
            title: "Processo Concluído!",
            text: "Registro excluído com sucesso!",
            type: "success",
            showCancelButton: false, 
            showConfirmButton: false 
            });
        $.ajax({
            url: '../controllers/ImagemDeleta.php',
            type: "POST",
            data: 'id='+id+"&botao=excluir"
        });
            setTimeout('location.reload();', 1200);
        }
        else{     
            swal({
            title: "Processo Cancelado!",
            text: "Registro não excluído!",
            type: "error",
            timer: 1300,
            showCancelButton: false, 
            showConfirmButton: false 
            });   
            }
            });
        }
        
 //AJAX BUSCA AS IMAGENS
  //$(document).ready(function(){   
    //var id_paciente=$('#id_paciente').val();
     //$.post('../models/ImagemBusca.php', { id_paciente: id_paciente },
       //function(data) {
       //data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.
        //for(var i=0; data.length > i; i++){
       //$('#imagens_paciente').append('<div class="gallery-col"><article class="gallery-item"><img class="gallery-picture" src="'+data[i].imagem+'" height="158"><div class="gallery-hover-layout"><div class="gallery-hover-layout-in"><p class="gallery-item-title">'+data[i].nome+'</p><div class="btn-group"><a href="'+data[i].imagem+'" data-dismiss="modal" title="'+data[i].nome+'"><img src="'+data[i].imagem+'" style="display: none;"><button type="button" class="btn tool2" data-tip="Visualizar" tabindex="4"><i class="font-icon font-icon-eye"></i></button></a><button type="button" onclick="deletar('+data[i].id+')" class ="btn tool2" data-tip="Excluir" tabindex="4"><i class="font-icon font-icon-trash"></i></button></div><p>'+ moment(data[i].data_cadastro).format('DD/MM/YYYY')+'</p></div></div></article></div>');
       //}
     //});
   //});

        



            