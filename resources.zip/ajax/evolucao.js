     
$('.aprovar_orcamento').hide();
$('#botaoFinaliza').hide();

 if($("#tbOrcamento tr").length == 1){
    $("#tbOrcamento").css("display", "none");
    $("#smile").show();
 }
 else{
    var tb = ($("#tbOrcamento  tr").length)-1;
    $("#smile").hide();
 }

    function adiconaEvolucao(id) {
      $.post('../models/CaixaBusca.php', {id:id},
      function(data) {
       data = $.parseJSON(data);
       $('#id_fatura').val(data[0].id);
       $('#tbTratamentos').append(data[0].tbDescricao);
       $('#id_paciente').val(data[0].id_paciente);
       $('#consumirProduto').modal('show');
       document.getElementById("codigo_insumo").focus();
       consumoEstoque()
      });
    }

     //FUNCAO QUE DA O CONSUMO DE PRODUTOS DO ESTOQUE! 
      function consumoEstoque() {
        $('#consumirProduto').modal('hide');
        swal({
          title: 'Você deseja consumir produtos/insumos antes de adicionar a Evolução?',
          text: "Materiais utilizados durante a consulta ou procedimento deste paciente!",
          type: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Sim',
          cancelButtonText: "Não",   
          closeOnConfirm: true,   
          closeOnCancel: true
          },
          function(isConfirm){   
           if (isConfirm){
            $('#consumirProduto').modal('show');
             document.addEventListener('keypress', function(e){
               if(e.which == 13){
                 //BUSCO O PRODUTO NO ESTOQUE PELO CODIGO
                 var codigo_insumo = $('#codigo_insumo').val();
                 $.post('../models/EstoqueBuscaCodigo.php', { codigo: codigo_insumo },
                   function(data) {
                   if(data==false){
                    $('#consumirProduto').modal('hide');
                    swal({
                     title: "Processo Cancelado!",
                     text: "Produto/Insumo não Cadastrado!",
                     type: "error",
                     timer:1700,
                     showCancelButton: false, 
                     showConfirmButton: false 
                    });
                    window.setTimeout(function () {
                      $('#consumirProduto').modal('show');
                      $('#codigo_insumo').val("");
                      document.getElementById("codigo_insumo").focus();
                    }, 1800);  
                   }
                   else{
                     data = $.parseJSON(data);
                     //AQUI FAZ A VALIDACAO DO ESTOQUE MINIMO
                     if (data[0].estoque_minimo == data[0].quantidade){
                     $('#consumirProduto').modal('hide');
                      swal({
                        title: "Processo Cancelado!",
                        text: "Estoque Mínimo de "+ data[0].produto + ", restam apenas " + data[0].quantidade + " , escolha outro Produto/Insumo ou altere a quantidade mínima em estoque!",
                        type: "error",
                        timer:5000,
                        showCancelButton: false, 
                        showConfirmButton: false 
                      });
                      window.setTimeout(function () {
                        $('#consumirProduto').modal('show');
                        $('#codigo_insumo').val("");
                        document.getElementById("codigo_insumo").focus();
                      }, 5000);  
                     }
                     else{
                       var id_usuario = $('#id_usuario').val();
                       var id_paciente = $('#id_paciente').val();
                       var qtd_consumida = 1;
                     $.ajax({
                       url: '../controllers/Estoque.php',
                       type: 'POST',
                       data:'id_usuario='+id_usuario+'&id_paciente='+id_paciente+'&codigo_produto='+data[0].codigo+'&produto='+data[0].produto+'&qtd_consumida='+qtd_consumida+'&valor_produto='+data[0].valor_unitario+'&botao=consumoPaciente'
                     }).done(function(resposta){
                     //EXIBE NO MODAL O PRODUTO/INSUMO ADD AO CONSUMO COM O PACIENTE E DIMINUI O PRODUTO NO ESTOQUE!
                     if (resposta) {
                        //AJAX QUE DIMINUI DO ESTOQUE O PRODUTO ESCOLHIDO!
                        $.ajax({
                            url: '../controllers/Estoque.php',
                            type: "POST",
                            data: 'id='+data[0].id+'&quantidade='+data[0].quantidade+"&botao=consumirProduto"
                        });
                        //AJAX QUE BUSCA OS PRODUTOS USADOS COM O PACIENTE E APRESENTA NA TABLE
                        $.post('../models/consumoPacienteBusca.php', {id_paciente:id_paciente},
                         function(data) {
                          $('#codigo_insumo').val("");
                          $('#consumo_paciente_foi').html("");
                          $('.tbConsumo').show();
                          data = $.parseJSON(data);
                          for(var i=0; data.length > i; i++){  
                          $('#consumo_paciente_foi').append('<tr><td>'+data[i].codigo_produto+'</td><td>'+data[i].produto+'</td><td></td><td>'+data[i].qtd_consumida+'</td><td></td><td><a onclick="devolveEstoque('+data[i].codigo_produto+','+data[i].id+')" style="position: relative; left:5%; top:2px;" class = "tool" data-tip="Devolver" tabindex="2"><i class="fa fa-refresh  color-blue" style="font-size:16px"></i></a></td></tr>');
                         }
                       });
                      }
                     });
                    }//fim else da validacao do estoque minimo
                   }
                 });
               }
             }, false);
           }
           else{ 
            $('#consumirProduto').modal('hide');
            $('#adicionaEvolucao').modal('show');
            document.getElementById("evolucao").focus();
           }    
         });
      }

      //FUNCAO DEVOLVE PARA O ESTOQUE 'txtCodEmpreendedor', 'txtNomeEmpreendedor'
      function devolveEstoque(codigo_produto, id) {
        var id = id
        var codigo_produto = codigo_produto
        var id_paciente = $('#id_paciente').val();
        $.post('../models/EstoqueBuscaCodigo.php', {codigo: codigo_produto},
        function(data) {
        data = $.parseJSON(data);
        //DEVOLVO AO ESTOQUE
        $.ajax({
          url: '../controllers/Estoque.php',
          type: "POST",
          data: 'codigo_produto='+codigo_produto+'&quantidade='+data[0].quantidade+"&botao=devolverProduto"
        }).done(function(resposta){
        //EXCLUO O PRODUTO DO PACIENTE
           if (resposta) {
            $.ajax({
              url: '../controllers/Estoque.php',
              type: "POST",
              data: 'id='+id+"&botao=excluirProdutoPaciente"
            }).done(function(resposta){
              if (resposta) {
              //SE EXCLUIU COM SUCESSO, ATUALIZO A TABLE
               $.post('../models/consumoPacienteBusca.php', {id_paciente:id_paciente},
                 function(data) {
                  document.getElementById("codigo_insumo").focus();
                  $('#codigo_insumo').val("");
                  $('#consumo_paciente_foi').html("");
                  data = $.parseJSON(data);
                  for(var i=0; data.length > i; i++){  
                  $('#consumo_paciente_foi').append('<tr><td>'+data[i].codigo_produto+'</td><td>'+data[i].produto+'</td><td></td><td>'+data[i].qtd_consumida+'</td><td></td><td><a onclick="devolveEstoque('+data[i].codigo_produto+','+data[i].id+')" style="position: relative; left:5%; top:2px;" class = "tool" data-tip="Devolver" tabindex="2"><i class="fa fa-refresh  color-blue" style="font-size:16px"></i></a></td></tr>');
                }
               });
              }
            });
           }
         });
       });
      }

    function consumoOK() {
      $('#consumirProduto').modal('hide');
      $('#adicionaEvolucao').modal('show');
      document.getElementById("evolucao").focus();
    }

    function addEvolucao() {
      var id_usuario  = $('#id_usuario').val();
      var id_paciente = $('#id_paciente').val();
      var id_fatura   = $('#id_fatura').val();
      var tratamentos = $('#tbTratamentos').val();
      var evolucao    = $('#evolucao').val();
      $.ajax({
        url: '../controllers/Evolucao.php',
        type: "POST",
        data: 'id_usuario='+id_usuario+'&id_paciente='+id_paciente+'&id_fatura='+id_fatura+'&tratamentos='+tratamentos+'&evolucao='+evolucao+"&botao=addEvolucao"
      }).done(function(resposta){
         if (resposta) {
           swal({
             title: "Processo Concluído!",
             text: "Evolução cadastrada com sucesso!",
             type: "success",
             showCancelButton: false, 
             showConfirmButton: false 
           });
           $('#adicionaEvolucao').modal('hide');
           setTimeout('location.reload();', 1700);
          }
       });
     }

    function verEvolucao(id) {
      $.post('../models/EvolucaoBusca.php', {id_fatura:id},
        function(data) {
        if(data==false){
           swal({
           title: "Processo Cancelado!",
           text: "Nenhuma evolução para Visualizar!",
           type: "error",
           timer: 1800,
           showCancelButton: false, 
           showConfirmButton: false 
          });  
        }
        else{
        data = $.parseJSON(data);
        for(var i=0; data.length > i; i++){  
        $('#evolucoes_add').append('<tr><td style="position:relative; top:20px;"><i class="fa fa-line-chart  color-green" style="font-size:20px"></i><strong> - '+moment(data[i].data_cadastro).format('DD/MM/YYYY')+'</strong></td></tr><tr><td>'+data[i].evolucao+'</td></tr>');    
        }
       $('#Evolucoes_add').modal('show');
      }
     })
    }
   


    function imprimeEvolucao(id) {
      $.post('../models/EvolucaoBusca.php', {id_fatura:id},
        function(data) {
        if(data==false){
          swal({
           title: "Processo Cancelado!",
           text: "Nenhuma evolução para imprimir!",
           type: "error",
           timer: 1800,
           showCancelButton: false, 
           showConfirmButton: false 
          });  
        }
        else{
         var randomico=$('#randomico').val();
         var codigo = randomico+btoa(id);
         window.open('imprimir/evolucao?@='+codigo, '_blank');
        }
      })
    }
