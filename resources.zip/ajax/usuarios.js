      function logarConta(){

            var email = $('#email').val();
            var senha = $('#senha').val();

            if (login.email.value == ""){
            alert("Digite o Email de Acesso!");
            login.email.focus();
            return (false);
            }
            if (login.senha.value == ""){
            alert("Digite a Senha de Acesso!");
            login.senha.focus();
            return (false);
            }
            $.ajax({
                url:'../controllers/Usuario.php',
                type:'POST',
                data:'email='+email+'&senha='+senha+"&botao=entrar"
            }).done(function(resposta){
                if(resposta==true){
                     location.href='../views/iniciar';
                }else{
                    alert('Dados Inválidos!');
                }
            });
        }



        function cadastrar_usuario(){
            var registro_profissional=$('#registro_profissional').val();
            var nivel_acesso=$('#nivel_acesso').val();
            var nome=$('#nome').val();
            var dt_nascimento=$('#dt_nascimento').val();
            var cpf=$('#cpf').val();
            var rg=$('#rg').val();
            var especialidade=$('#especialidade').val();
            var email=$('#email').val();
            var telefone_residencial=$('#telefoneFixo').val();
            var telefone_celular=$('#celular').val();
            var senha=$('#senha').val();
            var confirme_senha=$('#confirme_senha').val();
            var cep=$('#cep').val();
            var numero=$('#numero').val();
            var rua=$('#rua').val();
            var bairro=$('#bairro').val();
            var cidade=$('#cidade').val();
            var uf=$('#uf').val();

            if (cadastroUsuario.registro_profissional.value == "")
            {
            cadastroUsuario.registro_profissional.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha Registro Profissional!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });
            return (false);
            }

            if (cadastroUsuario.nivel_acesso.value == "")
            {
            cadastroUsuario.nivel_acesso.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Tipo de Acesso!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });            
            
            return (false);
            }
            
            if (cadastroUsuario.nome.value == "")
            {
            cadastroUsuario.nome.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Nome de Usuário!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });            
            return (false);
            }
            
            if (cadastroUsuario.dt_nascimento.value == "")
            {
            cadastroUsuario.dt_nascimento.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha a data de nascimento!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });           
            return (false);
            }
            
            if (cadastroUsuario.cpf.value == "")
            {
            cadastroUsuario.cpf.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o CPF do Usuário!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });       
            return (false);
            }
            
            if (cadastroUsuario.rg.value == "")
            {
            cadastroUsuario.rg.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o RG do Usuário!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });       
            return (false);
            }

            if (cadastroUsuario.celular.value == "")
            {
            cadastroUsuario.celular.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Telefone Celular!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });               
            return (false);
            }

            if (cadastroUsuario.email.value == "")
            {
            cadastroUsuario.email.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Email de Acesso!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });               
            return (false);
            }
            
            if (cadastroUsuario.senha.value == "")
            {
            cadastroUsuario.senha.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha com uma Senha!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });               
            return (false);
            }
            if (cadastroUsuario.confirme_senha.value == "")
            {
            cadastroUsuario.confirme_senha.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, Confirme a Senha!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });               
            return (false);
            }
            if (senha===confirme_senha) {

            $.ajax({
                    url:'../controllers/Usuario.php',
                    type:'POST',
                    data:'registro_profissional='+registro_profissional+'&nivel_acesso='+nivel_acesso+'&nome='+nome+'&dt_nascimento='+dt_nascimento+'&cpf='+cpf+'&rg='+rg+'&especialidade='+especialidade+'&email='+email+'&telefone_residencial='+telefone_residencial+'&telefone_celular='+telefone_celular+'&senha='+senha+'&cep='+cep+'&numero='+numero+'&rua='+rua+'&bairro='+bairro+'&cidade='+cidade+'&uf='+uf+'&botao=cadastrarUsuario'
                }).done(function(resposta){
                    if (resposta) {
                      $('#CadastroUsuarios').modal('hide'); 
                        swal({
                            title: "Processo Concluído!",
                            text: "Cadastro realizado com sucesso!",
                            type: "success",
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });
                      setTimeout('location.reload();', 1700);
                    }
                    
                });
               }
               else{
                   cadastroUsuario.confirme_senha.focus();
                   swal({
                   title:"Processo Cancelado!",
                   text: "Por Favor, verifique a Senha digitada!",
                   type: "error",
                   timer: 1800,
                   showCancelButton: false, 
                   showConfirmButton: false 
                   });   
               }
            }

//BUSCA PARA EDICAO
        function editaUsuario(id){
          var id=id
          $.post('../models/UsuarioBusca.php', { id: id },
            function(data) {
            data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.  
             $('#id').val(data[0].id);
             $('#registro_profissionals').val(data[0].registro_profissional);
             $('#nivel_acessos').append('<option value="'+data[0].nivel_acesso+'">&emsp;'+data[0].nivel_acesso+'</option>'+'<option value="Administrador/Dentista">&emsp;Administrador/Dentista</option>'+'<option value="Administradora">&emsp;Administradora</option>'+'<option value="Administrador">&emsp;Administrador</option>'+'<option value="Dentista">&emsp;Dentista</option>'+'<option value="Secretária">&emsp;Secretária</option>'+'<option value="Secretário">&emsp;Secretário</option>');
             $('#nomes').val(data[0].nome);
             $('#dt_nascimentos').val(moment(data[0].dt_nascimento).format('DD/MM/YYYY'));
             $('#cpfs').val(data[0].cpf);
             $('#rgs').val(data[0].rg);
             $('#especialidades').append('<option value="'+data[0].especialidade+'">&emsp;'+data[0].especialidade+'</option>'+'<option value="Clínico Geral">&emsp;Clínico Geral</option>'+'<option value="Ortodontia">&emsp;Ortodontia</option>'+'<option value="Endodontia">&emsp;Endodontia</option>'+'<option value="Implantodontia">&emsp;Implantodontia</option>'+'<option value="Dentística">&emsp;Dentística</option>'+'<option value="Periodontia">&emsp;Periodontia</option>'+'<option value="Odontopediatria">&emsp;Odontopediatria</option>'+'<option value="Bucomaxilofacial">&emsp;Bucomaxilofacial</option>'+'<option value="Cirurgia e Traumatologia Buco">&emsp;Cirurgia e Traumatologia Buco</option>'+'<option value="Radiologia">&emsp;Radiologia</option>'+'<option value="Dentística Restauradora">&emsp;Dentística Restauradora</option>'+'<option value="Ortodontia e Ortopedia Facial">&emsp;Ortodontia e Ortopedia Facial</option>'+'<option value="Ortopedia Funcional dos Maxilares">&emsp;Ortopedia Funcional dos Maxilares</option>'+'<option value="Saúde Coletiva">&emsp;Saúde Coletiva</option>'+'<option value="Estomatologia">&emsp;Estomatologia</option>'+'<option value="Patologia Bucal">&emsp;Patologia Bucal</option>'+'<option value="Odontologia do Trabalho">&emsp;Odontologia do Trabalho</option>');
             $('#emails').val(data[0].email);
             $('#telefoneFixos').val(data[0].telefone_residencial);
             $('#celulars').val(data[0].telefone_celular);
             $('#ceps').val(data[0].cep);
             $('#numeros').val(data[0].numero);
             $('#ruas').val(data[0].rua);
             $('#bairros').val(data[0].bairro);
             $('#cidades').val(data[0].cidade);
             $('#ufs').val(data[0].estado);

            });

        }
        



      //EDICAO 
        function editar_usuario(){
            var id=$('#id').val();
            var registro_profissional=$('#registro_profissionals').val();
            var nivel_acesso=$('#nivel_acessos').val();
            var nome=$('#nomes').val();
            var dt_nascimento=$('#dt_nascimentos').val();
            var cpf=$('#cpfs').val();
            var rg=$('#rgs').val();
            var especialidade=$('#especialidades').val();
            var email=$('#emails').val();
            var telefone_residencial=$('#telefoneFixos').val();
            var telefone_celular=$('#celulars').val();
            var cep=$('#ceps').val();
            var numero=$('#numeros').val();
            var rua=$('#ruas').val();
            var bairro=$('#bairros').val();
            var cidade=$('#cidades').val();
            var uf=$('#ufs').val();

            if (editarUsuario.registro_profissionals.value == "")
            {
            editarUsuario.registro_profissionals.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha Registro Profissional!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });
            return (false);
            }

            if (editarUsuario.nivel_acessos.value == "")
            {
            editarUsuario.nivel_acessos.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Tipo de Acesso!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });            
            
            return (false);
            }
            
            if (editarUsuario.nomes.value == "")
            {
            editarUsuario.nomes.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Nome do Usuário!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });            
            return (false);
            }
            
            if (editarUsuario.dt_nascimentos.value == "")
            {
            editarUsuario.dt_nascimentos.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha a data de nascimento!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });           
            return (false);
            }
            
            if (editarUsuario.cpfs.value == "")//form
            {
            editarUsuario.cpfs.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o CPF do Usuário!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });       
            return (false);
            }
            
            if (editarUsuario.rgs.value == "")
            {
            editarUsuario.rgs.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o RG do Usuário!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });       
            return (false);
            }

            if (editarUsuario.celulars.value == "")
            {
            editarUsuario.celulars.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Telefone Celular!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });               
            return (false);
            }

            $.ajax({
                    url:'../controllers/Usuario.php',
                    type:'POST',
                    data:'id='+id+'&registro_profissional='+registro_profissional+'&nivel_acesso='+nivel_acesso+'&nome='+nome+'&dt_nascimento='+dt_nascimento+'&cpf='+cpf+'&rg='+rg+'&especialidade='+especialidade+'&email='+email+'&telefone_residencial='+telefone_residencial+'&telefone_celular='+telefone_celular+'&cep='+cep+'&numero='+numero+'&rua='+rua+'&bairro='+bairro+'&cidade='+cidade+'&uf='+uf+'&botao=editarUsuario'
                }).done(function(resposta){
                    if (resposta) {
                      $('#EditarUsuarios').modal('hide'); 
                        swal({
                            title: "Processo Concluído!",
                            text: "Registro atualizado com sucesso!",
                            type: "success",
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });
                       setTimeout('window.location.href=("usuarios");', 1700);
                    }

                    
                });
            
            }


             function deletarUsuario(id){
                var id=id          
                    swal({
                        title: 'Você tem certeza?',
                        text: "A Conta será excluída permanentemente!",
                        type: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Sim',
                        cancelButtonText: "Cancelar",   
                        closeOnConfirm: false,   
                        closeOnCancel: false
                        },

                    function(isConfirm){   
                        if (isConfirm){     
                            swal({
                            title: "Processo Concluído!",
                            text: "Registro excluído com sucesso!",
                            type: "success",
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });
                        $.ajax({
                            url: '../controllers/Usuario.php',
                            type: "POST",
                            data: 'id='+id+"&botao=excluirUsuario"
                        });
                         setTimeout('location.reload();', 1700);
                        }
                        else{     
                            swal({
                            title: "Processo Cancelado!",
                            text: "Registro não excluído!",
                            type: "error",
                            timer: 1700,
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });   
                           }
                          });
                        }
        

   
     function mudarSenha() {
        var id_usuario = $("#id_usuario").val();
        var nova_senha = $("#nova_senha").val();
        var confirmar_senha = $("#confirmar_senha").val();

       if (altera_senha.nova_senha.value == ""){
           $('#nova_senha').val("");
           document.getElementById("nova_senha").focus();
           swal({
           title:"Campo Obrigatório!",
           text: "Por Favor, Digite uma Senha!",
           type: "error",
           timer: 1800,
           showCancelButton: false, 
           showConfirmButton: false 
           });               
        return (false);
       }
       if (altera_senha.confirmar_senha.value == ""){
           $('#confirmar_senha').val("");
           document.getElementById("confirmar_senha").focus();
           swal({
           title:"Campo Obrigatório!",
           text: "Por Favor, Confirme a Senha!",
           type: "error",
           timer: 1800,
           showCancelButton: false, 
           showConfirmButton: false 
           });               
        return (false);
       }
       if (nova_senha===confirmar_senha ) {
          $("#alteraSenha").modal('hide');
          swal({
            title: 'Você tem certeza?',
            text: "Sua senha será alterada permanentemente!", 
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Sim',
            cancelButtonText: "Cancelar",   
            closeOnConfirm: false,   
            closeOnCancel: true
            },
           function(isConfirm){   
            if (isConfirm){ 
                $.ajax({
                  url: '../controllers/Usuario.php',
                  type: "POST",
                  data: 'id_usuario='+id_usuario+'&nova_senha='+nova_senha+"&botao=alterarSenha"
                }).done(function(resposta){
                   if (resposta) {
                   swal({
                   title: "Processo Concluído!",
                   text: "Senha alterada, reiniciando o Sistema..." ,
                   type: "success",
                   showCancelButton: false, 
                   showConfirmButton: false
                  });
                 }
                })
                window.setTimeout(function () {
                fechar()
                }, 3000); 
               }
             });
           }
           else{
            swal({
            title:"Processo Cancelado!",
            text: "Por Favor, verifique a Senha digitada!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });   
           }
        }
        
