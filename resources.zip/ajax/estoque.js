if($("#tbConvenios tr").length == 1){
  $("#tbConvenios").css("display", "none");
  $("#smile").show();
}
else{
  var tb = ($("#tbConvenios  tr").length)-1;
  $("#smile").hide();
}   


//FUNCAO QUE CADASTRA O CONVENIO
        function cadastrar_produto(){
          var codigo = $('#codigo').val();
          $('#CadastroProdutos').modal('hide'); 
          $.post('../models/RegistroDuplicadoEstoque.php', {codigo:codigo},
            function(data) {
            data = $.parseJSON(data);
            if(data==true){
             swal({
              title: "Processo Cancelado!",
              text: "Produto já Cadastrado!",
              type: "error",
              timer: 1800,
              showCancelButton: false, 
              showConfirmButton: false 
             });
              window.setTimeout(function () {
                $('#CadastroProdutos').modal('show');
                $('#codigo').val("");
                document.getElementById("codigo").focus();
              }, 1800);  
            }
            else{
            var id_usuario=$('#id_usuario').val();
            var nota_fiscal=$('#nota_fiscal').val();
            var codigo=$('#codigo').val();
            var produto=$('#produto').val();
            var fornecedor=$("#fornecedor option:selected").val();
            var quantidade=$('#quantidade').val();
            var estoque_minimo=$('#estoque_minimo').val();
            var valor_unitario=$('#valor_unitario').val();

            if (cadastroProduto.nota_fiscal.value == "") {
            cadastroProduto.nota_fiscal.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha com o número da Nota Fiscal!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });            
            return (false);
            }
            
            if (cadastroProduto.produto.value == "") {
            cadastroProduto.produto.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha com o Produto!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });            
            return (false);
            }
            if (cadastroProduto.quantidade.value == "") {
            cadastroProduto.quantidade.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha a Quantidade!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });            
            return (false);
            }
            if (cadastroProduto.estoque_minimo.value == "") {
            cadastroProduto.estoque_minimo.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Estoque Mínimo!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });            
            return (false);
            }
            if (cadastroProduto.valor_unitario.value == "") {
            cadastroProduto.valor_unitario.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Valor Unitário!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });            
            return (false);
            }
            $.ajax({
                url:'../controllers/Estoque.php',
                type:'POST',
                data:'id_usuario='+id_usuario+'&nota_fiscal='+nota_fiscal+'&codigo='+codigo+'&produto='+produto+'&fornecedor='+fornecedor+'&quantidade='+quantidade+'&estoque_minimo='+estoque_minimo+'&valor_unitario='+valor_unitario+'&botao=cadastrarProduto'
                }).done(function(resposta){
                    if (resposta) {
                      $('#CadastroProdutos').modal('hide'); 
                        swal({
                            title: "Processo Concluído!",
                            text: "Cadastro realizado com sucesso!",
                            type: "success",
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });
                      setTimeout('location.reload();', 1700);
                    }         
                 });
                }
              })
            }


      //EDICAO DADOS 
        function editar_produto(){

            var id=$('#id').val();
            var nota_fiscal=$('#nota_fiscals').val();
            var codigo=$('#codigos').val();
            var produto=$('#produtos').val();
            var fornecedor=$("#fornecedors").val();
            var quantidade=$('#quantidades').val();
            var estoque_minimo=$('#estoque_minimos').val();
            var valor_unitario=$('#valor_unitarios').val();

            $.ajax({
                    url:'../controllers/Estoque.php',
                    type:'POST',
                    data:'id='+id+'&nota_fiscal='+nota_fiscal+'&codigo='+codigo+'&produto='+produto+'&fornecedor='+fornecedor+'&quantidade='+quantidade+'&estoque_minimo='+estoque_minimo+'&valor_unitario='+valor_unitario+'&botao=editarProduto'
                }).done(function(resposta){
                    if (resposta) {
                        swal({
                            title: "Processo Concluído!",
                            text: "Registro atualizado com sucesso!",
                            type: "success",
                            showCancelButton: false, 
                            showConfirmButton: false 
                        });
                      setTimeout('window.location.href=("estoque");', 1700);
                    }
                 });
              }

              function deletar(id){
                 var id=id        
                    swal({
                        title: 'Você tem certeza?',
                        text: "O Registro será excluído permanentemente!",
                        type: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Sim',
                        cancelButtonText: "Cancelar",   
                        closeOnConfirm: false,   
                        closeOnCancel: false
                        },

                      function(isConfirm){   
                        if (isConfirm){     
                            swal({
                            title: "Processo Concluído!",
                            text: "Registro excluído com sucesso!",
                            type: "success",
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });
                        $.ajax({
                            url: '../controllers/Estoque.php',
                            type: "POST",
                            data: 'id='+id+"&botao=excluirProduto"
                        });
                         setTimeout('location.reload();', 1700);
                        }
                        else{     
                            swal({
                            title: "Processo Cancelado!",
                            text: "Registro não excluído!",
                            type: "error",
                            timer: 1700,
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });   
                           }
                          });
                        }
        

                function consumir(id) {
                  var id=id
                   $.post('../models/EstoqueBusca.php', { id: id },
                    function(data) {
                      data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.                             
                      swal({
                        title: 'Você tem certeza?',
                        text: "Deseja Consumir 01 " + data[0].produto,
                        type: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Sim',
                        cancelButtonText: "Cancelar",   
                        closeOnConfirm: false,   
                        closeOnCancel: false
                       },
                      function(isConfirm){   
                        if (isConfirm){     
                            swal({
                            title: "Processo Concluído!",
                            text: "Produto Consumido com sucesso!",
                            type: "success",
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });
                        $.ajax({
                            url: '../controllers/Estoque.php',
                            type: "POST",
                            data: 'id='+id+'&quantidade='+data[0].quantidade+"&botao=consumirProduto"
                        });
                         setTimeout('location.reload();', 1200);
                        }
                        else{     
                            swal({
                            title: "Processo Cancelado!",
                            text: "O Produto não foi Consumido!",
                            type: "error",
                            timer: 1700,
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });   
                          }
                       });
                    }); 
                 }
        

   