if($("#tbAtestado tr").length == 1){
  $("#tbAtestado").css("display", "none");
  $("#smile").show();
  }
  else{
  var tb = ($("#tbAtestado  tr").length)-1;
  $("#smile").hide();
 }

//FUNCAO QUE CADASTRA A ATESTADO
function cadastrar_atestado(){
    var id_usuario=$('#id_usuario').val();
    var id_paciente=$('#id_paciente').val();
    var tipo_atestado = $('input:radio[name=tipo_atestado]:checked').val(); 
    var nome_empresa=$('#nome_empresa').val();
    var data_consulta=$('#data_consulta').val();
    var inicio_consulta=$('#inicio_consulta').val();
    var fim_consulta=$('#fim_consulta').val();
    var tempo_dispensa=$('#tempo_dispensa').val();
    var cid=$('#cid').val();

    if (tipo_atestado == "Atestado Odontológico" && nome_empresa == ""){

       swal({
           title: "Processo Cancelado!",
           text: "Digite o Nome da Instituição ou Empresa!",
           type: "error",
           timer: 1400,
           showCancelButton: false, 
           showConfirmButton: false 
       }); 

    }
    else if (tipo_atestado == "Atestado Odontológico" && cid == ""){

       swal({
           title: "Processo Cancelado!",
           text: "Digite o CID!",
           type: "error",
           timer: 1400,
           showCancelButton: false, 
           showConfirmButton: false 
       }); 

    }

    else if (tipo_atestado == "Atestado de Comparecimento" && nome_empresa == ""){

       swal({
           title: "Processo Cancelado!",
           text: "Digite o Nome da Instituição ou Empresa!",
           type: "error",
           timer: 1400,
           showCancelButton: false, 
           showConfirmButton: false 
       }); 

    }

    else if (tipo_atestado == "Atestado de Sanidade Bucal" && nome_empresa == ""){

       swal({
           title: "Processo Cancelado!",
           text: "Digite o Nome da Instituição ou Empresa!",
           type: "error",
           timer: 1400,
           showCancelButton: false, 
           showConfirmButton: false 
       }); 

    }
    else{
    $.ajax({
      url:'../controllers/Atestado.php',
      type:'POST',
      data:'id_usuario='+id_usuario+'&id_paciente='+id_paciente+'&tipo_atestado='+tipo_atestado+'&nome_empresa='+nome_empresa+'&data_consulta='+data_consulta+'&inicio_consulta='+inicio_consulta+'&fim_consulta='+fim_consulta+'&tempo_dispensa='+tempo_dispensa+'&cid='+cid+'&botao=cadastrarAtestado'
    }).done(function(resposta){
        if (resposta) {
            $('#Atestado').hide();
            swal({
                title: 'Deseja Imprimir o Atestado?',
                text: "Caso cancele, poderá imprimir depois!",
                type: 'info',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sim',
                cancelButtonText: "Cancelar",   
                closeOnConfirm: false,   
                closeOnCancel: false
                },

            function(isConfirm){   
                if (isConfirm){     
                    swal({
                    title: "Processo Concluído!",
                    text: "Atestado Impresso com sucesso!",
                    type: "success",
                    showCancelButton: false, 
                    showConfirmButton: false 
                    });
                    window.open('imprimir/atestado','_blank');
                    setTimeout('location.reload();', 1700);
                }
                else{     
                    swal({
                    title: "Processo Cancelado!",
                    text: "Atestado Não Impresso!",
                    type: "error",
                    timer: 1700,
                    showCancelButton: false, 
                    showConfirmButton: false 
                    });   
                    }
                });
             }
        });     
    }
}

function imprimirAtestado(id_atestado){
    var id=id_atestado
    var randomico=$('#randomico').val();
    var codigo = randomico+btoa(id);
    setTimeout('location.reload();', 1000);
    window.open('imprimir/atestados?@='+codigo, '_blank');
}

   function deletarAtestado(id_atestado){
                var id=id_atestado;
                    swal({
                        title: 'Você tem certeza?',
                        text: "O Atestado será excluído permanentemente!",
                        type: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Sim',
                        cancelButtonText: "Cancelar",   
                        closeOnConfirm: false,   
                        closeOnCancel: false
                        },

                    function(isConfirm){   
                        if (isConfirm){     
                            swal({
                            title: "Processo Concluído!",
                            text: "Atestado excluído com sucesso!",
                            type: "success",
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });
                        $.ajax({
                            url: '../controllers/Atestado.php',
                            type: "POST",
                            data: 'id='+id+"&botao=excluirAtestado"
                        });
                         setTimeout('location.reload();', 1700);
                        }
                        else{     
                            swal({
                            title: "Processo Cancelado!",
                            text: "Atestado não excluído!",
                            type: "error",
                            timer: 1700,
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });   
                           }
                          });
                        }


  $(":radio").bind("click", function desabilita(elemento){
   if($(this).val() == "Atestado de Comparecimento") {
    $("#nome_empresa").attr({readonly: false}); // Habilita
    $("#data_consulta").attr({readonly: false}); // Habilita
    $("#inicio_consulta").attr({readonly: false}); // Habilita
    $("#fim_consulta").attr({readonly: false}); // Habilita
    $("#cid").attr({readonly: true}); // Desabilita
    $(tempo_dispensa).attr({disabled: true});
  } 
   else if($(this).val() == "Atestado de Sanidade Bucal") {
    $("#nome_empresa").attr({readonly: false}); // Desabilita
    $("#data_consulta").attr({readonly: true}); // Desabilita
    $("#inicio_consulta").attr({readonly: true}); // Desabilita
    $("#fim_consulta").attr({readonly: true}); // Desabilita
    $("#cid").attr({readonly: true}); // Desabilita
    $(tempo_dispensa).attr({disabled: true});
  }
   else {
    $("#nome_empresa").attr({readonly: false}); // Habilita
    $("#data_consulta").attr({readonly: false}); // Habilita
    $("#inicio_consulta").attr({readonly: false}); // Habilita
    $("#fim_consulta").attr({readonly: false}); // Habilita
    $("#cid").attr({readonly: false}); // Habilita
    $(tempo_dispensa).attr({disabled: false});
  }
});


$( function() {
var availableTags = [
"K00 Distúrbios do desenvolvimento e da erupção dos dentes Exclui: dentes inclusos e impactados (K01.-)",
"K00.0 Anodontia",
"K00.00 Anodontia parcial [hipodontia] [oligodontia]",
"K00.01 Anodontia total",
"K00.09 Anodontia inespecífica",
"K00.1 Dentes supranumerários Inclui: dentes suplementares Exclui: dentes supranumerários impactos (K01.18)",
"K00.l0 Regiões dos incisivos e dos caninos Mesiodens",
"K00.11 Região dos pré-molares",
"K00.12 Região dos molares Distomolar Paramolar Quarto motor",
"K00.19 Dentes supranumerários, não especificados",
"K00.2 Anomalias do tamanho e da forma dos dentes",
"K00.20 Macrodontia",
"K00.21 Microdontia",
"K00.22 Concrescência",
"K00.23 Fusão e germinação Esquizodontia Sinodontia",
"K00.24 Dente evaginado [tubérculo oclusal] Exclui: tubérculo de Carabelli, que é considerado uma variação normal e não deve ser codificado",
"K00.25 Dente invaginado ['dens in dente'] [odontoma dilatado] e anomalias dos incisivos Sulco palatal Forma de cavilha [cônica] Forma de pá Forma de T ",
"K00.26 Pré-molarização",
"K00.27 Tubérculos anormais e pérolas de esmalte[enameloma] Exclui: dente evaginado [tubérculo oclusal] (K00.24) tubérculo de Carabelli, que é considerado uma variação normal e não deve ser codificado",
"K00.28 Taurodontismo",
"K00.29 Anormalidades inespecíficas e outras do tamanho e da forma dos dentes",
"K00.3 Dentes manchados Exclui: depósitos [acreções] nos dentes (K03.6) Dentes de Turner (K00.46)",
"K00.30 Manchas do esmalte endêmicas (fluoreto) [fluorose dental]",
"K00.31 Manchas do esmalte não-endêmicas [opacidade do esmalte não associadas ao fluoreto]",
"K00.39 Dentes manchados, não especificado",
"K00.4 Distúrbios na formação dos dentes Exclui: distúrbios hereditários da estrutura dental (K00.5) Incisivos de Hutchinson (A50.51) Dentes manchados (K00.3) Molares em amora (A50.52)",
"K00.40 Hipoplasia do esmalte",
"K00.41 Hipoplasia pré-natal do esmalte",
"K00.42 Hipoplasia neonatal do esmalte",
"K00.43 Aplasia e hipoplasia do cemento",
"K00.44 Dilaceração",
"K00.45 Odontodisplasia[odontodisplasia regional]",
"K00.46 Dente de Turner",
"K00.48 Outros distúrbios da formação dentária especificados",
"K00.49 Distúrbio na formação dentária, não especificados",
"K00.5 Anomalias hereditárias da estrutura dentária, não classificadas em outra parte",
"K00.50 Amelogênese imperfeita",
"K00.51 Dentinogênese imperfeita. Alterações dentárias na osteogênese imperfeita Exclui. displasia da dentina (K00.58) dente em concha (K00.58)",
"K00.52 Odontogênese imperfeita",
"K00.58 Outros distúrbios hereditários da estrutura dentária Dente em concha Displasia de dentina",
"K00.59 Anomalias hereditárias da estrutura dentária, inespecíficas",
"K00.6 Distúrbios da erupção dentária",
"K00.60 Dentes natais",
"K00.61 Dentes neonatais",
"K00.62 Erupção prematura dos dentes ['dentia praecox']",
"K00.63 Dentes temporários [decíduos] retidos [persistentes]",
"K00.64 Erupção tardia",
"K00.65 Queda prematura de dentes temporários [decíduos], Exclui: exfoliação de dentes (atribuível à doença do tecido circundante) (K08.0X)",
"K00.68 Outros distúrbios da erupção dentária especificados",
"K00.69 Distúrbio da erupção dentária, não especificado",
"K00.7 Síndrome da erupção dentária",
"K00.8 Outros distúrbios do desenvolvimento dos dentes Inclui: manchas intrínsecas do dente SOE Exclui: descolorações de origem local (K03.6, K03.7)",
"K00.80 Alterações de cordurante a formação dos dentes, devidas a incompatibilidade de tipo sangüíneo",
"K00.81 Alterações de cor durante a formação dos dentes, devidas a malformação do sistema biliar",
"K00.82 Alterações de cor durante a formação dos dentes, devidas a porfiria",
"K00.83 Alterações de cor durante a formação dos dentes, devidas atetraciclinas",
"K00.88 Outros distúrbios especificados de desenvolvimento dos dentes",
"K00.9 Distúrbio não especificado do desenvolvimento dentário, K01 Dentes inclusos e impactados Exclui: dentes inclusos e impactados com posição anormal dos próprios dentes ou dos dentes adjacentes (K07.3)",
"K01.0 Dentes inclusos Um dente incluso é um dente que não irrompeu sem que tenha havido obstrução por outro dente",
"K01.1 Dentes impactados Um dente impactado é um dente que não irrompeu em virtude de ter havido obstrução por outro dente",
"K01.10 Incisivo superior",
"K01.11 Incisivo inferior",
"K01.12 Canino superior",
"K01.13 Canino inferior",
"K01.14 Pré-molar superior",
"K01.15 Pré-molar inferior",
"K01.16 Molar superior",
"K01,17 Molar inferior",
"K01.18 Dentes supranumerários",
"K01.19 Dente impactado não especificado",
"K02 Cárie Dentária",
"K02.0 Cáries limitadas ao esmalte Manchas brancas (cáries iniciais)",
"K02.1 Cáries da dentina",
"K02.2 Cárie do cemento",
"K02.3 Cáries dentárias estáveis",
"K02.4 Odontoclasia Melanodontia infantil Melanodontoclasia Exclui: reabsorção interna e externa dos dentes (K03.3)",
"K02.8 Outras cáries dentárias",
"K02.9 Cárie dentária, sem outra especificação K03 Outras doenças dos tecidos dentários duros Exclui: bruxismo (bruquismo) (F45.8) cárie dentária (K02.-) ranger de dentes SOE (F45.8)",
"K03.0 Atrito dentário excessivo",
"K03.00 Oclusal",
"K03.01 Proximal",
"K03.08 Outros atritos dentários especificados",
"K03.09 Atrito dentário não especificados",
"K03.1 Abrasão dentária",
"K03.10 Por dentifrício Defeito cuneiforme SOE",
"K03.11 Habitual",
"K03.12 Ocupacional",
"K03.13 Tradicional",
"K03.18 Outras abrasões dentárias especificadas",
"K03.19 Abrasão dentária, não especificadas",
"K03.2 Erosão dentária",
"K03.20 Ocupacional",
"K03.21 Devida a regurgitação ou vômito persistentes",
"K03.22 Devida a dieta",
"K03.23 Devida a drogas e medicamentos",
"K03.24 Idiopática",
"K03.28 Outras erosões dentárias especificadas",
"K03.29 Erosão dentária, não especificada",
"K03.3 Reabsorção patológica dos dentes",
"K03.30 Externa",
"K03.31 Interna [granuloma interno da polpa] [mancha rosa]",
"K03.39 Reabsorção patológica dos dentes, não especificadas",
"K03.4 Hipercementose Exclui: hipercementose na doença de Paget",
"K03.5 Ancilose dentária",
"K03.6 Depósitos [acreções] nos dentes Inclui: manchas nos dentes SOE",
"K03.60 Película pigmentada Alaranjado Negro Verde", 
"K03.61 Devido ao tabaco",
"K03.62 Porbetel",
"K03.63 Outros depósitos moles macroscópicos] Matéria alba",
"K03.64 Tártaro supragengival",
"K03.65 Tártaro subgengival",
"K03.66 Placa dentária",
"K03.68 Outros depósitos dentários especificados",
"K03.69 Depósitos dentários, não especificados",
"K03.7 Alterações pós-eruptivas da cor dos tecidos duros dos dentes Exclui: depósitos [acreções] nos dentes (K03.6)",
"K03.70 Devido a metais e compostos metálicos",
"K03.71 Devido a sangramento da polpa",
"K03.72 Devido ao hábito de mascar Por betel Tabaco",
"K03.78 Outras alterações da cor especificadas",
"K03.79 Alteração da cor não especificada",
"K03.8 Outras doenças especificadas dos tecidos duros dos dentes",
"K03.80 Dentina sensível",
"K03.81 Alterações do esmalte irradiado. Use código adicional de causa externa (Capítulo XX), se necessário, para identificar a radiação, caso a radiação tenha sido a causa.",
"K03.88 Outras doenças específicas dos tecidos duros dos dentes",
"K03.9 Doenças dos tecidos duros dos dentes, não especificada",
"K04 Doenças da polpa e dos tecidos periapicais",
"K04.0 Pulpite",
"K04.00 Inicial(hiperemia)",
"K04.01 Aguda",
"K04.02 Supurativa [abscesso pulpar]",
"K04.03 Crônica",
"K04.04 Crônica, ulcerativa",
"K04.05 Crônica, hiperplásica [pólipo pulpar]",
"K04.08 Outras pulpites especificadas",
"K04.09 Pulpite não especificada ",
"K04.1 Necrose da polpa, Gangrena da polpa",
"K04.2 Degeneração da polpa, Calcificação da polpa dentária, Cálculos da polpa dentária, Dentículos da polpa dentária",
"K04.3 Formação anormal de tecidos duros na polpa",
"K04.3X Dentina secundário ou irregular, Exclui: calcificações da polpa dentária (K04.2) cálculo da polpa dentária (K04.2)",
"K04.4 Periodontite apical aguda de origem pulpar, Periodontite apical aguda SOE",
"K04.5 Periodontite apical crônica Granuloma apical",
"K04.6 Abscesso periapical com fístula, Inclui: dental abscesso com fístula dentoalveolar abscesso periodontal de origem pulpar",
"K04.60 Fístula no antro maxilar",
"K04.61 Fístula na cavidade nasal",
"K04.62 Fístula na cavidade oral",
"K04.63 Fístula na pele",
"K04.69 Abscesso periapical com fístula, não especificado",
"K04.7 Abscesso periapical sem fístula, Abscesso dental, Abscesso dentoalveolar, Abscesso periodontal de origem pulpar, Abscesso periapical sem referência a fístula sem fístula",
"K04.8 Cisto radicular Inclui: cisto apical (periodontal) periapical",
"K04.80 Apical e lateral",
"K04.81 Residual",
"K04.82 Paradental inflamatório Exclui: cisto periodontal lateral (K09.4)",
"K04.89 Cisto radicular, não especificado",
"K04.9 Outras doenças da polpa, e dos tecidos periapicais e as não especificadas",
"K05 Gengivite e doenças periodontais, Inclui: doença do rebordo alveolar sem dentes",
"K05.0 Gengivite aguda Exclui: pericoronite aguda (K05.22) gengivite ulcerativa necrotizante aguda [gengivite por espiroquetas] [gengivite de Vincent] (A69. 10) Gengivoestomatite por Herpes Viral (800.2X)",
"K05.00 Gengivoestomatite estreptocócica aguda",
"K05.08 Outra gengivite aguda especificada",
"K05.09 Gengivite aguda, não especificada",
"K05.1 Gengivite crônica",
"K05.10 Marginal simples",
"K05.11 Hiperplásica",
"K05,12 Ulcerativa, Exclui: gengivite ulcerativa necrotizante (A69. 10)",
"K05.13 Descamativa",
"K05.18 Outras gengivites crônicas especificadas",
"K05.19 Gengivite crônica, não especificada",
"K05.2 Periodontite aguda",
"K05.20 Abscesso periodontal [abscesso parodontal] de gengival sem fístula, Abscesso periodontal de origem gengival sem referência a fístula, Exclui: periodontite apical aguda de origem pulpar (K04.4)abscesso periapical de origem pulpar (K04.6, K04.7)",
"K05.21 Abscesso periodontal [abscesso parodontal] de origem gengival com fístula Exclui: abscesso periapical agudo de origem pulpar (K04.6, K04.7) periodontite apical aguda de origem pulpar (K04.4)",
"K05.22 Pericoronite aguda ",
"K05.28 Outras periodontites agudas especificadas",
"K05.29 Periodontite aguda, não especificada",
"K05.3 Periodontite crônica",
"K05.30 Simples",
"K05.31 Complexa",
"K05.32 Pericoronarite crônica",
"K05.33 Folículo espessado",
"K05.38 Outras periodontites crônicas especificadas",
"K05.39 Periodontite crônica, não especificadas",
"K05.4 Periodontose, Periodontose juvenil",
"K05.5 Outras doenças periodontais",
"K06 Outros transtornos da gengiva e do rebordo alveolar sem dentes, Exclui: atrofia do rebordo alveolar sem dentes (K08.2) gengivite (K05.0, K05.I )",
"K06.0 Retração gengival Inclui: pós-infecciosa pós-operatória",
"K06.00 Localizada",
"K06.01 Generalizada",
"K06.09 Retração gengival, não especificada",
"K06.1 Hiperplasia gengival Inclui: tuberosidade",
"K06.10 Fibromatose gengival",
"K06.18 Outras hiperplasias gengivais especificadas",
"K06.19 Doenças do Aparelho Digestivo 69",
"K06.2 Lesões da gengiva e do rebordo alveolar sem dentes, associadas a traumatismos",
"K06.20 Devido a oclusão traumática",
"K06.21 Devido a escovação",
"K06.22 Queratose por atrito [funcional]",
"K06.23 Hiperplasia irritativa do rebordo alveolar [hiperplasia devido à dentadura] ",
"K06.28 Outras lesões especificadas da gengiva e do rebordo alveolar sem dentes, associadas a traumatismos",
"K06.29 Lesões da gengiva e do rebordo alveolar sem dentes não especificadas, associadas a traumatismos, Outros transtornos especificados da gengiva e do rebordo alveolar sem dentes",
"K06.8 Outros Transtornos Especificados da Gengiva e do Rebordo Alveolar sem Dentes",
"K06.80 Cisto gengival do adulto Exclui: cisto gengival do recém-nascido (K09.82)",
"K06.81 Granuloma periférico de células gigantes [epúlide de células gigantes]",
"K06.82 Epúlide fibroso",
"K06.83 Granulo piogênico, Exclui: granuloma piogênico de outros locais que não sejam a gengiva ou o rebordo alveolar sem dentes",
"K06.84 Rebordo gengival flutuante",
"K06.88 Outros",
"K06.9 Transtornos da gengiva e do rebordo alveolar sem dentes, sem outra especificação",
"K07 Anomalias dento faciais (inclusive a maloclusão)",
"K07.0 Anomalias importantes (major) do tamanho da mandíbula, Exclui: acromegalia(E22.0) atrofia ou hiperplasia hemifacial (Q67.4) hiperplasia condilar unilateral (K lo-g1) hipoplasia condilar unilateral (Kl 0.82) síndrome de Robin (Q87.0)",
"K07.00 Macrognatismo maxilar[hiperplasia maxilar]",
"K07.01 Macrognatismo mandibular[hiperplasia mandibular]",
"K07.02 Macrognatismo, ambos os maxilares",
"K07.03 Micrognatismo maxilar[hipoplasia maxilar]",
"K07.04 Micrognatismo mandibular[hipoplasia mandibular]",
"K07.05 Micrognatismo, ambos os maxilares",
"K07.08 Outras anomalias do tamanho da mandíbula especificada",
"K07.09 Anomalia do tamanho da mandíbula, não especificada",
"K07.1 Anomalias da relação entre a mandíbula com a base do crânio",
"K07.10 Assimetrias, Exclui: atrofia hemifacial (Q64.40) hiperplasia condilar unilateral (K lo-g1) hipertrofia hemifacial (Q67.41) hipoplasia condilar unilateral (Kl 0.82)",
"K07.11 Prognatismo mandibular",
"K07.12 Prognatismo maxilar",
"K07.13 Retrognatismo mandibular",
"K07.14 Retrognatismo maxilar",
"K07.18 Outras anomalias especificadas da relação entre a mandíbula e a base do crânio",
"K07.19 Anomalia não especificada da relação entre a mandíbula e a base do crânio",
"K07.1 Anomalias da relação entre as arcadas dentárias",
"K07.20 Disto-oclusão",
"K07.21 Mésio-oclusão",
"K07.22 Superposição excessiva [mordida horizontal]",
"K07.23 Sobremordida excessiva[vertical]",
"K07.24 Mordida aberta",
"K07.25 Mordida cruzada (anterior, posterior)",
"K07.26 Desvio da linha mediana",
"K07.27 Oclusão lingual posterior dos dentes inferiores",
"K07.28 Outras anomalias especificadas da relação entre as arcadas dentárias",
"K07.29 Anomalia da relação entre as arcadas dentárias, não especificadas",
"K07.3 Anomalias da posição dos dentes",
"K07.30 Apinhamento Imbricação",
"K07.31 Deslocamento",
"K07.32 Rotação",
"K07.33 Espaçamento anormal Diastema",
"K07.34 Transposição",
"K07.35 Dentes inclusos ou impactados com posição anormal, Exclui: dentes inclusos ou impactados sem que haja ano de posição (K01.0, K01,1)",
"K07.38 Outrasanomalias especificadas da posição dos dentes",
"K07.39 Anomalia da posição dos dentes, não especificada",
"K07.4 Má oclusão, não especificada",
"K07.5 Anormalidades dento faciais funcionais, Exclui: bruxismo [ranger de dentes] (F45.82)",
"K07.50 Fechamento anormal dos maxilares",
"K07.51 Má oclusão devido à deglutição anormal",
"K07.54 Má oclusão devido à respiração pela boca",
"K07.55 Má oclusão devido a hábitos linguais, labiais ou chupar os dedos",
"K07.58 Outras anornalidades dento faciais funcionais especificadas",
"K07.59 Anormalidade dento facial funcional, não especificada",
"K07.6 Distúrbios da articulação temporomandibular",
"K07.60 Síndrome da dor e disfunção da articulação temporomandibular [Costen] Exclui: deslocamento (503.0) temporomandibular eluxação(503.4) da articulação doenças relacionadas no Capítulo XIII",
"K07.61 Click dos mandibulares",
"K07.62 Deslocamento e subluxação recorrentes da articulação temporomandibular Exclui: lesão atual (503.0)",
"K07.63 Dor na articulação temporomandibular, não classificada em outra parte Exclui: síndrome dolorosa da disfunção da articulação temporomandibular [Costen](K07.60)",
"K07.64 Rigidez da articulação temporomandibular, não classificada em outra parte",
"K07.65 Osteófito da articulação temporomandibular",
"K07.68 Outras doenças especificadas da articulação temporomandibular",
"K07.69 Distúrbio da articulação temporomandibular, não especificada",
"K08 Outros transtornos dos dentes e de suas estruturas de sustentação",
"K08.0 Exfoliação dos Dentes devido a Causas Sistêmicas Exclui: Anodontia (K00.0)",
"K08.0X Exfoliação dos dentes devido a doenças dos tecidos circundantes, inclusive causas sistêmicas, como acrodinia(T56.1), hipofosfatase(E83.3) Exclui: erupção prematura de dentes temporários [decíduos](K00.65)",
"K08.1 Perda de dentes devido a acidente, extração ou a periodontais localizadas Exclui: acidente atual (503.2)",
"K08.2 Atrofia do rebordo alveolar sem dentes",
"K08.3 Raiz dentária retida",
"K08.8 Outros transtornos especificados dos dentes e das estruturas de sustentação",
"K08.80 Dor de dente SOE",
"K08.81 Irregularidade do processo alveolar",
"K08.82 Hipertrofia do rebordo alveolar SOE",
"K08.88 Outros",
"K08.9 Transtorno dos dentes e de suas estruturas de sustentação, sem outra especificação",
"K09 Cistos da região bucal, não classificados em outra parte, Exclui: cisto radicular (K04.8) cisto mucoso (Kl1.6)",
"K09.0 Cistos odontogênicos de desenvolvimento",
"K09.00 Erupção",
"K09.01 Gengival",
"K09.02 Queratocisto [primordial]",
"K09.03 Folicular [dentígero]",
"K09.04 Periodontal lateral",
"K09.08 Outros cistos odontogênicos de desenvolvimento especificados",
"K09.09 Cisto odontogênico de desenvolvimento, nãoe specificado",
"K09.1 Cistos de desenvolvimento (não-odontogênicos) da região bucal Inclui: cistos de 'fissuras'",
"K09.10 Globulo maxilar",
"K09.11 Mesopalatino",
"K09.12 Nasopalatino [canal dos incisivos]",
"K09.13 Papilapalatina",
"K09.18 Outros cistos de desenvolvimento da região bucal especificados",
"K09.19 Cisto de desenvolvimento da região bucal, não especifica",
"K09.2 Outros cistos das mandíbulas, Exclui: cisto ósseo latente dos maxilares (K10.02) cisto de Stafne (K10.02)",
"K09.20 Cisto ósseo aneurismático2",
"K09.21 Cisto ósseo solitário [traumático] [hemorrágico]",
"K09.22 Cistos epiteliais dos maxilares não identificáveis como dontogênicos ou não odontogênicos",
"K09.28 Outros cistos dos maxilares especificados ",
"K09.29 Cisto da mandíbula, não especificado",
"K09.8 Outros cistos da região oral, não classificados em outra parte",
"K09.80 Cisto dermóide",
"K09.81 Cisto epidermóide",
"K09.82 Cisto gengival do recém-nascido, Exclui: cisto gengival do adulto (K06.80)",
"K09.83 Cisto palatino do recém-nascido, Pérolas de Epstein",
"K09.84 Cisto nasoalveolar[nasolabial]",
"K09.85 Cisto linfoepitelial da boca",
"K09.88 Outros cistos da região oral especificados",
"K09.9 Cistos da região oral, sem outras especificações",
"K10 Outras doenças dos maxilares",
"K10.0 Distúrbios do desenvolvimento dos maxilares",
"K10.00 Torus mandibular",
"K10-01 Torus palatino",
"K10.02 Cisto ósseo latente, Cisto de StaÍne, Cisto ósseo estático, Defeito ósseo de desenvolvimento na mandíbula",
"K10.08 Outros distúrbios de desenvolvimento dos maxilares",
"K10.09 Distúrbios de desenvolvimento dos maxilares, não especificados",
"K10.1 Granuloma central de células gigantes, Granuloma de células gigantes SOE, Exclui: granuloma periférico de células gigantes (k06.81)",
"K10.2 Afecções inflamatórias dos maxilares, Use código adicional para causa externa (Capítulo XX), se necessário, para, identificar radiação, se por causada por radiação.",
"R10.20 Osteíte dos maxilares, Exclui: osteíte alveolar (K10.3)",
"Alveolite seca (K10.3)",
"K10.21 Osteomielite dos maxilares, Exclui: osteomielite neonatal maxilar [maxilite neonatal] (K10.24)",
"K10.22 Periostite dos maxilares", 
"K10.23 Periostite maxilar crônica, Granulomapulsante, Microangiopatiahialina",
"K10.24 Osteomielite neonatal maxilar",
"K10.25 Seqüestro ósseo maxilar",
"K10.26 Osteorradionecrose",
"K10.28 Outras afecções inflamatórias dos maxilares especificadas",
"K10.29 Afecção inflamatória dos maxilares, não especificada",
"K10.3 Alveolite dos maxilares, Osteíte alveolar, Alveolite seca",
"K10.8 Outras doenças especificadas dos maxilares, Exclui: displasia fibrosa, poliostótica (Q78, I )",
"K10.80 Querubismo",
"K10.81 Hiperplasia condilar unilateral",
"K10.82 Hipoplasia condilar unilateral",
"K10.83 Displasiafibrosa dos maxilares",
"K10.88 Outras doenças dos maxilares especificadas, Exostose maxilar",
"K10.9 Doença dos maxilares, não especificadas",
"K11 Doenças das glândulas salivares, Exclui: tumores das glândulas salivares (C07.- C08.-, D 10.-, Dl1.",
"K11.0 Atrofia de glândula salivar",
"K11.l Hipertrofia de glândula salivar",
"K11.2 Sialadenite, Exclui: parotidite epidêmica [caxumba] (826.-) uveoparotidite [febre de Heerfordt] (D86.8)",
"K11.3 Abscesso de glândula salivar",
"K11.4 Fístula de glândula salivar, Exclui: fístula congênita de glândula salivar (Q38.43)",
"K11.5 Sialolitíase, Cálculo [pedra] de canal salivar",
"K11.6 Mucocele de glândula salivar Rânula",
"K11.60 Cisto mucoso de retenção",
"K11.61 Cisto mucoso de extravasamento",
"K11.69 Mucocele de glândula salivar, não especificada",
"K11.7 Alterações da secreção salivar, Exclui: boca seca SOE(R68.2) síndrome seca [Sjögren] (M35.0)",
"K11.70 Hipossecreção",
"K11.71 Xerostomia",
"K11.72 Hipersecreção",
"K11.78 Outros distúrbios da secreção salivar especificados",
"K11.79 Distúrbios da secreção salivar, não especificados",
"K11.8 Outras doenças das glândulas salivares, Exclui: síndrome seca [Sjögren] (M35.0)",
"K11.80 Lesão linfo epitelial benigna de glândula salivar",
"K11.81 Doença de Mikulicz",
"K11.82 Estenose de canal salivar",
"K11.83 Sialectasia",
"K11.84 Sialose",
"K11.85 Sialometaplasia necrotizante",
"K11.88 Outras doenças das glândulas salivares especificadas",
"K11.9 Doença da glândula salivar, sem outra especificação Sialoadenopatia SOE",
"Kl2 Estomatite e lesões correlatas",
"Kl2.0 Aftas bucais recidivantes",
"K12.00 Aftas recidivantes (minar) Aftas (minar) Aftose de Mikuiicz Estomatite aftosa Úlcera aftosa recidivante Ulcerosa",
"K12.01 Periadenite mucosa necrótica recidivante Aftas major Aftose de Sutton Estomatite aftosa cicatrizante",
"K12.02 Estomatite herpeti forme [erupção herpetiforme] Exclui: dermatite herpetiforme (L13.0X) gengivoestomatite por vírus do herpes simples [herpes(800.2X)",
"K12.03 Aftose de Bednar", 
"K12.04 Úlcera traumática, Exclui: úlceras da língua SOE (K14.09) úlcera traumática da língua (Kl 4.01)",
"K12.08 Outras aftas bucais recidivantes especificadas",
"K12.09 Aftas orais recidivantes, não especificadas",
"K12.1 Outras formas de estomatite",
"K12.10 Estomatite por artefato",
"K12.11 Estomatite geográfica, Exclui: língua geográfica (KI 4. I )",
"K12.12 Estomatite devido à prótese, Exclui: estomatite devido à prótese por infecção por (837.03) úlcera traumática devido à prótese (K12.04)",
"K12.13 Hiperplasia papilar do palato",
"K12.14 Estomatite de contato, Estomatite por rolo de algodão", 
"K12.18 Outras formas de estomatite especificadas",
"K12.19 Estomatite, não especificada",
"K12.2 Celulite e abscesso da boca, Flegmão, Abscesso submandibuiar, Exclui. abscesso periapicai (K04.6-K04.7) periodontai (K05.2i ) periamigdaiiano (J36) de glândula salivar (Ki1.3) l de língua (K14.00)",
"K13 Outras doenças do lábio e da mucosa oral, Inclui: afecções epiteliais da língua, Exclui: algumas afecções da gengiva e do rebordo alveolar sem dentes (K05-K06) cistos da região oral (K09.-) doenças da língua (K14.-) estomatite e lesões correlatas (Kl 2.-)",
"K13.0 Doenças dos lábios, Exclui: queilite actínica (L56.8X) arriboflavinose (E53.0)",
"K13.00 Queilite angular Queilose angular Perlèche NCOP, Exclui: perlèche devido à: l candidíase (837.0) l deficiência de riboflavina (E53.0)",
"K13.01 Queilite glandular apostematosa",
"K13.02 Queilite exfoliativa",
"K13.03 Queiliteso E",
"K13.04 Queilodinia",
"K13.08 Outras doenças do lábio especificadas",
"K13.09 Doença do lábio, não especificada",
"K13.1 Mordedura da mucosa das bochechas e dos lábios",
"K13.2 Leucoplasia e outras afecções do epitélio oral, inclusive da língua, Exclui: leucoplasia por Candida (837.02) hiperplasia epitelial focal (807.X2) queratose por atrito (K06.22) queratose funcional (K06.22) leucoplasia pilosa (Kl 3.3)",
"K13.20 Leucoplasia, idiopática",
"K13.21 Leucoplasia associada ao tabaco, Exclui: leucoceratose do palato causado pela nicotina (Kl 3.24) palato do fumante (Ki 3.24)",
"K13.22 Eritroplasia",
"K13.23 Leucoedema",
"K13.24 Palato do fumante [leucoqueratose causada pela nicotina] [estomatite nicotínica]",
"K13.28 Outras",
"K13.29 não especificadas Leucoplasia SOE",
"K13.3 Leucoplasia pilosa",
"K13.4 Lesões granulomatosas e granulomatóides da mucosa oral",
"K13.40 Granuloma piogênico, Exclui: gengiva (K06.83)",
"K13.41 Granuloma e osinófilo da mucosa oral, Exclui: granuloma cosinófilo do osso (D76.011) histiocitose X (D76.-)",
"K13.42 Xantoma verrucoso [histiocitose Y]",
"K13.48 Outras lesões granulomatóide da mucosa oral, não specificadas",
"K13.49 Lesão granulomatosa e granulomatóide da mucosa oral, não especificada",
"K13.5 Fibrose oral submucosa",
"K13.6 Hiperplasia irritativa da mucosa oral, Exclui: hiperplasia irritativa do rebordo alveolar sem dentes devido à dentadura] (K06.23)",
"K13.7 Outras lesões e as não especificadas da mucosa oral",
"K13.70 Pigmentação excessiva por melanina Melanoplasia Melanose do fumante ",
"K13.71 Fístula oral  Exclui: fístula oroantral (T81.8)",
"K13.72 Tatuagem deliberada Exclui: tatuagem por amálgama (T81.50)",
"K13.73 Mucinose oral focal",
"K13.78 Outras lesões da mucosa oral especificadas Linha alba",
"K13.79 Lesão da mucosa oral, não especificada",
"K14 Doenças da língua Exclui: eritroplasia da língua (KI 3.22) hiperplasia epitelial focal (807.X2) fibrose submucosa da língua (K13.5) leucoplasia pilosa (K13.3) leucoedema ) da língua (K13.2) leucoplasia macroglossia (congênita) (Q38.2X) 14.0 GlossiteExcluir: glossite atrófica(K14.42)",
"K14.00 Abscesso da língua",
"K14.01 Ulceração traumática da língua",
"K14.08 Outras glossites especificadas",
"Kl 4.09 Glossite, não especificada Úlcera da língua SOE",
"14.1 Língua geográfica Glossite areata exfoliativa Glossite migratória benigna Glossite rombóide mediana",
"14.2 Glossite rombóide mediana",
"14.3 Hipertrofia das papilas linguais",
"K14.30 Língua saburrosa",
"K14.31 Língua pilosa Língua pilosa negra Língua vilosa negra Exclui: leucoplasia pilosa (Kl 3.3) língua pilosa devido a antibióticos (Kl 4.38)",
"K14.32 Hipertrofia das papilas foliáceas",
"K14.38 Outras hipertrofias das papilas 1ínguais especificadas Língua pilosa devido a antibióticos",
"K14.39 Hipertrofia das papilas 1inguais, não especificadas 14.5 Língua escrotal Fissurada Gretada Língua Sulcada Exclui: língua Fissurada, congênita (Q38.33)",
"14.6 Glossodínia Exclui: anormalidades do paladar (R43.-)",
"K14.60 Glossopirose [língua queimante]",
"K14.61 Glossodínia [1íngua dolorosa]",
"K14.68 Outras glossodínias especificadas",
"K14.69 Glossodínia, não especificada",
"14.8 Outras doenças da língua",
"K14.80 Língua crenada [indentada]",
"K14.81 Hipertrofia da língua Hemi-hipertrofia da língua Exclui: macroglossia (congênita)(Q38.2X)",
"K14.82 Atrofia da língua Hemiatrofia da língua Exclui: atrofia das papilas linguais (K14.4)",
"K14.88 Outras doenças especificadas da língua Doenças da amígdala lingual",
"K14.9 Doença da língua, sem outra especificação.Glossopatia SOE"];
$( "#cid" ).autocomplete({
      source: availableTags
  });
});
