
       var date = new Date();
      
        $('#calendar').fullCalendar({

            defaultView: 'agendaWeek', //agendaWeek
            hiddenDays: [0],
            minTime: "06:00:00",
            maxTime: "24:00:00",
            allDaySlot:false,
            header: {
            left: '',
            center: 'prev, title, next',
            right: 'agendaDay,agendaWeek'
            },
       

            editable: true,
            eventLimit: true,
            selectable: true,
            selectHelper: true,
            events: "../models/AgendaBusca.php",


            select: function(start, end) {
                $('.fc-popover.click').remove();
                $('#agendar #start').val(moment(start).format('DD/MM/YYYY HH:mm'));
                $('#agendar #end').val(moment(end).format('DD/MM/YYYY HH:mm'));
                $('#agendar').modal('show');
                $(".fc-popover").hide();

            },


            eventDrop: function(event, delta, revertFunc) { // si changement de position

                edit(event);
                $('.fc-popover.click').remove();
                $(".fc-popover").hide();

            },
         
            eventResize: function(event,dayDelta,minuteDelta,revertFunc) { // si changement de longueur

                edit(event);
                $('.fc-popover.click').remove();


            },
            
            viewRender: function(view, element) {
                $(".fc-popover").hide();
                $("#side-datetimepicker").on("dp.change",function (e) {
                var consulta = $("#consulta").val();
                $('#calendar').fullCalendar( 'gotoDate', consulta );
                });
              
            },

            eventRender: function(event, element) {

                element.bind('click', function() {
                    $('#id').val(event.id);
                    $('#id_paciente').val(event.id_paciente);
                    $('#title').val(event.title);
                    $('#color').val(event.color);
                    $('#start').val(event.start);
                    $('#end').val(event.end);

                  
               });
             },

            eventClick: function(event, calEvent, jsEvent, view) {

            var eventEl = $(this);

            if (!$(this).hasClass('event-clicked')) {
                 $('.fc-event').removeClass('event-clicked');
                 $(this).addClass('event-clicked');
                 $('#id').val(event.id);
                 $('#id_paciente').val(event.id_paciente);
                 $('#title').val(event.title);
                 $('#color').val(event.color);
                 $('#start').val(event.start);
                 $('#end').val(event.end);
                
            }


            // Add popover
            $('body').append(
                '<div class="fc-popover click">' +
                    '<div class="fc-header">' +event.title+
                        '<button type="button" class="cl"><i class="font-icon-close-2"></i></button>' +
                    '</div>' +

                '<div class="fc-body main-screen">' +
                   '<p>' +moment(event.start).format('<b> dddd, DD/MM/YYYY <br> HH:mm </b>')+'<b>às</b> '+moment(event.end).format('<b>H:mm</b>')+'<b> horas</b>' +'</p>' +
                   '<p>' +'<b>Dentista<br> Dr(a) ' +event.dentista+'</b></p>' +
                        '<p class="color-blue-grey"><br/></p>' +
                        '<div class="text-center">' +
 '<a href="#" class="prontuario">'+'<button type="button" class="btn btn-rounded btn-sm btn-success-outline">'+'Prontuário'+'</button>' +'</a>'+

 '<a href="#" class="fc-event-action-edit">'+'<button type="submit" class="btn btn-rounded btn-sm btn-primary-outline">'+'Editar '+'</button>' +'</a>'+

 '<a href="#" class="deletar">'+'<button type="submit" class="btn btn-rounded btn-sm btn-danger-outline">'+'Excluir '+'</button>' +'</a>'+'</div>' +
                '</div>' +
               
                '<form>'+
                '<input type="hidden" id="id" name="id" class="form-control" value='+event.id+'>'+
                '<input type="hidden" id="deletar" name="deletar" value="1">'+ 
                '</form>' +

                '<div class="fc-body edit-event">'+
                '<p><b>Editar Status da Consulta?</b></p>'+
                '<div class="form-group">'+
                '<div class="input-group">'+

                
                '<div class="calendar-page-side-section-in">' +
                                '<ul class="colors-guide-list">' +

                '<form>'+
                '<input type="hidden" name="id"  id="id1" class="form-control" value='+event.id+'>'+
                '<input type="hidden" name="color"  id="color1" value="#0071c5">'+

                                    '<button type="button" class="enviou1" style="background-color: Transparent; border: none;">' +
                                    '<li>'+
                                        '<div class="color-double"><div></div></div>' +
                                        'Agendada'+
                                    '</li>'+
                                    '</button><br>'+
                '</form>'+


                '<form>'+
                '<input type="hidden" name="id" id="id2"   class="form-control" value='+event.id+'>'+
                '<input type="hidden" name="color" id="color2" value="#3CB371">'+
                                    '<button type="button" class="enviou2" style="background-color: Transparent; border: none;">' +
                                    '<li>' +
                                        '<div class="color-double green"><div></div></div>' +
                                        'Confirmada' +
                                    '</li>' +
                                    '</button><br>' +
                 '</form>'+

                '<form>'+
                '<input type="hidden" name="id"  id="id3"   class="form-control" value='+event.id+'>'+
                '<input type="hidden" name="color" id="color3" value="#FF6347">'+
                                    '<button type="button" class="enviou3" style="background-color: Transparent; border: none;">' +
                                    '<li>' +
                                        '<div class="color-double red"><div></div></div>' +
                                        'Cancelada' +
                                    '</li>' +
                                    '</button><br>' +
                 '</form>'+                                    

                '<form>'+
                '<input type="hidden" name="id"   id="id4"  class="form-control" value='+event.id+'>'+
                '<input type="hidden" name="color" id="color4" value="#DAA520">'+
                                    '<button type="button" class="enviou4" style="background-color: Transparent; border: none;">' +
                                    '<li>' +
                                        '<div class="color-double orange"><div></div></div>' +
                                        'Faltou' +
                                    '</li>' +
                                    '</button><br>' +
                 '</form>'+

                                '</ul>' +
                            '</div>' +
                         '</div>' +
                 '<p>__________________________</p>'+  

                 '<p><b>Editar Observações?</b></p>'+
                 '<form>'+
                 '<input type="hidden" name="idObs"   id="idObs"  class="form-control" value='+event.id+'>'+
                 '<textarea style="border:none; width:100%; height: 100px;" name="obs" id="obs" value='+event.observacao+'>'+event.observacao+'</textarea>'+'<p></p>'+
                 '<button type="button" class="btn btn-rounded btn-sm btn-success-outline col-lg-12 enviarObs">Salvar</button><br>' +
                 '</form>'+
                  '</div>' +
                '</div>'
            );
       
          $('.prontuario').click(function(e){
             var randomico=$('#randomico').val();
             var codigo = randomico+btoa(event.id_paciente);
             window.location.href = 'prontuario?@='+codigo;
           });

               //Atualizacao Status do Agendamento => Agendado
             $('.enviou1').click(function(e){
               var id = $("#id1").val();
                var color = $("#color1").val();
                 $('.fc-popover.click').remove();
                  $.ajax({
                    url: '../controllers/Agenda.php',
                    type: "POST",
                    data: 'id='+id+'&color='+color+"&botao=editarStatus",
                    success: function(e){
                      $('#calendar').fullCalendar('refetchEvents', e);  
                      $('#calendar').fullCalendar('rerenderEvents');
                    }
                });
                swal({
                    title: "Processo Concluído!",
                    text: "Agenda atualizada com sucesso!",
                    type: "success",
                    timer: 1700,
                    showCancelButton: false, 
                    showConfirmButton: false 
                 });
              });

           //Atualizacao Status do Agendamento => Confirmada
             $('.enviou2').click(function(e){
               var id = $("#id2").val();
                var color = $("#color2").val();
                 $('.fc-popover.click').remove();
                  $.ajax({
                    url: '../controllers/Agenda.php',
                    type: "POST",
                    data: 'id='+id+'&color='+color+"&botao=editarStatus",
                    success: function(e){
                      $('#calendar').fullCalendar('refetchEvents', e);  
                      $('#calendar').fullCalendar('rerenderEvents');
                    }
                });
                swal({
                    title: "Processo Concluído!",
                    text: "Agenda atualizada com sucesso!",
                    type: "success",
                    timer: 1700,
                    showCancelButton: false, 
                    showConfirmButton: false 
                 });

              });

            //Atualizacao Status do Agendamento => Cancelada 
             $('.enviou3').click(function(e){
               var id = $("#id3").val();
                var color = $("#color3").val();
                 $('.fc-popover.click').remove();
                  $.ajax({
                    url: '../controllers/Agenda.php',
                    type: "POST",
                    data: 'id='+id+'&color='+color+"&botao=editarStatus",
                    success: function(e){
                      $('#calendar').fullCalendar('refetchEvents', e);  
                      $('#calendar').fullCalendar('rerenderEvents');
                    }
                });
                 swal({
                    title: "Processo Concluído!",
                    text: "Agenda atualizada com sucesso!",
                    type: "success",
                    timer: 1700,
                    showCancelButton: false, 
                    showConfirmButton: false 
                 });
              });

             //Atualizacao Status do Agendamento => Faltou
             $('.enviou4').click(function(e){
               var id = $("#id4").val();
                var color = $("#color4").val();
                 $('.fc-popover.click').remove();
                  $.ajax({
                    url: '../controllers/Agenda.php',
                    type: "POST",
                    data: 'id='+id+'&color='+color+"&botao=editarStatus",
                    success: function(e){
                      $('#calendar').fullCalendar('refetchEvents', e);  
                      $('#calendar').fullCalendar('rerenderEvents');
                    }
                });
                swal({
                    title: "Processo Concluído!",
                    text: "Agenda atualizada com sucesso!",
                    type: "success",
                    timer: 1700,
                    showCancelButton: false, 
                    showConfirmButton: false 
                 });
              });

             //Atualizacao Observacao do Agendamento 
             $('.enviarObs').click(function(e){
               var id = $("#idObs").val();
                var observacao = $("#obs").val();
                 $('.fc-popover.click').remove();
                  $.ajax({
                    url: '../controllers/Agenda.php',
                    type: "POST",
                    data: 'id='+id+'&observacao='+observacao+"&botao=editarObservacao",
                    success: function(e){
                      $('#calendar').fullCalendar('refetchEvents', e);  
                      $('#calendar').fullCalendar('rerenderEvents');
                    }
                });
                swal({
                    title: "Processo Concluído!",
                    text: "Agenda atualizada com sucesso!",
                    type: "success",
                    timer: 1700,
                    showCancelButton: false, 
                    showConfirmButton: false 
                 });
              });

            //classe e funcao que deleta agendamento
             $('.deletar').click(function(e){
                var id = $("#id").val();
                 var deletar = $("#deletar").val();
                  e.preventDefault();
                     $('.fc-popover.click').remove();
            
                    swal({
                        title: 'Você tem certeza?',
                        text: "O Agendamento será excluído permanentemente!",
                        type: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Sim',
                        cancelButtonText: "Cancelar",   
                        closeOnConfirm: false,   
                        closeOnCancel: false
                        },

                    function(isConfirm){   
                        if (isConfirm){     
                            swal({
                            title: "Processo Concluído!",
                            text: "Agendamento excluído com sucesso!",
                            type: "success",
                            timer: 1700,
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });
                        $.ajax({
                            url: '../controllers/Agenda.php',
                            type: "POST",
                            data: 'id='+id+"&botao=excluir",
                            success: function(e){
                               $('#calendar').fullCalendar('refetchEvents', e);  
                               $('#calendar').fullCalendar('rerenderEvents');
                            }
                        });

                        }
                        else{     
                            swal({
                            title: "Processo Cancelado!",
                            text: "Agendamento não excluído!",
                            type: "error",
                            timer: 1700,
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });   
                           }
                          });
                        });



                 
            // Datepicker init
            $('.fc-popover.click .datetimepicker').datetimepicker({
                widgetPositioning: {
                    horizontal: 'right'
                }
            });

            $('.fc-popover.click .datetimepicker-2').datetimepicker({
                widgetPositioning: {
                    horizontal: 'right'
                },
                format: 'LT',
                debug: true
            });


            // Position popover
            function posPopover(){
                $('.fc-popover.click').css({
                    left: eventEl.offset().left + eventEl.outerWidth()/2,
                    top: eventEl.offset().top + eventEl.outerHeight()
                });
            }

            posPopover();

            $('.fc-scroller, .calendar-page-content, body').scroll(function(){
                posPopover();
            });

            $(window).resize(function(){
               posPopover();
            });


            // Remove old popover
            if ($('.fc-popover.click').length > 1) {
                for (var i = 0; i < ($('.fc-popover.click').length - 1); i++) {
                    $('.fc-popover.click').eq(i).remove();
                }
            }

            // Close buttons
            $('.fc-popover.click .cl, .fc-popover.click .remove-popover').click(function(){
                $('.fc-popover.click').remove();
                $('.fc-event').removeClass('event-clicked');
            });

            // Actions link
            $('.fc-event-action-edit').click(function(e){
                e.preventDefault();

                $('.fc-popover.click .main-screen').hide();
                $('.fc-popover.click .edit-event').show();
            });

            $('.fc-event-action-remove').click(function(e){
                e.preventDefault();

                $('.fc-popover.click .main-screen').hide();
                $('.fc-popover.click .remove-confirm').show();
            });
                      }
                 });


//datetipecker
   $(function () {
     $('#side-datetimepicker').datetimepicker({
     inline: true,
     format: 'YYYY/MM/DD',
     widgetPositioning: {
          horizontal: 'right'
        }
         });
     });

  $(function () {
    $('.datetimepicker-1').datetimepicker({
        widgetPositioning: {
          horizontal: 'right'
        },
      debug: false
   });

 });
 
 $(function () {
    $('.datetimepicker-2').datetimepicker({
      format: 'DD/MM/YYYY',
       widgetPositioning: {
          horizontal: 'right'
        },
      debug: false
   });
 });

$(function () {
  $('.datetimepicker-3').datetimepicker({
    widgetPositioning: {
      horizontal: 'right'
    },
    format: 'LT',
    debug: false
  });
});


(function($, viewport){
    $(document).ready(function() {

        if(viewport.is('>=lg')) {
            $('.calendar-page-content, .calendar-page-side').matchHeight();
        }
        $(window).resize(
            viewport.changed(function() {
                if(viewport.is('<lg')) {
                    $('.calendar-page-content, .calendar-page-side').matchHeight({ remove: true });
                }
            })
        );
    });
});
//(jQuery, ResponsiveBootstrapToolkit);

       //funcao que edita o agendamento ao arrasta-lo
        function edit(event){
            start = event.start.format('YYYY-MM-DD HH:mm');
            if(event.end){
            end = event.end.format('YYYY-MM-DD HH:mm');
            }else{
            end = start;
            } 
            id = event.id;
            start = start;
            end = end;
            
            $.ajax({
             url: '../controllers/Agenda.php',
             type: "POST",
             data: 'id='+id+'&start='+start+'&end='+end+"&botao=editarDataHora",
             success: function(event){
              $('#calendar').fullCalendar('refetchEvents', event);  
              $('#calendar').fullCalendar('rerenderEvents');
                    swal({
                    title: "Processo Concluído!",
                    text: "Agenda atualizada com sucesso!",
                    type: "success",
                    timer: 1700,
                    showCancelButton: false, 
                    showConfirmButton: false 
                    });
                  }
              });
           }


//funcao que cadastra o agendamento na modal
          function agendar(){
            var id_usuario  = $("#id_usuario").val();
            var id_paciente = $("#title option:selected").val();
            var title = $("#title option:selected").text();
            var dentista=$('#dentista').val();
            var start = $("#start").val();
            var end  = $("#end").val();
            var observacao = $("#observacao").val();
            $.post('../models/PacienteBusca.php', { id: id_paciente },
              function(data) {
              data = $.parseJSON(data);
            var celular  = (data[0].telefone_celular);
            var email  = (data[0].email);
            if (agendamentos.title.value == ""){
            agendamentos.title.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Nome do Paciente!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false
            });
            return (false);
            }

            if (agendamentos.dentista.value == ""){
            agendamentos.dentista.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Nome do Dentista!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false
            });
            return (false);
            }

            if (agendamentos.start.value == ""){
            agendamentos.start.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Início da Consulta!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false
            });
            return (false);
            }
            
            if (agendamentos.end.value == ""){
            agendamentos.end.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Fim da Consulta!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false
            });
            return (false);
            }

            $.ajax({
             url: '../controllers/Agenda.php',
             type: "POST",
             data: 'id_usuario='+id_usuario+'&id_paciente='+id_paciente+'&title='+title+'&email='+email+'&celular='+celular+'&dentista='+dentista+'&start='+start+'&end='+end+'&observacao='+observacao+"&botao=agendar",
             success: function(event){
              $('#calendar').fullCalendar('refetchEvents', event);  
              $('#calendar').fullCalendar('rerenderEvents');
              $('#agendar').modal('hide');
              }
           });
               swal({
               title: "Processo Concluído!",
               text: "Agendamento realizado com sucesso!",
               type: "success",
               showCancelButton: false, 
               showConfirmButton: false 
               });
           setTimeout('location.reload();', 1700);
           }); 
         }
     
       function cadastrar_paciente_agenda(){
            var id_usuario  = $("#id_usuario2").val();
            var title=$('#title2').val();
            var dentista=$('#dentista2').val();
            var start=$('#start2').val();
            var end  =$('#end2').val();
            var observacao  =$('#observacaos').val();
            var dt_nascimento=$('#dt_nascimento').val();
            var rg=$('#rg').val();
            var cpf=$('#cpf').val();
            var telefone_celular=$('#celular').val();
            var email=$('#email').val();
            
            if (cadastroagenda.title2.value == ""){
            cadastroagenda.title2.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Nome do Paciente!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });
            return (false);
            }
            if (cadastroagenda.dentista2.value == ""){
            cadastroagenda.dentista2.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Nome do Dentista!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });
            return (false);
            }
            if (cadastroagenda.dt_nascimento.value == ""){
            cadastroagenda.dt_nascimento.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha a data de nascimento!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });
            return (false);
            }
            if (cadastroagenda.rg.value == ""){
            cadastroagenda.rg.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o RG do Paciente!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });
            return (false);
            }
            if (cadastroagenda.cpf.value == ""){
            cadastroagenda.cpf.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o CPF do Paciente!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });
            return (false);
            }
            if (cadastroagenda.celular.value == ""){
            cadastroagenda.celular.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Telefone Celular!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });
            return (false);
            }
            if (cadastroagenda.email.value == ""){
            cadastroagenda.email.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Email!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });
            return (false);
            }
            if (cadastroagenda.start2.value == ""){
            cadastroagenda.start2.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Início da Consulta!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });
            return (false);
            }
            
            if (cadastroagenda.end2.value == ""){
            cadastroagenda.end2.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Fim da Consulta!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });
            return (false);
            }

            $.ajax({
                    url:'../controllers/Agenda.php',
                    type:'POST',
                    data:'id_usuario='+id_usuario+'&nome='+title+'&dt_nascimento='+dt_nascimento+'&rg='+rg+'&cpf='+cpf+'&telefone_celular='+telefone_celular+'&email='+email+'&dentista='+dentista+'&start='+start+'&end='+end+'&observacao='+observacao+'&botao=cadastrarPaciente',
                      success: function(event){
                      $('#calendar').fullCalendar('refetchEvents', event);  
                      $('#calendar').fullCalendar('rerenderEvents');
                  }
                }).done(function(resposta){
                    if (resposta) {
                       $('#agendar').modal('hide'); 
                       $('#CadastroPacientesAgenda').modal('hide');

                       swal({
                         title: "Processo Concluído!",
                         text: "Agendamento realizado com sucesso!",
                         type: "success",
                         timer: 1700,
                         showCancelButton: false, 
                         showConfirmButton: false 
                         });
                      
                    }
                    
                });
            
            }

       function fechaModal(){
        $('#agendar').modal('hide'); 
      }

