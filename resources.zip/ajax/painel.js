//FUNCAO QUE BUSCA OS ALERTAS DA ANAMNESE 
    var id=$('#id_paciente').val();
     $.post('../models/AnamneseBusca.php', { id: id },
      function(data) {
       data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.  

           if(data[0].febre_reumatica == "Sim"){
               var febre_reumatica = '<tr><td>Tem Febre Reumática?</td><td>Sim</td></tr>';
               var a = 1;
           }
           else{
               var febre_reumatica = "";
               var a = 0;
           }

           if(data[0].hepatite == "Sim"){
               var hepatite = '<tr><td>Tem Hepatite?</td><td>Sim</td></tr>';
               var b = 1;
           }
           else{
               var hepatite = "";
               var b = 0;
           }

           if(data[0].diabetes == "Sim"){
               var diabetes = '<tr><td>Tem Diabetes?</td><td>Sim</td></tr>';
               var c = 1;
           }
           else{
               var diabetes = "";
               var c = 0;
           }

           if(data[0].anemia == "Sim"){
               var anemia = '<tr><td>Tem Anemia?</td><td>Sim</td></tr>';
               var d = 1;
           }
           else{
               var anemia = "";
               var d = 0;
           }

           if(data[0].portador_hiv == "Sim"){
               var portador_hiv = '<tr><td>É portador do vírus HIV?</td><td>Sim</td></tr>';
               var e = 1;
           }
           else{
               var portador_hiv = "";
               var e = 0;
           }

           if(data[0].asma == "Sim"){
               var asma = '<tr><td>Tem Asma?</td><td>Sim</td></tr>';
               var f = 1;
           }
           else{
               var asma = "";
               var f = 0;
           }

           if(data[0].problema_cardiaco == "Sim"){
               var problema_cardiaco = '<tr><td>Tem problemas cardíacos?</td><td>Sim</td></tr>';
               var g = 1;
           }
           else{
               var problema_cardiaco = "";
               var g = 0;
           }

           if(data[0].problema_renal == "Sim"){
               var problema_renal = '<tr><td>Tem problemas renais?</td><td>Sim</td></tr>';
               var h = 1;
           }
           else{
               var problema_renal = "";
               var h = 0;
           }

           if(data[0].problema_respiratorio == "Sim"){
               var problema_respiratorio = '<tr><td>Tem problemas respiratórios?</td><td>Sim</td></tr>';
               var i = 1;
           }
           else{
               var problema_respiratorio = "";
               var i = 0;
           }

           if(data[0].problema_cicatrizacao == "Sim"){
               var problema_cicatrizacao  = '<tr><td>Tem problemas com cicatrização?</td><td>Sim</td></tr>';
               var j = 1;
           }
           else{
               var problema_cicatrizacao = "";
               var j = 0;
           }

           if(data[0].problema_anestesia == "Sim"){
               var problema_anestesia = '<tr><td>Tem problemas com anestesia?</td><td>Sim</td></tr>';
               var k = 1;
           }
           else{
               var problema_anestesia = "";
               var k = 0;
           }

           if(data[0].teve_hemorragia == "Sim"){
               var teve_hemorragia = '<tr><td>Já teve hemorragias?</td><td>Sim</td></tr>';
               var l = 1;
           }
           else{
               var teve_hemorragia = "";
               var l = 0;
           }

           if(data[0].usando_medicacao == ""){
               var usando_medicacao = "";
               var m = 0;
           }
           else{
               var usando_medicacao = '<tr><td>Está usando alguma medicação?</td><td>'+ data[0].usando_medicacao +'</td></tr>';
               var m = 1;
           }

           if(data[0].medico_assistente == ""){
               var medico_assistente = "";
               var n = 0;
           }
           else{
               var medico_assistente = '<tr><td>Nome do médico assistente/telefone?</td><td>'+ data[0].medico_assistente +'</td></tr>';
               var n = 1;
           }

           if(data[0].tratamento_medico == ""){
               var tratamento_medico = "";
               var o = 0;
           }
           else{
               var tratamento_medico = '<tr><td>Está em Tratamento Médico?</td><td>'+ data[0].tratamento_medico +'</td></tr>';
               var o = 1;
           }

           if(data[0].foi_operado == ""){
               var foi_operado = "";
               var p = 0;
           }
           else{
               var foi_operado = '<tr><td>Já foi operado(a)?</td><td>'+ data[0].foi_operado +'</td></tr>';
               var p = 1;
           }

           if(data[0].gravidez == ""){
               var gravidez = "";
               var q = 0;
           }
           else{
               var gravidez = '<tr><td>Está Grávida?</td><td>'+ data[0].gravidez +'</td></tr>';
               var q = 1;
           }

           if(data[0].antecedentes_familiares == ""){
               var antecedentes_familiares = "";
               var r = 0;
           }
           else{
               var antecedentes_familiares = '<tr><td>Antecedentes familiares?</td><td>'+ data[0].antecedentes_familiares +'</td></tr>';
               var r = 1;
           }

           if(data[0].alergias == ""){
               var alergias = "";
               var s = 0;
           }
           else{
               var alergias = '<tr><td>Tem Alergia a algum Medicamento?</td><td>'+ data[0].alergias +'</td></tr>';
               var s = 1;
           }

           if(data[0].pressao_alta_baixa == ""){
               var pressao_alta_baixa = "";
               var t = 0;
           }
           else{
               var pressao_alta_baixa = '<tr><td>Tem Pressão Alta ou Baixa?</td><td>'+ data[0].pressao_alta_baixa +'</td></tr>';
               var t = 1;
           }

           if(data[0].problema_articulacao == ""){
               var problema_articulacao = "";
               var u = 0;
           }
           else{
               var problema_articulacao = '<tr><td>Problemas nas Articulações?</td><td>'+ data[0].problema_articulacao +'</td></tr>';
               var u = 1;
           }

           if(data[0].usa_marcapasso == ""){
               var usa_marcapasso = "";
               var v = 0;
           }
           else{

               var usa_marcapasso = '<tr><td>Usa Marcapasso?</td><td>'+ data[0].usa_marcapasso +'</td></tr>'; 
               var v = 1;          
           }

           if(data[0].tonturas_desmaios == ""){
               var tonturas_desmaios = "";
               var x = 0;
           }
           else{
               var tonturas_desmaios = '<tr><td>Sofre de Tonturas ou Desmaios?</td><td>'+ data[0].tonturas_desmaios +'</td></tr>';
               var x = 1;
           }

           if(data[0].problemas_gastricos == ""){
               var problemas_gastricos = "";
               var z = 0;
           }
           else{
               var problemas_gastricos = '<tr><td>Problemas Gástricos?</td><td>'+ data[0].problemas_gastricos +'</td></tr>';
               var z = 1;
           }

           if(data[0].queixa_principal == ""){
               var queixa_principal = "";
               var y = 0;
           }
           else{
               var queixa_principal = '<tr><td>Qual é sua Queixa Principal?</td><td>'+ data[0].queixa_principal +'</td></tr>';
               var y = 1;
           }

           if(data[0].dor_mastigar == ""){
               var dor_mastigar = "";
               var ab = 0;
           }
           else{
               var dor_mastigar = '<tr><td>Sente dor ao mastigar alimentos?</td><td>'+ data[0].dor_mastigar +'</td></tr>';
               var ab = 1;
           }

           if(data[0].mastiga_doisLados == ""){
               var mastiga_doisLados = "";
               var bc = 0;
           }
           else{
               var mastiga_doisLados = '<tr><td>Mastiga dos dois lados da boca?</td><td>'+ data[0].mastiga_doisLados +'</td></tr>';
               var bc = 1;
           }

           if(data[0].usa_alcoolDrogas == ""){
               var usa_alcoolDrogas = "";
               var cd = 0;
           }
           else{
               var usa_alcoolDrogas = '<tr><td>Faz uso de Álcool ou Drogas?</td><td>'+ data[0].usa_alcoolDrogas +'</td></tr>';
               var cd = 1;
           }

           if(data[0].e_fumante == ""){
               var e_fumante = "";
               var de = 0;
           }
           else{
               var e_fumante = '<tr><td>É Fumante?</td><td>'+ data[0].e_fumante +'</td></tr>';
               var de = 1;
           }

           if(data[0].extracoes == ""){
               var extracoes = "";
               var ef = 0;
           }
           else{
               var extracoes = '<tr><td>Realizou Extrações?</td><td>'+ data[0].extracoes +'</td></tr>';
               var ef = 1;
           }

           if(data[0].usa_protese == ""){
               var usa_protese = "";
               var fg = 0;
           }
           else{
               var usa_protese ='<tr><td>Usa Prótese?</td><td>'+ data[0].usa_protese +'</td></tr>';
               var fg = 1;
           }

           if(data[0].higiene_bucal == ""){
               var higiene_bucal = "";
               var gh = 0;
           }
           else{
               var higiene_bucal ='<tr><td>Como é a sua Higiene Bucal?</td><td>'+ data[0].higiene_bucal +'</td></tr>';
               var gh = 1;
           }

           if(data[0].ranger_dentes == ""){
               var ranger_dentes = "";
               var hi = 0;
           }
           else{
               var ranger_dentes ='<tr><td>Range os Dentes?</td><td>'+ data[0].ranger_dentes +'</td></tr>';
               var hi = 1;
           }

           if(data[0].alteracao_bucal == ""){
               var alteracao_bucal = "";
               var ij = 0;
           }
           else{
               var alteracao_bucal = '<tr><td>Alteraçãoes Bucais ou Faciais?</td><td>'+ data[0].alteracao_bucal +'</td></tr>';
               var ij = 1;
           }

           if(data[0].come_doces == ""){
               var come_doces = "";
               var jl = 0;
           }
           else{
               var come_doces ='<tr><td>Come Doces, Chicletes ou Balas?</td><td>'+ data[0].come_doces +'</td></tr>';
               var jl = 1;
           }

           if(data[0].toma_cafe == ""){
               var toma_cafe = "";
               var lm = 0;
           }
           else{
               var toma_cafe ='<tr><td>Toma Café, ou Líquidos escuros?</td><td>'+ data[0].toma_cafe +'</td></tr>';
               var lm = 1;
           }

           if(data[0].gengiva_dolorida == ""){
               var gengiva_dolorida = ""; 
               var mn = 0;   
           }
           else{
               var gengiva_dolorida = '<tr><td>Gengivas doloridas ou sangrando?</td><td>'+ data[0].gengiva_dolorida +'</td></tr>';
               var mn = 1; 
           }

           if(data[0].ultimo_tratamento == ""){
               var ultimo_tratamento = "";
               var no = 0;
           }
           else{
               var ultimo_tratamento = '<tr><td>Último Tratamento Odontológico?</td><td>'+ data[0].ultimo_tratamento +'</td></tr>';
               var no = 1;
           }

           if(data[0].observacoes == ""){
               var observacoes ="";
               var pq = 0;
           }
           else{
               var observacoes ='<tr><td>Observações</td><td>'+ data[0].observacoes +'</td></tr>';
               var pq = 1;
           }

           var soma_info = a+b+c+d+e+f+g+h+i+j+k+l+m+n+o+p+q+r+s+t+u+v+x+z+y+ab+bc+cd+de+ef+fg+gh+hi+ij+jl+lm+mn+no+pq;
           $('.info_alertas').append(soma_info);
           $('#tabela_alertas').append(febre_reumatica+hepatite+diabetes+anemia+portador_hiv+asma+problema_cardiaco+problema_renal+problema_respiratorio+problema_cicatrizacao+problema_anestesia+teve_hemorragia+usando_medicacao+medico_assistente+tratamento_medico+foi_operado+gravidez+antecedentes_familiares+alergias+pressao_alta_baixa+problema_articulacao+usa_marcapasso+tonturas_desmaios+problemas_gastricos+queixa_principal+dor_mastigar+mastiga_doisLados+usa_alcoolDrogas+e_fumante+extracoes+usa_protese+higiene_bucal+ranger_dentes+alteracao_bucal+come_doces+toma_cafe+gengiva_dolorida+ultimo_tratamento+observacoes);                    

          if(soma_info == "0"){
           $('#tb_anamnese').hide();
           $('#tb_vazia_').show();
          }
          else{
           $('#tb_anamnese').show();
           $('#tb_vazia_').hide(); 
         }
        });


 //FUNCAO QUE BUSCA TODOS OS AGENDAMENTOS DO PACIENTE 
  function agendamentos(){
    var id=$('#id_paciente').val();
      $('#tabela_agendamentos').html("");
       $('.contar_agendamentos').html("");
       $.post('../models/AgendaBuscaAlertas.php', {id:id},
       function(data) {
         data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.
         $('.contar_agendamentos').append(data.length); 
         for(var i=0; data.length > i; i++){
           if(data[i].color == "#0071c5"){
               status = '<span class="label label-primary" style="text-align:center; width:88%;">Agendada</span>';
           }
           else if(data[i].color == "#3CB371"){
               status = '<span class="label label-success" style="text-align:center; width:88%;">Confirmada</span>';
           }
           else if(data[i].color == "#FF6347"){
               status = '<span class="label label-danger" style="text-align:center; width:88%;">Cancelada</span>';
           }
           else if(data[i].color == "#DAA520"){
               status = '<span class="label label-warning" style="text-align:center; width:88%;">Faltou</span>';
           }
           $('#tabela_agendamentos').append("<tr><td>"+data[i].title+"</td><td>"+data[i].dentista+"</td><td>"+moment(data[i].start).format('DD/MM/YYYY HH:mm')+"</td><td>"+moment(data[i].end).format('DD/MM/YYYY HH:mm')+"</td><td  style='position: relative; left:-2%;'>"+status+"</td><td><a onclick='editar_agenda("+data[i].id+")' style='position: relative; left:-30%; top:2px;' class = 'tool' data-tip='Editar' tabindex='2'><i class='fa fa-edit  color-blue' style='font-size:16px'></i></a><a onclick='deletar_agenda("+data[i].id+")'  style='position: relative; left:20%;' class = 'tool' data-tip='Excluir' tabindex='2'><i class='font-icon font-icon-trash color-red'></i></a></td></tr>");
        
           }
          if(data.length == 0){
           $('#tb_agenda').hide();
           $('#tb_vazia').show();
          }
          else{
           $('#tb_agenda').show();
           $('#tb_vazia').hide(); 
         }
     });
   }

 //FUNCAO QUE TRAS OS DADOS PARA EDICAO
 function editar_agenda(id){
       var id=id;
         $('#id').html("");
         $('#dentista2').html("");
         $('.dentista2').html("");
         $('#start2').html("");
         $('#end2').html("");
         $('#color2').html("");
         $('#observacao2').html("");
         $('.contar_agendamentos').html("");
         $('#alerta_agendamentos').hide();
         $('#editar').show();
         $("#sair").click(function (){
         $('#editar').hide();
         $('#alerta_agendamentos').show();
       });

       $.post('../models/AgendaBuscaAlertas2.php', { id: id },
       function(data) {
         data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.  
         $('#id').val(data[0].id);
         $('#dentista2').append('<option value='+ data[0].dentista+'>&emsp;'+ data[0].dentista+'</option>');
         $('#start2').val(moment(data[0].start).format('DD/MM/YYYY HH:mm'));
         $('#end2').val(moment(data[0].end).format('DD/MM/YYYY HH:mm'));
         
         if(data[0].color == "#0071c5"){
            $('#agendada').prop('checked',true);
         }
         else if(data[0].color == "#3CB371"){
            $('#confirmada').prop('checked',true);
         }
         else if(data[0].color == "#FF6347"){
            $('#cancelada').prop('checked',true);
         }
         else if(data[0].color == "#DAA520"){
            $('#faltou').prop('checked',true);
         }

         $('#observacao2').val(data[0].observacao);
       });
       $.post('../models/DentistaBusca.php',
       function(data) {
         data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.  
         for(var i=0; data.length > i; i++){
         $('.dentista2').append('<option value='+ data[i].nome+'>&emsp;'+ data[i].nome+'</option>');
         }
      });
    }

 //FUNCAO QUE EDITA O AGENDAMENTO
 function add_editar_agenda(id){
    $('.contar_agendamentos').html("");
    var id=$('#id').val();
    var dentista = $(".dentista2 option:selected").text();
    var start = $('#start2').val();
    var end = $('#end2').val();

    if ($("#agendada").is(':checked') ){
      var color="#0071c5";
    }
    if ($("#confirmada").is(':checked') ){
      var color="#3CB371";
    }
    if ($("#cancelada").is(':checked') ){
      var color="#FF6347";
    }
    if ($("#faltou").is(':checked') ){
      var color="#DAA520";
    }

    var observacao=$('#observacao2').val();

     $.ajax({
       url:'../controllers/Agenda.php',
       type:'POST',
       data:'id='+id+'&dentista='+dentista+'&start='+start+'&end='+end+'&color='+color+'&observacao='+observacao+'&botao=editar_agenda'
     }).done(function(resposta){
        $('#editar').hide();
           if (resposta) { 
           swal({
            title: "Processo Concluído!",
            text: "Agendamento atualizado com sucesso!",
            type: "success",
            timer: 1700,
            showCancelButton: false, 
            showConfirmButton: false 
           });
           agendamentos();
           window.setTimeout(function () {
           $('#alerta_agendamentos').show(); 
           }, 1800);
        }
    });
 } 

 // FUNCAO QUE EXCLUI O AGENDAMENTO
 function deletar_agenda(id){
    var id=id;
     $('#alerta_agendamentos').hide();
     $('.contar_agendamentos').html("");
       swal({
         title: 'Você tem certeza?',
         text: "O Agendamento será excluído permanentemente!",
         type: 'warning',
         showCancelButton: true,
         confirmButtonColor: '#3085d6',
         cancelButtonColor: '#d33',
         confirmButtonText: 'Sim',
         cancelButtonText: "Cancelar",   
         closeOnConfirm: false,   
         closeOnCancel: false
         },
         
         function(isConfirm){   
         if (isConfirm){     
             swal({
             title: "Processo Concluído!",
             text: "Agendamento excluído com sucesso!",
             type: "success",
             timer: 1700,
             showCancelButton: false, 
             showConfirmButton: false 
             });
             $.ajax({
             url: '../controllers/Agenda.php',
             type: "POST",
             data: 'id='+id+"&botao=excluir",
             success: function(e){ 
               agendamentos();
               window.setTimeout(function () {
               $('#alerta_agendamentos').show(); 
               }, 1800);
             }
          });
        }
        else{     
            swal({
            title: "Processo Cancelado!",
            text: "Agendamento não excluído!",
            type: "error",
            timer: 1700,
            showCancelButton: false, 
            showConfirmButton: false 
            });
            window.setTimeout(function () {
            $('#alerta_agendamentos').show(); 
            }, 1800);  
           }
         });
       }



     //FUNCAO QUE AGENDA UMA NOVA CONSULTA PARA O PACIENTE 
     function agendar_consulta(){
           var id_usuario  = $("#id_usuario").val();
           var id_paciente = $("#id_paciente").val();
           var title = $("#nome").val();
           var dentista=$(".dentista option:selected").text();
           var start = $("#start").val();
           var end  = $("#end").val();
           var observacao = $("#observacao").val();

            $.ajax({
             url: '../controllers/Agenda.php',
             type: "POST",
             data: 'id_usuario='+id_usuario+'&id_paciente='+id_paciente+'&title='+title+'&dentista='+dentista+'&start='+start+'&end='+end+'&observacao='+observacao+"&botao=agendar",
             success: function(data){
              $('#agendar').modal('hide');

             swal({
               title: "Processo Concluído!",
               text: "Agendamento realizado com sucesso!",
               type: "success",
               timer: 1700,
               showCancelButton: false, 
               showConfirmButton: false 
             });

             agendamentos();
             window.setTimeout(function () {
              $('#alerta_agendamentos').modal('show'); 
             }, 1800); 

              }
           });
         }


   //FUNCAO QUE CONTA QUANTOS ATESTADOS EXISTEM
    function contar_atestados(id_paciente) {
      var id_paciente = $('#id_paciente').val();
      $('.contar_atestados').html("");
      $.post('../models/AtestadoBusca.php', { id_paciente: id_paciente },
       function(data) {
         data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.  
         $('.contar_atestados').append(data.length);
      });
    } 


   //FUNCAO QUE CONTA O TOTAL ORCAMENTOS EXISTEM
    function contar_orcamentos(id_paciente) {
      var id_paciente = $('#id_paciente').val();
      $('.contar_orcamentos').html("");
      $.post('../models/OrcamentoBusca.php', { id_paciente: id_paciente },
       function(data) {
         data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.  
         $('.contar_orcamentos').append(data.length);
      });
    } 

   //FUNCAO QUE CONTA O TOTAL ORCAMENTOS APROVADOS
    function orcamentos_aprovados(id_paciente) {
      var id_paciente = $('#id_paciente').val();
      var total_aprovados = 0;
      $('.contar_aprovados').html("");
      $.post('../models/OrcamentoAprovado.php', { id_paciente: id_paciente },
       function(data) {
         data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.  
         $('.contar_aprovados').append(data.length);
         for(var i=0; data.length > i; i++){
             total_aprovados += parseFloat(data[i].valor_final);
             $('#total_aprovados').html('<div>Aprovados<br><h4>' +parseFloat(total_aprovados).toLocaleString('pt-br',{style: 'currency', currency: 'BRL'})+'</h4></div>');
         }
      });
    } 

    //FUNCAO QUE CONTA O TOTAL ORCAMENTOS PENDENTES
    function orcamentos_pendentes(id_paciente) {
      var id_paciente = $('#id_paciente').val();
      var total_pendentes = 0;
      $('.contar_pendentes').html("");
      $.post('../models/OrcamentoPendente.php', { id_paciente: id_paciente },
       function(data) {
         data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.  
         $('.contar_pendentes').append(data.length);
         for(var i=0; data.length > i; i++){
             total_pendentes += parseFloat(data[i].valor_final);
             $('#total_pendentes').html('<div>Pendentes<br><h4>' +parseFloat(total_pendentes).toLocaleString('pt-br',{style: 'currency', currency: 'BRL'})+'</h4></div>');
         }
      });
    } 

    //FUNCAO QUE CONTA O TOTAL ORCAMENTOS LIQUIDADOS
    function orcamentos_liquidados(id_paciente) {
      var id_paciente = $('#id_paciente').val();
      var total = 0;
      $('.contar_liquidados').html("");
      $.post('../models/OrcamentoLiquidado.php', { id_paciente: id_paciente },
       function(data) {
         data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.  
         $('.contar_liquidados').append(data.length);
         for(var i=0; data.length > i; i++){
             total += parseFloat(data[i].valor_final);
             $('#total').html('<div>Liquidados<br><h4>' +parseFloat(total).toLocaleString('pt-br',{style: 'currency', currency: 'BRL'})+'</h4></div>');
         }
      });
    } 

  //FUNCAO QUE CONTA O TOTAL DE IMAGENS
   function imagens(id_paciente) {
     var id_paciente = $('#id_paciente').val();
      $.post('../models/ImagemBusca.php', { id_paciente: id_paciente },
        function(data) {
        data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.
        $('.contar_imagem').append(data.length);
      });
   }


   //FUNCAO QUE CONTA O TOTAL DE RECEITAS EMITIDAS
   function receitas(id_paciente) {
     var id_paciente = $('#id_paciente').val();
      $.post('../models/ReceituarioBusca.php', { id_paciente: id_paciente },
        function(data) {
        data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.
        $('.contar_receita').append(data.length);
      });
   }

   
imagens();
receitas();   
agendamentos();
contar_atestados();
contar_orcamentos();
orcamentos_aprovados();
orcamentos_pendentes();
orcamentos_liquidados();
