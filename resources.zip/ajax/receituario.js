if($("#tbReceita tr").length == 1){
  $("#tbReceita").css("display", "none");
  $("#smile").show();
  }
  else{
  var tb = ($("#tbReceita  tr").length)-1;
  $("#smile").hide();
 }

function carregaTextDrogas( opcao ){
  document.all.meuTexto.value = opcao;
}

function carregaTextPrescricao( opcao ){
  document.all.meuTexto.value = opcao;
}

//FUNCAO QUE CADASTRA A RECEITA
        function cadastrar_receita(){
           var id_usuario=$('#id_usuario').val();
           var id_paciente=$('#id_paciente').val();
           var tipo_receita = $('input:radio[name=tipo_receita]:checked').val(); 
           var prescricao=$('#prescricao').val();
           if (prescricao == ""){
              swal({
                  title: "Processo Cancelado!",
                  text: "Prescreva a Medicação",
                  type: "error",
                  timer: 1400,
                  showCancelButton: false, 
                  showConfirmButton: false 
              }); 

           }
           else{
           $.ajax({
                url:'../controllers/Receituario.php',
                type:'POST',
                data:'id_usuario='+id_usuario+'&id_paciente='+id_paciente+'&tipo_receita='+tipo_receita+'&prescricao='+prescricao+'&botao=cadastrarReceita'
                }).done(function(resposta){
           if (resposta) {
            $('#Receita').hide();
            swal({
                title: 'Deseja Imprimir a Receita?',
                text: "Caso cancele, poderá imprimir depois!",
                type: 'info',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sim',
                cancelButtonText: "Cancelar",   
                closeOnConfirm: false,   
                closeOnCancel: false
                },
            function(isConfirm){   
                if (isConfirm){     
                    swal({
                    title: "Processo Concluído!",
                    text: "Receita Impressa com sucesso!",
                    type: "success",
                    showCancelButton: false, 
                    showConfirmButton: false 
                    });
                    window.open('imprimir/receita','_blank');
                    setTimeout('location.reload();', 1700);
                }
                else{     
                    swal({
                    title: "Processo Cancelado!",
                    text: "Receita não Impressa!",
                    type: "error",
                    timer: 1700,
                    showCancelButton: false, 
                    showConfirmButton: false 
                    });   
                    setTimeout('location.reload();', 1700);
                    }
                });
             }
        });
     }   
 }


 function imprimirReceita(id_receita){
    var id=id_receita
    var randomico=$('#randomico').val();
    var codigo = randomico+btoa(id);
    setTimeout('location.reload();', 1000);
    window.open('imprimir/receitas?@='+codigo, '_blank');
}

   function deletarReceita(id_receita){
                var id=id_receita;
                    swal({
                        title: 'Você tem certeza?',
                        text: "A Receita será excluída permanentemente!",
                        type: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Sim',
                        cancelButtonText: "Cancelar",   
                        closeOnConfirm: false,   
                        closeOnCancel: false
                        },

                    function(isConfirm){   
                        if (isConfirm){     
                            swal({
                            title: "Processo Concluído!",
                            text: "Receita excluída com sucesso!",
                            type: "success",
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });
                        $.ajax({
                            url: '../controllers/Receituario.php',
                            type: "POST",
                            data: 'id='+id+"&botao=excluirReceita"
                        });
                         setTimeout('location.reload();', 1700);
                        }
                        else{     
                            swal({
                            title: "Processo Cancelado!",
                            text: "Receita não excluída!",
                            type: "error",
                            timer: 1700,
                            showCancelButton: false, 
                            showConfirmButton: false 
                            }); 

                           }
                          });
                        }

$( function() {
var availableTags = [
 "Amoxicilina 500mg - 21 cápsulas: Tomar 1 cápsula a cada 8 horas, por 7 dias.", 
 "Amoxicilina 875mg - 14 comprimidos:Tomar 1 comprimido a cada 12 horas, por 7 dias.", 
 "Amoxicilina 875mg + Clavulanato de potássio 125mg - 14 comprimidos: Tomar 1 comprimido a cada 12 horas por 7 dias." ,
 "Clindamicina 150mg - 42 cápsulas: Tomar 2 cápsulas a cada 8 horas, por 7 dias." ,
 "Clindamicina 300mg - 21 cápsulas: Tomar 1 cápsula a cada 8 horas, por 7 dias." ,
 "Cefalexina 500mg - 28 cápsulas: Tomar 1 cápsula a cada 6 horas, por 7 dias." ,
 "Azitromicina 500mg - 03 cápsulas: Tomar 1 cápsula ao dia, por 3 dias. Tomar 1 hora antes ou 2 horas após refeições.", 
 "Azitromicina 1000mg - 01 cápsula: Tomar 1 cápsula como dose única. Tomar 1 hora antes ou 2 horas após as refeições." ,
 "Metronidazol 400mg - 30 comprimidos: Tomar 1 comprimido a cada 8 horas, por 10 dias.", 
 "Metronidazol 400mg - 20 comprimidos: Tomar 1 comprimido a cada 12 horas, por 10 dias." ,
 "Ampicilina 500mg - 28 ampolas: Aplicar 1 ampola via intra-muscular profunda a cada 6 horas, por 7 dias.", 
 "Amoxicilina 500mg + Clavulanato de Potássio 100mg - 21 ampolas: Aplicar ampola via intra-muscular profunda a cada 8 horas, por 7 dias.",
 "Cefazolina 500mg - 28 ampolas: Aplicar 1 ampola via intra-muscular profunda a cada 6 horas, por 7 dias.",  
 "Cefazolina 1000mg - 21 ampolas: Aplicar 1 ampola via intra-muscular profunda a cada 8 horas, por 7 dias.", 
 "Cefalotina 500mg - 28 ampolas: Aplicar 1 ampola via intra-muscular profunda a cada 6 horas, por 7 dias." ,
 "Cefalotina 100mg - 28 ampolas: Aplicar 1 ampola via intra0muscular profunda a cada 12 horas, por 7 dias.", 
 "Clindamicina 300mg - 21 ampolas: Aplicar 1 ampola via intra-muscular profunda a cada 8 horas, por 7 dias.", 
 "Despacilina 400.000 UI - 1 ampola: Aplicar 1 ampola via intra-muscular profunda, em dose única." , 
 "Benzetacil 1.200.000 UI - 1 ampola: Aplicar ampola via intra-muscular profunda, em dose única." ,
 "Amoxicilina 500mg - 4 cápsulas: Tomar 4 cápsulas, 1 hora antes do procedimento." ,
 "Cefalexina 500mg - 4 cápsulas: Tomar 4 cápsulas, 1 hora antes do procedimento.",
 "Clindamicina 300mg - 2 cápsulas: Tomar 2 cápsulas, 1 hora antes do procedimento.",
 "Azitromicina 500mg - 1 cápsula: Tomar 1 cápsula, 1 hora antes do procedimento.",
 "Ampicilina 1000mg - 2 ampolas: Aplicar 2 ampolas - 2000mg - por via intramuscular profunda, 30 minutos antes do procedimento.",
 "Cefazolina 1000mg - 1 ampola: Aplicar 1 ampola - 1000mg - por dia intramuscular profunda, 30 minutos antes do procedimento.",
 "Clindamicina 300mg - 2 ampolas: Aplicar 2 ampolas - 600mg - via intramuscular profunda, 30 minutos antes do procedimento.",
 "Diclofenaco Potássico 50mg - 9 drágeas: Tomar 1 drágea a cada 8 horas, por 3 dias.",
 "Dexametasona 0,5mg - 1 comprimido: Tomar 1 comprimido, 1 hora antes do procedimento.", 
 "Dexametasona 2,0mg - 1 comprimido: Tomar 1 comprimido, 1 hora antes do procedimento.",
 "Dexametasona 4,0mg - 1 comprimido: Tomar 1 comprimido, 1 hora antes do procedimento." ,
 "Betametasona 0,5 mg - 1 comprimido: Tomar 1 comprimido, 1 hora antes do procedimento.",  
 "Betametasona 2,0mg - 1 comprimido: Tomar 1 comprimido, 1 hora antes do procedimento." , 
 "Paracetamol 500mg : Tomar 1 comprimido a cada 6 horas.", 
 "Paracetamol 750mg : Tomar 1 comprimido a cada 8horas." ,
 "Ibuprofeno 300mg : Tomar 1 comprimido a cada 6 horas." ,
 "Ibuprofeno 600mg : Tomar 1 comprimido a cada 8 horas." ,
 "Ibuprofeno 400mg(Envelope): Dissolver 1 envelope em meio copo de água e tomar a cada 6 horas." ,
 "Ibuprofeno 600mg(Envelope): Dissolver 1 envelope em meio copo de água e tomar a cada 8 horas." ,
 "Tylex 30mg : Tomar 1 comprimido a cada 6 horas.", 
 "Tramadol 50mg: Tomar 1 comprimido a cada 6 horas." ,
 "Tramadol 100mg: Tomar 1 comprimido a cada 12 horas." ,
 "Tramadol Gotas 100mg/ml: Tomar 20 gotas a cada 12 horas." ,
 "Tramadol 50mg(Ampolas): Injetar 1 ampola via IM profunda a cada 6 horas." ,
 "Tramadol 100mg(Ampolas): Injetar 1 ampola via IM profunda a cada 12 horas." ,
 "Cetorolaco de Trometamina 10mg - 12 comprimidos sublinguais: Colocar 1 comprimido embaixo da língua e deixar dissolver a cada 8 horas durante 3 dias.", 
 "Diclofenaco Potássico 100mg - 3 comprimidos: Tomar 1 comprimido ao dia, por 3 dias.", 
 "Diclofenaco Sódico 75mg - 6 comprimidos: Tomar 1 drágea a cada 12 horas, por 3 dias." ,
 "Diclofenaco 70mg + Colesteramina 70mg - 6 cápsulas: Tomar 1 cápsula a cada 12 horas, durante 3 dias." ,
 "Nimesulida 100mg - 6 comprimidos: Tomar 1 comprimido a cada 12 horas, por 3 dias.", 
 "Cetoprofeno 50mg - 12 comprimidos: Tomar 1 comprimido a cada 6 horas, durante 3 dias.", 
 "Cetoprofeno 100mg - 6 comprimidos: Tomar 1 comprimido a cada 12 horas, durante 3 dias." ,
 "Cetoprofeno 200mg - 3 comprimidos: Tomar 1 comprimido ao dia, durante 3 dias." ,
 "Piroxicam 10mg - 6 cápsulas: Tomar 1 cápsula a cada 12 horas, durante 3 dias." ,
 "Piroxicam 20mg - 3 cápsulas: Tomar 1 cápsula ao dia, durante 3 dias." ,
 "Tenoxican 20mg - 3 comprimidos: Tomar 1 comprimido ao dia, durante 3 dias." ,
 "Celecoxib 100mg - 6 cápsulas: Tomar 1 cápsula a cada 12 horas, durante 3 dias.",
 "Celecoxib 200mg - 3 cápsulas: Tomar 1 cápsula ao dia, durante 3 dias." ,
 "Cetoprofeno 100mg - 6 ampolas: Aplicar 1 ampola, via intramuscular profunda, a cada 12 horas, por 3 dias." ,
  "Piroxican 20mg - 1 ampola: Aplicar 1 ampola ao dia, via intramuscular profunda, por 3 dias." ,
 "Tenoxican 20mg - 3 ampolas: Aplicar 1 ampola ao dia, via intramuscular profunda, por 3 dias." ,
 "Piroxicam 20mg - 3 comprimidos sublinguais: Colocar um comprimido embaixo da língua e deixar dissolver, uma vez ao dia, por 3 dias.", 
 "Fluconazol 150mg - 4 cápsulas: Tomar 1 cápsula por semana por 4 semanas." ,
 "Nistatina Suspensão Oral 100.000 UI - 1 frasco: Fazer bochechos com 15ml (1 colher de sopa), a cada 6 horas, por 15 dias." ,
 "Nitrato de Micanazol Creme - 1 tubo: Aplicar 2 vezes ao dia, na área indicada, por 15 dias." ,
 "Cetoconazol Creme - 1 tubo: Aplicar 2 vezes ao dia, na área indicada, por 15 dias." ,
 "Aciclovir Creme - 1 tubo: Aplicar 6 vezes ao dia, na área indicada, por 3 dias." ,
 "Metoclopramida 10mg - 9 comprimidos: Tomar 1 comprimido a cada 8 horas, por 3 dias, se houver náuse ou vômito." ,
 "Ondansetron 4mg - 9 comprimidos: Tomar 1 comprimido a cada 8 horas, por 3 dias, se houver náusea ou vômito." ,
 "Diazepam ( Valium®) 5mg: Tomar 5 a 10mg, uma hora antes do início do procedimento." ,
 "Diazepam ( Valium®) 5mg: Tomar 5  uma hora antes do início do procedimento.", 
 "Diazepam ( Valium®) 5mg: Tomar 0,2 a 0,5mg/Kg, uma hora antes do início do procedimento." ,
 "Lorezepam( Lorax®) 1mg: Tomar 1 a 2 mg, uma hora antes do início do procedimento." ,
 "Alprazolam( Frontal®) 0,25mg: Tomar 0,25 a 0,75mg, uma hora antes do início do procedimento." ,
 "Midazolam ( Dormonid®) 7,5 mg: Tomar 7,5 a 15 mg, uma hora antes do início do procedimento." ,
 "Midazolam ( Dormonid®) 7,5 mg:  Tomar 0,3 a 0,5mg/Kg, uma hora antes do início do procedimento." ,
 "Triazolam(Halcion®) 0,125 mg: Tomar 0,125 a 0,25mg, uma hora antes do início do procedimento.", 
 "Triazolam(Halcion®) 0,125 mg: Tomar 0,06 a 0,125mg, uma hora antes do início do procedimento." ,
 "Sensodyne Original® ( Cloreto de Estrôncio)(Tubo 90gr): Escovar 2 vezes ao dia." ,
 "Parodontax® ( Bicarbonato de Sódio e Extratos Vegetais) (Tubos 50mg): Escovar 2 vezes ao dia.", 
 "Periogard ® sem Álcool ( Digluconato de clorexidina a 0,12%)(1 frasco 250ml): Bochechar 15 ml ( 1 tampa cheia) por 30 segundos, deus vezes ao dia, pela manhã e à noite após higiene bucal." ,
 "Listerine ®( óleos essenciais fenólicos em veículo hidroalcoólico) ( 1 frasco 250ml): Bochechar 20ml por 30 segundos, duas vezes ao dia, pela manhã e à noite após higiene bucal.",
 "Colgate Plax ®( Triclosan) (1 frasco 250ml): Bochechar 20 ml por 30 segundos, duas vezes ao dia, pela manhã e à noite após higiene bucal." ,
 "Cepacol ®(cloreto de cetilpiridínio) ( 1 frasco 250ml): Bochechar 10 a 20 ml por 30 segundos, duas vezes ao dia, pela manhã e à noite após higiene bucal." , 
 "Malvatricin ®( Tirotricina 0,3mg/ml - Quinosol 10 mg/ml) ( 1 frasco de 100ml): Diluir 10 mL ( um copinho-medida) em meio copo de água. Bochechar e/ou gargarejar, 3 a 4 vezes ao dia. Nos quadros agudos, usar de duas em duas horas.", 
 "Solução de Fluoreto de Sódio 0,05% - 1 frasco: Bochechar 10 ml de solução, 1 vez por dia após a última escovação." ,
 "Solução de Fluoreto de Sódio 0,2% - 1 frasco: Bochechar 10 ml de solução, 1 vez por semana após a última escovação." ,
 "Dorilax - Composição de carisoprodol 150mg + cafeína 50mg + paracetamol 350mg: Tomar 1 comprimido a cada 6 horas." ,
 "Mioflex - Composição carisoprodol 150mg + fenibutazona 75 mg + paracetamol 300mg: Tomar 1 comprimido a cada 8 horas." ,
 "Trandrilax - Composto de carisoprodol 125mg + cafeína 30mg + paracetamol 300mg + diclofenaco sódico 50mg. Tomar 1 comprimido ao dia.", 
 "Dorflex - Composição orfenadrina 25 mg + dipirona sódica 300mg + cafeína 50mg: Tomar 1 comprimido a 6 horas.", 
 "Saliva Artificial - 100ml : Aplicar 5 gotas na cavidade bucal, 6 vezes ao dia." ,
 "Cicatrizan Creme - 1 tubo: Aplicar 2 vezes ao dia, na área indicada." ,
 "Oleato de Monoetanolamina 0,05g/ml - 3 ampolas: Aplicar na área indicada, com acompanhamento profissional."];
  $( "#prescricao" ).autocomplete({
      source: availableTags
    });
  });


