if($("#tbs tr").length == 1){
  $("#tbs").css("display", "none");
  $("#smile").show();
}
else{
  var tb = ($("#tbs  tr").length)-1;
  $("#smile").hide();
}

   //FUNCAO QUE MOSTRA INPUT E SELECT DE ACORDO COM A OPTION SELECIONADA
   $('.tp2').hide();
   $('.tp1').hide();
   $('.pacientes').hide();
   $('.funcionarios').hide();
   $('.fornecedores').hide();
   $('#despesas_de').on('change', function() {
   if($('#despesas_de').val() == 'Paciente'){
      $('.seleciona1').show();
      $('.seleciona2').remove();
      $('.seleciona3').remove();
      $('.pacientes').show();
      $('.funcionarios').hide();
      $('.fornecedores').hide();
      $('.tp2').hide();
      $('.tp1').show();
      $('#tipo_fatura').append('<option class="seleciona1">Selecione o Tipo de Fatura</option>'+'<option class="seleciona1" value="Devolução de Valor">Devolução de Valor</option>'+'<option class="seleciona1" value="Crédito">Crédito</option>');
    }
    else if($('#despesas_de').val() == 'Fornecedor'){
      $('.seleciona1').remove();
      $('.seleciona2').show();
      $('.seleciona3').remove();
      $('.pacientes').hide();
      $('.funcionarios').hide();
      $('.fornecedores').show();
      $('.tp2').show();
      $('.tp1').hide();
      $('#tipo_fatura').append('<option value=""></option>');
    }
    else if($('#despesas_de').val() == 'Funcionário'){
      $('.seleciona1').remove();
      $('.seleciona2').remove();
      $('.seleciona3').show();
      $('.pacientes').hide();
      $('.funcionarios').show();
      $('.fornecedores').hide();
      $('.tp1').show();
      $('.tp2').hide();
      $('#tipo_fatura').append('<option class="seleciona3">Selecione o Tipo de Fatura</option>'+'<option class="seleciona3" value="Salário Funcionário">Salário Funcionário</option>'+'<option class="seleciona3" value="Benefício Funcionário">Benefício Funcionário</option>');
    }
  });

  $('#fornecedor').on('change', function() {
       var tipo_fatura2 = $(this).val();
       $('#tipo_fatura2').val(tipo_fatura2);
   });

         function cadastrar_despesa(){
            var id_usuario=$('#id_usuario').val();
            var despesas_de=$('#despesas_de').val();
            var paciente=$('#paciente').val();
            var funcionario=$('#funcionario').val();
            var fornecedores=$("#fornecedor option:selected").text();
            if (fornecedores == "Selecione o Fornecedor") {
                var fornecedor = "";
            }
            else{
                var fornecedor = fornecedores;
            }
            var tipo_fatura1=$('#tipo_fatura').val();
            var tipo_fatura2=$('#tipo_fatura2').val();
            var descricao_despesa=$('#descricao_despesa').val();
            var dt_vencimento=$('#dt_vencimento').val();
            var valor_despesa=$('#valor_despesa').val();


            if (cadastroDespesa.dt_vencimento.value == "")
            {
            cadastroDespesa.dt_vencimento.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha com a Data de Vencimento!",
            type: "error",
            timer: 1300,
            showCancelButton: false, 
            showConfirmButton: false 
            });            
            return (false);
            }

            if (cadastroDespesa.valor_despesa.value == "")
            {
            cadastroDespesa.valor_despesa.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha com o Valor Despesa!",
            type: "error",
            timer: 1300,
            showCancelButton: false, 
            showConfirmButton: false 
            });            
            return (false);
            }

            $.ajax({
              url:'../controllers/Pagamentos.php',
              type:'POST',
              data:'id_usuario='+id_usuario+'&despesas_de='+despesas_de+'&paciente='+paciente+'&funcionario='+funcionario+'&fornecedor='+fornecedor+'&tipo_fatura='+tipo_fatura1+tipo_fatura2+'&descricao_despesa='+descricao_despesa+'&dt_vencimento='+dt_vencimento+'&valor_despesa='+valor_despesa+'&botao=cadastrarDespesa'
            }).done(function(resposta){
            if (resposta) {
               $('#CadastroDespesa').modal('hide'); 
               swal({
                 title: "Processo Concluído!",
                 text: "Despesa cadastrada com sucesso!",
                 type: "success",
                 showCancelButton: false, 
                 showConfirmButton: false 
               });
               setTimeout('location.reload();', 1700);
             }  
          });
        }

        function Liquidar(id){
          var id=id        
          swal({
              title: 'Você tem certeza?',
              text: "A Despesa será Liquidada!",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Sim',
              cancelButtonText: "Cancelar",   
              closeOnConfirm: false,   
              closeOnCancel: false
              },

             function(isConfirm){   
               if (isConfirm){     
                   swal({
                   title: "Processo Concluído!",
                   text: "Despesa Liquidada com sucesso!",
                   type: "success",
                   showCancelButton: false, 
                   showConfirmButton: false 
                   });
                   $.ajax({
                     url:'../controllers/Pagamentos.php',
                     type: "POST",
                     data: 'id='+id+"&botao=liquidarDespesa"
                   });
                     setTimeout('location.reload();', 1700);
                   }
                   else{     
                    swal({
                      title: "Processo Cancelado!",
                      text: "Despesa não Liquidada!",
                      type: "error",
                      timer: 1700,
                      showCancelButton: false, 
                      showConfirmButton: false 
                     });   
                    }
                  });
                }

        function deletar(id){
          var id=id        
          swal({
              title: 'Você tem certeza?',
              text: "A Despesa será excluída permanentemente!",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Sim',
              cancelButtonText: "Cancelar",   
              closeOnConfirm: false,   
              closeOnCancel: false
              },

             function(isConfirm){   
               if (isConfirm){     
                   swal({
                   title: "Processo Concluído!",
                   text: "Despesa excluída com sucesso!",
                   type: "success",
                   showCancelButton: false, 
                   showConfirmButton: false 
                   });
                   $.ajax({
                     url:'../controllers/Pagamentos.php',
                     type: "POST",
                     data: 'id='+id+"&botao=excluirDespesa"
                   });
                     setTimeout('location.reload();', 1700);
                   }
                   else{     
                    swal({
                      title: "Processo Cancelado!",
                      text: "Despesa não excluída!",
                      type: "error",
                      timer: 1700,
                      showCancelButton: false, 
                      showConfirmButton: false 
                     });   
                    }
                  });
                }


         function Liquidado(){
           swal({
             title: "Processo Cancelado!",
             text: "A Fatura já foi Liquidada!",
             type: "error",
             timer: 1700,
             showCancelButton: false, 
             showConfirmButton: false 
            }); 
         }

         function cancelar_exclusao(){
           swal({
             title: "Processo Cancelado!",
             text: "Você não pode excluir uma Fatura Liquidada!",
             type: "error",
             timer: 1700,
             showCancelButton: false, 
             showConfirmButton: false 
            }); 
         }
