$(document).ready(function(){
  montaOdontograma();
  tabelaOrcamentos();       
});
       
$('.aprovar_orcamento').hide();
$('#botaoFinaliza').hide();

 if($("#tbOrcamento tr").length == 1){
    $("#tbOrcamento").css("display", "none");
    $("#smile").show();
 }
 else{
    var tb = ($("#tbOrcamento  tr").length)-1;
    $("#smile").hide();
 }

function montaOdontograma(){
   var dentesSuperior = new Array(18, 17, 16, 15, 14, 13, 12, 11, 21, 22, 23, 24, 25, 26, 27, 28);
    for(var i=0; dentesSuperior.length > i; i++){
    $('#ArcadaSuperior').append("<div class='js-dente view-dente' data-dente='"+dentesSuperior[i]+"' title='"+dentesSuperior[i]+"'><input type='checkbox' class='superior' name='dente[]' id='cb"+dentesSuperior[i]+"' value='"+dentesSuperior[i]+"'/><label  class='superior' for='cb"+dentesSuperior[i]+"'><img src='../resources/img/arcadas/"+dentesSuperior[i]+".png'></label><div class='img-dente' data-imgdente='"+dentesSuperior[i]+"'></div></div>");
 
    }
   var dentesInferior = new Array(48, 47, 46, 45, 44, 43, 42, 41,31, 32, 33, 34, 35, 36, 37, 38);
    for(var i=0; dentesInferior.length > i; i++){
    $('#ArcadaInferior').append("<div class='js-dente view-dente2' data-dente='"+dentesInferior[i]+"' title='"+dentesInferior[i]+"'><input type='checkbox' class='inferior' name='dente[]' id='cb"+dentesInferior[i]+"' value='"+dentesInferior[i]+"'/><label class='inferior' for='cb"+dentesInferior[i]+"'><img src='../resources/img/arcadas/"+dentesInferior[i]+".png'></label><div class='img-dente' data-imgdente='"+dentesInferior[i]+"'></div></div>");
    }
    $('#plano').append('<option class="plano0">Selecione o Plano</option><option class="plano1" value="Particular">Particular</option><option class="plano2" value="Convênio">Convênio</option>');  
}

 function tabelaOrcamentos(){
   $('.unitario').attr('checked',true); 
    var id_paciente=$('#id_paciente').val();
     $.post('../models/TabelaOrcamento.php', { id_paciente: id_paciente },
       function(data) {
       data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.
       var total = 0;
        if(data[0].plano!="Particular"){
           $('.aprovar_orcamento').show();
           $('#botaoFinaliza').show();
           $('#infoTb').hide();
        }
        if(data[0].plano=="Particular"){
           $('.plano0').remove();
           $('.plano1').remove();
           $('.plano2').remove();
           $('.selecaoConvenio').remove();
           $('.convenio').remove();
           $('#procedimento').html("");
           $('#plano').attr("disabled", true);
           $('#convenio').attr("disabled", true);
           $('.aprovar_orcamento').show();
           $('#botaoFinaliza').show();
           $('#infoTb').hide();
           $('#plano').append('<option value="'+data[0].plano+'">'+data[0].plano+'</option><option class="plano2" value="Convênio">Convênio</option>');
           $.post('../models/ConvenioProcedimentos.php', { id_usuario: data[0].id_usuario },
           function(data) {
               data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.
               for(var i=0; data.length > i; i++){  
               $('#convenio').append('<option  class="convenio" value="'+data[i].convenio+'">'+data[i].convenio+'</option>');
              }
           });
           $('#convenio').append('<option value="'+data[0].convenio+'">'+data[0].convenio+'</option>');
           $.post('../models/ProcedimentoBusca.php', { convenio: data[0].convenio },
           function(data) {
             data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.
             $('#procedimento').append('<option class="selecaoProcedimento">Selecione o Procedimento</option>');
             for(var i=0; data.length > i; i++){
             $('#procedimento').append('<option  class="nome_procedimento" value="'+data[i].valor_procedimento+'">'+data[i].nome_procedimento+'</option>');
             }
          });
        }
        else{
           $('.plano0').remove();
           $('.plano1').remove();
           $('.plano2').remove();
           $('.selecaoConvenio').remove();
           $('.convenio').remove();
           $('#procedimento').html("");
           $('#plano').attr("disabled", true); 
           $('#convenio').attr("disabled", true);
           $('#plano').append('<option value="'+data[0].plano+'">'+data[0].plano+'</option><option class="plano1" value="Particular">Particular</option>');
           $.post('../models/ConvenioProcedimentos.php', { id_usuario: data[0].id_usuario },
           function(data) {
               data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.
               for(var i=0; data.length > i; i++){  
               $('#convenio').append('<option  class="convenio" value="'+data[i].convenio+'">'+data[i].convenio+'</option>');
              }
           });  
           $('#convenio').append('<option value="'+data[0].convenio+'">'+data[0].convenio+'</option>');
           $.post('../models/ProcedimentoBusca.php', { convenio: data[0].convenio },
           function(data) {
             data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.
             $('#procedimento').append('<option class="selecaoProcedimento">Selecione o Procedimento</option>');
             for(var i=0; data.length > i; i++){  
             $('#procedimento').append('<option  class="nome_procedimento" value="'+data[i].valor_procedimento+'">'+data[i].nome_procedimento+'</option>');
             }
          });
        }

        if(data[0].convenio == "Particular"){
           document.getElementById("parcelamento").disabled = true;
           $('#avista').attr('checked', true);
           $('#parcelamento').val("1");
           $('#forma_pagamento').html("");
           $('#forma_pagamento').append('<option class="opcao1" value="Dinheiro">Dinheiro</option>'+'<option class="opcao3" value="Cartão de Débito">Cartão de Débito</option><option class="opcao6" value="Cheque">Cheque</option>');
           $('#plano1').val(data[0].plano);
           $('#convenio2').val(data[0].convenio);
        }
        else{
           document.getElementById("parcelamento").disabled = true;
           document.getElementById("desconto").disabled = true;
           $('#avista').attr('disabled', true);
           $('#parcelar').attr('disabled', true);
           $('#parcelamento').val("1");
           $('#forma_pagamento').html("");
           $('#forma_pagamento').append('<option class="opcao0" value="Convênio">Convênio</option>');
           $('#forma_pagamento').attr('disabled', true);
           $('#plano1').val(data[0].plano);
           $('#convenio2').val(data[0].convenio);
        }

        for(var i=0; data.length > i; i++){
      
            if(data[i].dente_regiao=="18,17,16,15,14,13,12,11,21,22,23,24,25,26,27,28,48,47,46,45,44,43,42,41,31,32,33,34,35,36,37,38"){
               $("input[type=checkbox][name='dente[]']").attr("disabled", true);
               dentes="Arcadas";
            }
            else if(data[i].dente_regiao=="17,16,15,14,13,12,11,21,22,23,24,25,26,27,47,46,45,44,43,42,41,31,32,33,34,35,36,37"){
               $("input[type=checkbox][name='dente[]']").attr("disabled", true);
               dentes="Arcadas(Agenesia 18,28,48,38)";  
   
            }
            else if (data[i].dente_regiao=="18,17,16,15,14,13,12,11,21,22,23,24,25,26,27,28") {
               $("input[type=checkbox][class='superior']").attr("disabled", true);
               dentes = "Arcada Superior";
            }
            else if (data[i].dente_regiao=="48,47,46,45,44,43,42,41,31,32,33,34,35,36,37,38") {
               $("input[type=checkbox][class='inferior']").attr("disabled", true);
               dentes = "Arcada Inferior";
            }
            else if (data[i].dente_regiao=="17,16,15,14,13,12,11,21,22,23,24,25,26,27,") {
               $("input[type=checkbox][class='superior']").attr("disabled", true);
               dentes = "Arcada Superior(Agenesia 18 e 28)";

            }
            else if (data[i].dente_regiao=="47,46,45,44,43,42,41,31,32,33,34,35,36,37") {
               dentes = "Arcada Inferior(Agenesia 48 e 38)";

            }
            else{
               dentes=data[i].dente_regiao;
               array_dentes = dentes.split(',');
               for(var c=0; array_dentes.length > c; c++){
               $('input:checkbox[name="dente[]"][value="'+array_dentes[c]+'"]').attr('disabled', true);
            }
        }
        $('#tabelaOrcamento').append('<tr class="t1"><td>'+dentes+'</td><td>'+data[i].faces+'</td><td>'+ data[i].procedimento+'</td><td> '+ parseInt(data[i].valor_procedimento).toLocaleString('pt-br', {minimumFractionDigits: 2})+'</td><td><div class="checkbox-bird green tool4" style="top: 6px; left:15%;" data-tip="Selecionar" tabindex="2"><input type="checkbox" class="selecao" name="id[]" id="'+data[i].id+'" value="'+data[i].id+'"><label for="'+data[i].id+'"></label></div></td><td><a onclick="deletarUnitario('+data[i].id+')" class="tool4" data-tip="Excluir" tabindex="2"><i class="font-icon font-icon-trash color-red" style="font-size:16px;"></i></a></td></tr>');            
        total += parseFloat(data[i].valor_procedimento);
      }
        $('#total').html('<tr><td style="position: relative; left:79%;"><b>TOTAL R$ '+parseInt(total).toLocaleString('pt-br', {minimumFractionDigits: 2})+'</b></td></tr>');         
   });       
}


//FUNÇÃO QUE DESABILITA INPUTS DE ACORDO COM A OPTION
  function desabilita(){ 
    if(document.getElementById('avista').checked){
       $('#parcelamento').val("1");
       document.getElementById("parcelamento").disabled = true;
       $('#forma_pagamento').html("");
       $('#valor_entrada').val("");
       $('#desconto').val("");
       $('.opcao2').remove();
       $('#forma_pagamento').append('<option class="opcao1" value="Dinheiro">Dinheiro</option><option class="opcao3" value="Cartão de Débito">Cartão de Débito</option><option class="opcao6" value="Cheque">Cheque</option>');
    }
    else{
       $('#parcelamento').val("");
       document.getElementById("parcelamento").disabled = false;
       $('#valor_entrada').val("");
       $('#forma_pagamento').html("");
       $('#desconto').val("");
       $('.opcao1').remove();
       $('.opcao3').remove();
       $('#forma_pagamento').append('<option class="opcao4" value="Boleto Bancário">Boleto Bancário</option><option class="opcao2" value="Cartão de Crédito">Cartão de Crédito</option><option class="opcao5" value="Cheque">Cheque</option>');
     }
   }

//FUNÇÃO QUE CHECA TODOS CHECKS PARA APROVACAO DO ORCAMENTO
var checkTodos = $("#checkTodos");
    checkTodos.click(function () {
    if ( $(this).is(':checked') ){
      $("input[type=checkbox][name='id[]']").prop("checked", true);
    }
    else{
      $("input[type=checkbox][name='id[]']").prop("checked", false);
    }
  });

//FUNCAO QUE BUSCA OS CONVENIOS PARA ORCAMENTO
 $('#faces').append('<option value="M">M</option><option value="O/I">O/I</option><option value="D">D</option><option value="V">V</option><option value="L/P">L/P</option>');
  $('#convenio').append('<option class="selecaoConvenio">Selecione o Convênio</option>');
   $('#plano').on('change', function() {
    if($('#plano').val() == 'Particular'){
       $('.convenio').remove();
       $('.selecaoConvenio').remove();
       $('.nome_procedimento').remove();
       $('#valor_procedimento').val(""); 
       $('#convenio').append('<option class="selecaoConvenio">Selecione o Convênio</option>'+'<option class="particular" value="Particular">Particular</option>');
       }
       else{
         $('#convenio').append('<option class="selecaoConvenio">Selecione o Convênio</option>');
         $('.particular').remove();
         $('.selecaoConvenio').remove();
         $('.nome_procedimento').remove();
         $('#valor_procedimento').val("");
         //AJAX BUSCA CONVENIOS
         var id_usuario=$('#id_usuario').val();
          $.post('../models/ConvenioProcedimentos.php', { id_usuario: id_usuario },
            function(data) {
             data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.
             $('#convenio').append('<option class="selecaoConvenio">Selecione o Convênio</option>');
             for(var i=0; data.length > i; i++){  
             $('#convenio').append('<option  class="convenio" value="'+data[i].convenio+'">'+data[i].convenio+'</option>');
            }
         });
       }
    });

   //DESABILITA OS CHECKBOX AO CANCELAR A FINALIZACAO DO ORCAMENTO
   function desativaCkeckTbOrcamentos(){
    $("input[type=checkbox][class='selecao']").prop("checked", false);
    }
    $('#convenio').on('change', function(){
    $('.selecaoConvenio').remove();
    $('.nome_procedimento').remove();
    $('.selecaoProcedimento').remove();
    $('#valor_procedimento').val("");
    var convenio=$('#convenio').val();                   
     $.post('../models/ProcedimentoBusca.php', { convenio: convenio },
       function(data) {
       data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.
       $('#procedimento').append('<option class="selecaoProcedimento">Selecione o Procedimento</option>');
       for(var i=0; data.length > i; i++){  
       $('#procedimento').append('<option  class="nome_procedimento" value="'+data[i].valor_procedimento+'">'+data[i].nome_procedimento+'</option>');
       }
     });
    });

    $('#procedimento').on('change', function() {
       var valor = $(this).val();
       $('#valor_procedimento').val(parseInt(valor).toLocaleString('pt-br', {minimumFractionDigits: 2}));
    });

    var unitario = $("#unitario");
    unitario.click(function () {
    if ( $(this).is(':checked') ){
         $("input[type=checkbox][class='superior']").prop("checked", false);
         $("input[type=checkbox][class='inferior']").prop("checked", false);
         $("input[type=checkbox][name='dente[]']").attr("disabled", false);
        }
    });
 
    var arcadas = $("#arcadas");
    arcadas.click(function () {
    if ( $(this).is(':checked') ){
         $("input[type=checkbox][name='dente[]']").prop("checked", true);
         $("input[type=checkbox][name='dente[]']").attr("disabled", false);
       }
    });

    var arcadaSuperior = $("#arcadaSuperior");
    arcadaSuperior.click(function () {
    if ( $(this).is(':checked') ){
         $("input[type=checkbox][class='superior']").attr("disabled", false);
         $("input[type=checkbox][name='dente[]']").prop("checked", false);
         $("input[type=checkbox][class='superior']").prop("checked", true);
         $("input[type=checkbox][class='inferior']").attr("disabled", true);
       }
    });

    var arcadaInferior = $("#arcadaInferior");
    arcadaInferior.click(function () {
    if ( $(this).is(':checked') ){
    $("input[type=checkbox][class='inferior']").attr("disabled", false);
    $("input[type=checkbox][class='inferior']").prop("checked", true);
    $("input[type=checkbox][class='superior']").prop("checked", false);
    $("input[type=checkbox][class='superior']").attr("disabled", true);
    }
  });


 function odontograma(){
    dente = new Array();
      $("input[type=checkbox][name='dente[]']:checked").each(function(){
      dente.push($(this).val());   
    });
      var somaQtd = dente.length;
    if ($("#arcadas").is(':checked') ){
      var quantidade = '1';
    }
    else if ($("#arcadaSuperior").is(':checked') ){
      var quantidade = '1';
    }
    else if ($("#arcadaInferior").is(':checked') ){
      var quantidade = '1';
    }
    else if ($("#montarArcada").is(':checked') ){
      var quantidade = '1';
    }
    else{
      var quantidade = somaQtd;
    }
      var id_usuario=$('#id_usuario').val();
      var id_paciente=$('#id_paciente').val();
      var plano=$('#plano').val();
      var convenio=$('#convenio').val();
      var face = $("#faces").val();
    if (face == undefined) {
      var faces = "Não se Aplica";
    }
    else{
      var faces = face;
    }
      var procedimento=$("#procedimento option:selected").text();
      var valor_procedimento=$('#valor_procedimento').val();

    if (dente == ""){
       swal({
        title:"Odontograma é Obrigatório!",
        text: "Por Favor, Selecione a Regiao ou Dente ",
        type: "error",
        timer: 1500,
        showCancelButton: false, 
        showConfirmButton: false 
       });
     return (false);
    }
    else if(procedimento == ""){
       swal({
        title:"Procedimento é Obrigatório!",
        text: "Por Favor, Selecione um Procedimento! ",
        type: "error",
        timer: 1500,
        showCancelButton: false, 
        showConfirmButton: false 
       });
     return (false);
    }
    $.ajax({
        url: '../controllers/Orcamentos.php',
        type: 'post',
        data:'id_usuario='+id_usuario+'&id_paciente='+id_paciente+'&plano='+plano+'&convenio='+convenio+'&quantidade='+quantidade+'&dente_regiao='+dente+'&faces='+faces+'&procedimento='+procedimento+'&valor_procedimento='+valor_procedimento+'&botao=cadastrarOrcamento'
    }).done(function(resposta){
    if (resposta) {
       swal({
        title: "Processo Concluído!",
        text: "Procedimento adicionado com sucesso!",
        type: "success",
        timer:1200,
        showCancelButton: false, 
        showConfirmButton: false 
       });
          $('#plano').attr("disabled", true);              
          $("input[type=checkbox][class='inferior']").prop("checked", false);
          $("input[type=checkbox][class='superior']").prop("checked", false);
          $("input[type=checkbox][name='dente[]']").prop("checked", false);
          $('#procedimento option').remove(); 
          var convenio=$('#convenio').val();
        $.post('../models/ProcedimentoBusca.php', { convenio: convenio },
          function(data) {
          data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.
          $('#procedimento').append('<option class="selecaoProcedimento">Selecione o Procedimento</option>');
          for(var i=0; data.length > i; i++){  
          $('#procedimento').append('<option  class="nome_procedimento" value="'+data[i].valor_procedimento+'">'+data[i].nome_procedimento+'</option>');
          }
        });
          $('#arcadas').attr('checked',false);
          $('#arcadaSuperior').attr('checked',false);
          $('#arcadaInferior').attr('checked',false);
          $('#unitario').prop('checked',true); 
          $('#valor_procedimento').val("");
          $("#tabelaOrcamento tr").remove();
          $('#faces option').remove();
          $('#faces').append('<option value="M">M</option><option value="O/I">O/I</option><option value="D">D</option><option value="V">V</option><option value="L/P">L/P</option>');
          tabelaOrcamentos();
          } 
       });  
     }

     //FUNCAO QUE DA O CONSUMO DE PRODUTOS DO ESTOQUE! 
      function consumoEstoque() {
        $('#consumirProduto').modal('hide');
        swal({
          title: 'Deseja Consumir algum produto ou insumo?',
          text: "Materiais utilizados durante a consulta ou procedimento deste paciente!",
          type: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Sim',
          cancelButtonText: "Cancelar",   
          closeOnConfirm: true,   
          closeOnCancel: true
          },
          function(isConfirm){   
           if (isConfirm){
            $('#consumirProduto').modal('show');
             document.addEventListener('keypress', function(e){
               if(e.which == 13){
                 //BUSCO O PRODUTO NO ESTOQUE PELO CODIGO
                 var codigo_insumo = $('#codigo_insumo').val();
                 $.post('../models/EstoqueBuscaCodigo.php', { codigo: codigo_insumo },
                   function(data) {
                   if(data==false){
                    $('#consumirProduto').modal('hide');
                    swal({
                     title: "Processo Cancelado!",
                     text: "Produto/Insumo não Cadastrado!",
                     type: "error",
                     timer:1700,
                     showCancelButton: false, 
                     showConfirmButton: false 
                    });
                    window.setTimeout(function () {
                      $('#consumirProduto').modal('show');
                      $('#codigo_insumo').val("");
                      document.getElementById("codigo_insumo").focus();
                    }, 1800);  
                   }
                   else{
                     data = $.parseJSON(data);
                     //AQUI FAZ A VALIDACAO DO ESTOQUE MINIMO
                     if (data[0].estoque_minimo == data[0].quantidade){
                     $('#consumirProduto').modal('hide');
                      swal({
                        title: "Processo Cancelado!",
                        text: "Estoque Mínimo de "+ data[0].produto + ", restam apenas " + data[0].quantidade + " , escolha outro Produto/Insumo ou altere a quantidade mínima em estoque!",
                        type: "error",
                        timer:5000,
                        showCancelButton: false, 
                        showConfirmButton: false 
                      });
                      window.setTimeout(function () {
                        $('#consumirProduto').modal('show');
                        $('#codigo_insumo').val("");
                        document.getElementById("codigo_insumo").focus();
                      }, 5000);  
                     }
                     else{
                       var id_usuario = $('#id_usuario').val();
                       var id_paciente = $('#id_paciente').val();
                       var qtd_consumida = 1;
                     $.ajax({
                       url: '../controllers/Estoque.php',
                       type: 'POST',
                       data:'id_usuario='+id_usuario+'&id_paciente='+id_paciente+'&codigo_produto='+data[0].codigo+'&produto='+data[0].produto+'&qtd_consumida='+qtd_consumida+'&valor_produto='+data[0].valor_unitario+'&botao=consumoPaciente'
                     }).done(function(resposta){
                     //EXIBE NO MODAL O PRODUTO/INSUMO ADD AO CONSUMO COM O PACIENTE E DIMINUI O PRODUTO NO ESTOQUE!
                     if (resposta) {
                        //AJAX QUE DIMINUI DO ESTOQUE O PRODUTO ESCOLHIDO!
                        $.ajax({
                            url: '../controllers/Estoque.php',
                            type: "POST",
                            data: 'id='+data[0].id+'&quantidade='+data[0].quantidade+"&botao=consumirProduto"
                        });
                        //AJAX QUE BUSCA OS PRODUTOS USADOS COM O PACIENTE E APRESENTA NA TABLE
                        $.post('../models/consumoPacienteBusca.php', {id_paciente:id_paciente},
                         function(data) {
                          $('#codigo_insumo').val("");
                          $('#consumo_paciente_foi').html("");
                          $('.tbConsumo').show();
                          data = $.parseJSON(data);
                          for(var i=0; data.length > i; i++){  
                          $('#consumo_paciente_foi').append('<tr><td>'+data[i].codigo_produto+'</td><td>'+data[i].produto+'</td><td></td><td>'+data[i].qtd_consumida+'</td><td></td><td><a onclick="devolveEstoque('+data[i].codigo_produto+','+data[i].id+')" style="position: relative; left:5%; top:2px;" class = "tool" data-tip="Devolver" tabindex="2"><i class="fa fa-refresh  color-blue" style="font-size:16px"></i></a></td></tr>');
                         }
                       });
                      }
                     });
                    }//fim else da validacao do estoque minimo
                   }
                 });
               }
             }, false);
           }
           else{ 
            $('#consumirProduto').modal('hide');
            $('#finalizaOrcamento').modal('show');
           }    
         });
      }

      //FUNCAO DEVOLVE PARA O ESTOQUE 'txtCodEmpreendedor', 'txtNomeEmpreendedor'
      function devolveEstoque(codigo_produto, id) {
        var id = id
        var codigo_produto = codigo_produto
        var id_paciente = $('#id_paciente').val();
        $.post('../models/EstoqueBuscaCodigo.php', {codigo: codigo_produto},
        function(data) {
        data = $.parseJSON(data);
        //DEVOLVO AO ESTOQUE
        $.ajax({
          url: '../controllers/Estoque.php',
          type: "POST",
          data: 'codigo_produto='+codigo_produto+'&quantidade='+data[0].quantidade+"&botao=devolverProduto"
        }).done(function(resposta){
        //EXCLUO O PRODUTO DO PACIENTE
           if (resposta) {
            $.ajax({
              url: '../controllers/Estoque.php',
              type: "POST",
              data: 'id='+id+"&botao=excluirProdutoPaciente"
            }).done(function(resposta){
              if (resposta) {
              //SE EXCLUIU COM SUCESSO, ATUALIZO A TABLE
               $.post('../models/consumoPacienteBusca.php', {id_paciente:id_paciente},
                 function(data) {
                  document.getElementById("codigo_insumo").focus();
                  $('#codigo_insumo').val("");
                  $('#consumo_paciente_foi').html("");
                  data = $.parseJSON(data);
                  for(var i=0; data.length > i; i++){  
                  $('#consumo_paciente_foi').append('<tr><td>'+data[i].codigo_produto+'</td><td>'+data[i].produto+'</td><td></td><td>'+data[i].qtd_consumida+'</td><td></td><td><a onclick="devolveEstoque('+data[i].codigo_produto+','+data[i].id+')" style="position: relative; left:5%; top:2px;" class = "tool" data-tip="Devolver" tabindex="2"><i class="fa fa-refresh  color-blue" style="font-size:16px"></i></a></td></tr>');
                }
               });
              }
            });
           }
         });
       });
      }

      function consumoOK() {
        $('#consumirProduto').modal('hide');
        $('#finalizaOrcamento').modal('show');
      }
      //FUNÇÃO QUE BUSCA OS VALORES E SOMA PARA POSSÍVEL  APROVACAO 
      function finalizar(){
          $('#tabelaAprova').html(""); 
          var id = $(".aprovar_orcamento").serialize();
          if(id == ""){
            swal({
               title: 'Atenção!',
               text: "Escolha um procedimento a Finalizar!",
               type: 'warning',  
               timer: 1500,
               showCancelButton: false, 
               showConfirmButton: false 
             });
           }
           else{
           // AJAX QUE BUSCA OS VALORES SOMADOS
           $.ajax({
              url: '../models/AprovarOrcamentoBusca.php',
              type: "POST",
              data: id,
              success: function(data){
              $('#somaTotal').val(mascara(data+"00"));
              }
           });
           //AJAX QUE BUSCA O ID DE USUARIO E DO PACIENTE
           $.ajax({
              url: '../models/AprovarOrcamentoDados.php',
              type: "POST",
              dataType: 'json',
              data: id,
              success: function(data){
               for(var i=0; data.length > i; i++){
                  if(data[i].dente_regiao=="18,17,16,15,14,13,12,11,21,22,23,24,25,26,27,28,48,47,46,45,44,43,42,41,31,32,33,34,35,36,37,38"){
                     dentes="Arcadas";
                  }
                  else if(data[i].dente_regiao=="17,16,15,14,13,12,11,21,22,23,24,25,26,27,47,46,45,44,43,42,41,31,32,33,34,35,36,37"){
                     dentes="Arcadas(Agenesia 18,28,48,38)";
                  }
                  else if (data[i].dente_regiao=="18,17,16,15,14,13,12,11,21,22,23,24,25,26,27,28") {
                     dentes = "Arcada Superior";
                  }
                  else if (data[i].dente_regiao=="48,47,46,45,44,43,42,41,31,32,33,34,35,36,37,38") {
                     dentes = "Arcada Inferior";
                  }

                  else if (data[i].dente_regiao=="17,16,15,14,13,12,11,21,22,23,24,25,26,27,") {
                     dentes = "Arcada Superior(Agenesia 18 e 28)";
                  }
                  else if (data[i].dente_regiao=="47,46,45,44,43,42,41,31,32,33,34,35,36,37") {
                     dentes = "Arcada Inferior(Agenesia 48 e 38)";
                  }
                  else{
                    dentes=data[i].dente_regiao;
                  }
                    $('#tabelaAprova').append('<tr><td>'+dentes+'</td><td>'+data[i].faces+'</td><td>'+ data[i].procedimento+'</td><td> '+ mascara(data[i].valor_procedimento+"00")+'</td></tr>');                    
                    $('.tabelaAprova').append("Dentes "+ dentes +" Faces(" +data[i].faces+ "), " +data[i].procedimento);
                    $('#id_usuario1').val(data[i].id_usuario);
                    $('#id_paciente2').val(data[i].id_paciente);
                    }
                  }
               });
               $('#id_orcamentos').val(id);
               $('#consumirProduto').modal('show');
               document.getElementById("codigo_insumo").focus();
              consumoEstoque()
             }
           }

        //FUNCAO QUE FINALIZA ORCAMENTO E MANDA PARA TABELA DE ORCAMENTOS FINALIZADOS
        function finalizarOrcamento(){
          var idPaciente=$('#idPaciente').val();
          var id_usuario=$('#id_usuario1').val();
          var id_paciente=$('#id_paciente2').val();
          var plano=$('#plano1').val();
          var convenio=$('#convenio2').val();
          var procedimentos_aprovados= $('#divAprovados').html();
          var tbDescricao= $('.tabelaAprova').html();
          var valor_total=$('#somaTotal').val();
          var parcelar=$('#parcelamento').val();
          if(parcelar==""){
             parcelamento= "1";
          }
          else{
            parcelamento=parcelar;
          }
          var valor_entrada=$('#valor_entrada').val();
          var desconto=$('#desconto').val();
          var forma_pagamento=$('#forma_pagamento').val();
          var forma_pagamento_entrada=$('#forma_pagamento_entrada').val();
          $.ajax({
            url: '../controllers/Orcamentos.php',
            type: 'POST',
            data:'id_usuario='+id_usuario+'&id_paciente='+id_paciente+'&plano='+plano+'&convenio='+convenio+'&procedimentos_aprovados='+procedimentos_aprovados+'&tbDescricao='+tbDescricao+'&valor_total='+valor_total+'&parcelamento='+parcelamento+'&valor_entrada='+valor_entrada+'&desconto='+desconto+'&forma_pagamento='+forma_pagamento+'&forma_pagamento_entrada='+forma_pagamento_entrada+'&botao=finalizarOrcamento'
          }).done(function(resposta){

           if (resposta) {
              $('#finalizaOrcamento').modal('hide');
              swal({
                title: 'Deseja Imprimir o Orçamento?',
                text: "Caso cancele, poderá imprimir depois!",
                type: 'info',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sim',
                cancelButtonText: "Cancelar",   
                closeOnConfirm: false,   
                closeOnCancel: false
                },
              function(isConfirm){   
                if (isConfirm){     
                   swal({
                    title: "Processo Concluído!",
                    text: "Orçamento Impresso com sucesso!",
                    type: "success",
                    showCancelButton: false, 
                    showConfirmButton: false 
                   });
                window.open('imprimir/orcamento','_blank'); 
                setTimeout(function(){window.top.location="orcamento?@="+idPaciente } , 1000);
                }
                else{     
                    swal({
                     title: "Processo Cancelado!",
                     text: "Orçamento não Impresso!",
                     type: "error",
                     showCancelButton: false, 
                     showConfirmButton: false 
                    });  
                    setTimeout(function(){window.top.location="orcamento?@="+idPaciente } , 1000); 
                    }
                 });
              }
           });  
           var id=$('#id_orcamentos').val();
           $.ajax({
             url: '../controllers/Orcamentos.php',
             type: 'POST',
             data:id+'&botao=statusOrcamento'
          }); 
       }

        //FUNCAO VISUALIZAR ORCAMENTO
          function abrirOrcamento(id){
              var id=id
              var randomico=$('#randomico').val();
              var codigo = randomico+btoa(id);
              $.ajax({
                url: '../models/BuscarOrcamentoVizualizar.php',   
                type: "POST",
                dataType: 'json',
                data: 'id='+id,
                success: function(data){
                for(var i=0; data.length > i; i++){
                    $('#procedimentos_aprovados').append('<div>'+data[i].procedimentos_aprovados+'</div>');

                    if(data[i].forma_pagamento_entrada == ""){
                      var fm_pagamento_entrada = "";
                    }
                    else{
                      var fm_pagamento_entrada = " pagos com " + data[i].forma_pagamento_entrada;
                    }

                    if(data[i].valor_entrada == 0){
                       var entrada = "";
                    }
                    else{
                       var entrada = " com entrada de " + Number(data[i].valor_entrada).toLocaleString('pt-br',{style: 'currency', currency: 'BRL'}) + fm_pagamento_entrada;
                    }

                    if(data[i].desconto == ""){
                       descontos = "";
                    }
                    else{
                       descontos = " e desconto de " + data[i].desconto + "%";
                    }

                    if(data[i].plano == "Particular"){
                      fm_pagamento= data[i].forma_pagamento;
                    }
                    else{
                      fm_pagamento= data[i].convenio;
                    }

                    $('#subtotal').append('<div style="position: relative; left: 200px;">'+Number(data[i].valor_total).toLocaleString('pt-br',{style: 'currency', currency: 'BRL'})+'</div>');
                    $('#formas_pagamento').append("Plano " + data[i].plano + " ( " + fm_pagamento + " em " + data[i].parcelamento + "X de " + Number(data[i].valor_parcela).toLocaleString('pt-br',{style: 'currency', currency: 'BRL'}) + entrada + descontos +" ) ");
                    $('#total').append('<div style="position: relative; left: 335px;"><b> '+ Number(data[i].valor_final).toLocaleString('pt-br',{style: 'currency', currency: 'BRL'}) +'</b></div>');
                    }
                 }
              });
              $('#visualizarOrcamento').modal('show');
              $("#Imprimir").click(function () {
                 setTimeout('location.reload();', 1000);
                 window.open('imprimir/orcamentos?@='+codigo, '_blank');
              });
            }
            
            //FUNCAO QUE APROVA ORCAMENTO E MANDA A FATURA APROVADA PARA O CAIXA!
            function aprovarOrcamento(id){
               var id=id
                $.post('../models/BuscarOrcamentoVizualizar.php', { id: id },
                 function(data) {
                  data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON. 
                   if(data[0].status_aprovacao == "Aprovado"){
                    swal({
                        title: "Processo Cancelado!",
                        text: "Este orçamento já foi Aprovado!",
                        type: "error",
                        timer:1500,
                        showCancelButton: false, 
                        showConfirmButton: false 
                       });  
                    }
                    else{
                       var randomico=$('#randomico').val();
                       var codigo = randomico+btoa(id);
                       $.ajax({
                         url: '../controllers/Orcamentos.php',
                         type: "POST",
                         data: 'id='+id+"&botao=aprovarOrcamento"
                       });
                       swal({
                         title: 'Orçamento aprovado com sucesso!',
                         text: "Fatura enviada ao caixa!",
                         type: "success",
                         showCancelButton: false, 
                         showConfirmButton: false 
                       });
                       setTimeout('location.reload();', 1600);
                      }   
                   }); 
                }

           //FUNÇÃO DELETA POR SELECIONAR CHECKBOX
           $(document).ready(function(){
             $(document).on('submit','#tabela_orcamento', function(event){
                event.preventDefault();
                 var dados = $(this).serialize();
                 if(dados == ""){
                    swal({
                        title: 'Atenção!',
                        text: "Escolha um procedimento a ser excluído!",
                        type: 'warning',  
                        timer: 1500,
                        showCancelButton: false, 
                        showConfirmButton: false 
                        });
                    }
                    else{
                    swal({
                        title: 'Você tem certeza?',
                        text: "O procedimento será excluído permanentemente!",
                        type: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Sim',
                        cancelButtonText: "Cancelar",   
                        closeOnConfirm: false,   
                        closeOnCancel: false
                        },
                    function(isConfirm){   
                    if (isConfirm){     
                       swal({
                        title: "Processo Concluído!",
                        text: "Procedimento excluído com sucesso!",
                        type: "success",
                        timer:1400,
                        showCancelButton: false, 
                        showConfirmButton: false 
                        });
                        $.ajax({
                          url: '../controllers/Orcamentos.php',
                          type: "POST",
                          data: dados+"&botao=excluirOrcamento"
                        });
                        setTimeout('location.reload();', 1700); 
                        }
                        else{     
                        swal({
                            title: "Processo Cancelado!",
                            text: "Procedimento não excluído!",
                            type: "error",
                            timer:1400,
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });  
                            setTimeout('location.reload();', 1700);  
                           }
                          });
                        }
                      });
                    });
        

             //FUNCAO DELETAR ORCAMENTO
            function deletarOrcamento(id){
                var id=id 
                 $.post('../models/BuscarOrcamentoVizualizar.php', { id: id },
                 function(data) {
                  data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON. 
                   if(data[0].status_aprovacao == "Aprovado"){
                    swal({
                        title: "Processo Cancelado!",
                        text: "Você não pode excluir um orçamento Aprovado!",
                        type: "error",
                        timer:1500,
                        showCancelButton: false, 
                        showConfirmButton: false 
                       });  
                    }
                    else{   
                    swal({
                        title: 'Você tem certeza?',
                        text: "O Procedimento será excluído permanentemente!",
                        type: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Sim',
                        cancelButtonText: "Cancelar",   
                        closeOnConfirm: false,   
                        closeOnCancel: false
                        },

                    function(isConfirm){   
                        if (isConfirm){     
                            swal({
                            title: "Processo Concluído!",
                            text: "Procedimento excluído com sucesso!",
                            type: "success",
                            timer:1400,
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });
                        $.ajax({
                            url: '../controllers/Orcamentos.php',
                            type: "POST",
                            data: 'id='+id+"&botao=excluirFinalizado"
                        });

                          setTimeout('location.reload();', 1700);
                        }
                        else{     
                            swal({
                            title: "Processo Cancelado!",
                            text: "Procedimento não excluído!",
                            type: "error",
                            timer:1400,
                            showCancelButton: false, 
                            showConfirmButton: false 
                            }); 
                            
                            setTimeout('location.reload();', 1700);
                           }
                          });
                        }
                     });
                  }

        //FUNCAO DELETAR UNITARIO
            function deletarUnitario(id){
                var id=id        
                    swal({
                        title: 'Você tem certeza?',
                        text: "O Procedimento será excluído permanentemente!",
                        type: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Sim',
                        cancelButtonText: "Cancelar",   
                        closeOnConfirm: false,   
                        closeOnCancel: false
                        },

                    function(isConfirm){   
                        if (isConfirm){ 
                        $.ajax({
                            url: '../controllers/Orcamentos.php',
                            type: "POST",
                            data: 'id='+id+"&botao=excluirUnitario"
                        });

                            swal({
                            title: "Processo Concluído!",
                            text: "Procedimento excluído com sucesso!",
                            type: "success",
                         
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });
                                                
                          setTimeout('location.reload();', 1700);          
                        }
                        else{     
                            swal({
                            title: "Processo Cancelado!",
                            text: "Procedimento não excluído!",
                            type: "error",
                            timer:1400,
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });

                          setTimeout('location.reload();', 1700);
                           }

                          });
                        }


