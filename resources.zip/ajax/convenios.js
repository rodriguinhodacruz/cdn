if($("#tbConvenios tr").length == 1){
  $("#tbConvenios").css("display", "none");
  $("#smile").show();
}
else{
  var tb = ($("#tbConvenios  tr").length)-1;
  $("#smile").hide();
}   

//FUNCAO QUE CADASTRA O CONVENIO
        function cadastrar_convenio(){
     
            var id_usuario=$('#id_usuario').val();
            var convenio=$('#convenio').val();
            var registro_ans=$('#registro_ans').val();
            var cnpj=$('#cnpj').val();
            var email=$('#email').val();
            var site=$('#site').val();
            var telefone=$('#telefoneFixo').val();
            var telefone_celular=$('#celular').val();
            if (cadastroConvenio.convenio.value == "")
            {
            cadastroConvenio.convenio.focus();
            swal({
            title:"Campo Obrigatório!",
            text: "Por Favor, preencha o Convênio!",
            type: "error",
            timer: 1800,
            showCancelButton: false, 
            showConfirmButton: false 
            });            
            
            return (false);
            }
            

            $.ajax({
                    url:'../controllers/Convenio.php',
                    type:'POST',
                    data:'id_usuario='+id_usuario+'&convenio='+convenio+'&registro_ans='+registro_ans+'&cnpj='+cnpj+'&email='+email+'&site='+site+'&telefone='+telefone+'&telefone_celular='+telefone_celular+'&botao=cadastrarConvenio'
                }).done(function(resposta){
                    if (resposta) {
                      $('#CadastroPacientes').modal('hide'); 
                        swal({
                            title: "Processo Concluído!",
                            text: "Cadastro realizado com sucesso!",
                            type: "success",
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });
                      setTimeout('location.reload();', 1700);
                    }

                    
                });
            
            }



//FUNCAO QUE BUSCA OS DADOS PARA EDICAO
        function editaConvenio(id){
          var id=id
          $.post('../models/ConvenioBusca.php', { id: id },
            function(data) {
            data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.  
             $('#id').val(data[0].id);
             $('#convenios').val(data[0].convenio);
             $('#sites').val(data[0].site);
             $('#emails').val(data[0].email);
             $('#telefoneFixos').val(data[0].telefone);
             $('#celulars').val(data[0].telefone_celular);
            });

        }


    //FUNCAO ALTERAR FOTO PERFIL DO PACIENTE
        function bandeira(id){
          var id=id
          $.post('../models/ConvenioBusca.php', { id: id },
            function(data) {
            data = $.parseJSON(data);//Converte o Array String vindo do PHP em objecto JSON.  
             $('#idFoto').val(data[0].id);
             $('#img-preview').attr('src', data[0].bandeira);
            });

        }
          $("#file-input").change(function() {
          var file = this.files[0];
          var imagefile = file.type;
          var reader = new FileReader();
            reader.onload = function(e){
                $(".img").html('<img src="' + e.target.result + '" />');              
            };
            reader.readAsDataURL(this.files[0]);
          }); 

          $('#file-input').change(function() {
            var id=$('#idFoto').val();
             $('#form-Bandeira').ajaxForm({
                    url: '../controllers/FotoBandeira.php',
                    type: 'post',
                    data:{ id: id }
             }).submit();

             $('#Bandeira').modal('hide'); 
                swal({
                    title: "Processo Concluído!",
                    text: "Bandeira alterada com sucesso!",
                    type: "success",
                    showCancelButton: false, 
                    showConfirmButton: false 
                    });
                  setTimeout('window.location.href=("convenios");', 1700);
          }); 
      

      //EDICAO DADOS 
        function editar_convenio(){
            var id=$('#id').val();
            var convenio=$('#convenios').val();
            var registro_ans=$('#registro_anss').val();
            var cnpj=$('#cnpjs').val();
            var email=$('#emails').val();
            var site=$('#sites').val();
            var telefone=$('#telefoneFixos').val();
            var telefone_celular=$('#celulars').val();
            

            $.ajax({
                    url:'../controllers/Convenio.php',
                    type:'POST',
                    data:'id='+id+'&convenio='+convenio+'&registro_ans='+registro_ans+'&cnpj='+cnpj+'&email='+email+'&site='+site+'&telefone='+telefone+'&telefone_celular='+telefone_celular+'&botao=editarConvenio'
                }).done(function(resposta){
                    if (resposta) {
                        swal({
                            title: "Processo Concluído!",
                            text: "Registro atualizado com sucesso!",
                            type: "success",
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });
                        
                        setTimeout('window.location.href=("convenios");', 1700);
                    }

                    
                });
            
            }


             function deletar(id){
                var id=id        
                    swal({
                        title: 'Você tem certeza?',
                        text: "O Registro será excluído permanentemente!",
                        type: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Sim',
                        cancelButtonText: "Cancelar",   
                        closeOnConfirm: false,   
                        closeOnCancel: false
                        },

                    function(isConfirm){   
                        if (isConfirm){     
                            swal({
                            title: "Processo Concluído!",
                            text: "Registro excluído com sucesso!",
                            type: "success",
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });
                        $.ajax({
                            url: '../controllers/Convenio.php',
                            type: "POST",
                            data: 'id='+id+"&botao=excluirConvenio"
                        });
                         setTimeout('location.reload();', 1700);
                        }
                        else{     
                            swal({
                            title: "Processo Cancelado!",
                            text: "Registro não excluído!",
                            type: "error",
                            timer: 1700,
                            showCancelButton: false, 
                            showConfirmButton: false 
                            });   
                           }
                          });
                        }
        


        

   